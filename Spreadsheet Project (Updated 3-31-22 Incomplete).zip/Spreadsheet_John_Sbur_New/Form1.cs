﻿// <copyright file="Form1.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Spreadsheet_John_Sbur
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Cpts321;

    /// <summary>
    ///  Main class that holds information, events, and behaviour of the spreadsheet window.
    /// </summary>
    public partial class Form1 : Form
    {
        private Spreadsheet dataSpreadsheet;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();

            // Initialize dataSpreadsheet
            this.dataSpreadsheet = new Spreadsheet(50, 26);

            // Subscribe to the event handler so when value is changed it updates the grid.
            this.dataSpreadsheet.CellPropertyChangedEventHandler += this.UpdateDataGridCell;

            // Resize for easier viewing
            this.Width = 1000;
            this.Height = 1000;

            string holder = " ";

            // Clear existing columns and rows
            this.dataGridView1.Rows.Clear();
            this.dataGridView1.Columns.Clear();

            // Add columns A-Z.
            for (char i = 'A'; i <= 'Z'; i++)
            {
                holder = i.ToString();
                this.AddColumn(holder);
            }

            // Add rows 1-50
            for (int i = 1; i <= 50; i++)
            {
                holder = i.ToString();
                this.AddRow(holder);
            }

            // Resize row headers so multiple digits are seen.
            this.dataGridView1.RowHeadersWidth = 50;
        }

        /// <summary>
        ///  Function used to add columns into the application.
        /// </summary>
        /// <param name="name">
        ///  Used to mark the name of the column to be added.
        /// </param>
        private void AddColumn(string name)
        {
            // Create and name column
            DataGridViewColumn newColumn = new DataGridViewColumn();
            newColumn.Name = name;

            // Create template cell for column to use as default
            DataGridViewCell cellTemplate = new DataGridViewTextBoxCell();
            cellTemplate.Style.BackColor = Color.White;

            // Set column template to cell
            newColumn.CellTemplate = cellTemplate;

            // Insert new column
            this.dataGridView1.Columns.Add(newColumn);
        }

        /// <summary>
        ///  Function used to add rows into the application.
        /// </summary>
        /// <param name="name">
        ///  Name of row to be added.
        /// </param>
        private void AddRow(string name)
        {
            DataGridViewRow newRow = new DataGridViewRow();
            newRow.HeaderCell.Value = name;
            this.dataGridView1.Rows.Add(newRow);
        }

        /// <summary>
        ///  Function used to manually update dataGridView cells.
        /// </summary>
        /// <param name="rowIndex">
        ///  Target row to be updated.
        /// </param>
        /// <param name="columnIndex">
        ///  Target column to be updated.
        /// </param>
        private void UpdateCell(int rowIndex, int columnIndex)
        {
            // If the target is in range, edit the cell requested by updating the text of the cell in the grid to match the spreadsheet cell. Otherwise, return.
            if ((this.dataSpreadsheet.RowCount > rowIndex && rowIndex >= 0) && (columnIndex >= 0 && columnIndex < this.dataSpreadsheet.ColumnCount))
            {
                if ((this.dataGridView1.Rows.Count > rowIndex) && (this.dataGridView1.Columns.Count > columnIndex))
                {
                    this.dataGridView1[columnIndex, rowIndex].Value = this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Value;
                }
            }

            return;
        }

        /// <summary>
        ///  Event triggers on a Cell's data changing. Changed the dataGridView's table's corresponding cell to match the change.
        /// </summary>
        /// <param name="sender">
        ///  Sending object, usually a spreadsheetcell.
        /// </param>
        /// <param name="e">
        ///  ARguments sent from sender object.
        /// </param>
        private void UpdateDataGridCell(object? sender, EventArgs e)
        {
            if (sender != null)
            {
                if (sender.GetType() == typeof(SpreadsheetCell))
                {
                    SpreadsheetCell sourceCell = (SpreadsheetCell)sender;
                    this.UpdateCell(sourceCell.RowIndex, sourceCell.ColumnIndex);
                }
            }
        }

        /// <summary>
        ///  Event triggers when demo button is clicked.
        ///  The demo should set the text in about 50 random cells to a text string of your choice.
        ///     “Hello World!” would be fine or some other message would be ok too.
        ///  o Also, do a loop to set the text in every cell in column B to “This is cell B#”, where #
        ///     number is the row number for the cell.
        ///  o Then set the text in every cell in column A to “=B#”, where ‘#’ is the row number of the
        ///     cell. So in other words you’re setting every cell in column A to have a value equal to the
        ///     cell to the right of it in column B.
        ///  o The result should be that the cells in column A update to have the same values as
        ///     column B.
        /// </summary>
        /// <param name="sender">
        ///  Object that sent the event.
        /// </param>
        /// <param name="e">
        ///  Arguments sent from sender when event was invoked.
        /// </param>
        private void DemoButtonClicked(object sender, EventArgs e)
        {
            // Part 1, fill 50 random cells.
            var randomNumberGenerator = new Random();
            int randomColumn = 0;
            int randomRow = 0;

            for (int i = 0; i < 50;)
            {
                randomColumn = randomNumberGenerator.Next(0, 26);
                randomRow = randomNumberGenerator.Next(0, 50);

                SpreadsheetCell[,] holderArray = this.dataSpreadsheet.CellArray;

                if (holderArray[randomRow, randomColumn].Text == string.Empty)
                {
                    this.dataSpreadsheet.SetCellText(randomRow, randomColumn, "Hello World!");
                    i++;
                }
            }

            // Part 2, set every column in column B to "This is cell B#"
            for (int i = 0; i < 50; i++)
            {
                this.dataSpreadsheet.SetCellText(i, 1, "This is cell B" + (i + 1).ToString());
            }

            // Part 3, set every column in column A to "=B#"
            for (int i = 0; i < 50; i++)
            {
                this.dataSpreadsheet.SetCellText(i, 0, "=B" + (i + 1).ToString());
            }
        }

        /// <summary>
        ///  Event triggers when the cell is selected for editing. Text is displayed instead of value.
        /// </summary>
        /// <param name="sender">
        ///  Cell that triggered the event.
        /// </param>
        /// <param name="e">
        ///  Arguments passed into event.
        /// </param>
        // Warning suppressed because code was autogenerated and tampering destabilized the application.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            if (this.dataSpreadsheet != null)
            {
                if (this.dataSpreadsheet.GetCell(e.RowIndex, e.ColumnIndex) != null)
                {
                    // Cannot be null since if statements before checked to make sure it isn't null.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                    if (this.dataSpreadsheet.GetCell(e.RowIndex, e.ColumnIndex).Text != null)
                    {
                        this.dataGridView1[e.ColumnIndex, e.RowIndex].Value = this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Text;
                    }
#pragma warning restore CS8602 // Dereference of a possibly null reference.
                }
            }
        }

        /// <summary>
        ///  Event triggers when the cell is unselected for editing. Updated value is displayed based on the entered text from the user instead of text.
        /// </summary>
        /// <param name="sender">
        ///  Cell that triggered the event.
        /// </param>
        /// <param name="e">
        ///  Arguments passed into event.
        /// </param>
        // Warning suppressed because code was autogenerated and tampering destabilized the application.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            if (this.dataSpreadsheet != null && this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex] != null)
            {
                if (this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    if (this.dataSpreadsheet.GetCell(e.RowIndex, e.ColumnIndex) != null && this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() != null)
                    {
                        // If nothing changed, change the cell back to the original value with possibly updated variable values.
                        if (this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() == this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Text)
                        {
#pragma warning disable CS8604 // Possible null reference argument.
                            this.dataSpreadsheet.SetCellText(e.RowIndex, e.ColumnIndex, string.Empty);
                            this.dataSpreadsheet.SetCellText(e.RowIndex, e.ColumnIndex, this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
#pragma warning restore CS8604 // Possible null reference argument.
                        }

                        // if the new text is the empty string, set it to the empty string
                        else if (this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() == string.Empty)
                        {
                            this.dataGridView1[e.ColumnIndex, e.RowIndex].Value = string.Empty;
                            this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Text = string.Empty;
                            this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Value = string.Empty;
                        }

                        // Otherwise, update the cell.
                        else
                        {
                            // Cannot be null as if statement before checks to make sure it isn't.
                            try
                            {
#pragma warning disable CS8604 // Possible null reference argument.
                                this.dataSpreadsheet.SetCellText(e.RowIndex, e.ColumnIndex, string.Empty);
                                this.dataSpreadsheet.SetCellText(e.RowIndex, e.ColumnIndex, this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
#pragma warning restore CS8604 // Possible null reference argument.
                            }
                            catch
                            {
                                this.dataGridView1[e.ColumnIndex, e.RowIndex].Value = this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Value;
                            }
                        }
                    }
                }
                else
                {
                    this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Text = string.Empty;
                    this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Value = string.Empty;
                }
            }
        }
    }
}
