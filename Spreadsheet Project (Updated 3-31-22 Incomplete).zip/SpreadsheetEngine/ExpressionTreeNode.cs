﻿// <copyright file="ExpressionTreeNode.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Base node to be inherited by other node types.
    /// </summary>
    public abstract class ExpressionTreeNode
    {
        private string? name;
        private ExpressionTreeNode? left;
        private ExpressionTreeNode? right;

        private bool isParenthesisToken;

        /// <summary>
        ///  Notifies subscribers when the name of the Node has been changed.
        /// </summary>
        public event PropertyChangedEventHandler? NameChanged = (sender, e) => { };

        /// <summary>
        ///  Notifies subscribers when the left child Node has been changed.
        /// </summary>
        public event PropertyChangedEventHandler? LeftChanged = (sender, e) => { };

        /// <summary>
        ///  Notifies subscribers when the right child Node has been changed.
        /// </summary>
        public event PropertyChangedEventHandler? RightChanged = (sender, e) => { };

        /// <summary>
        ///  Gets or Sets name.
        /// </summary>
        public string? Name
        {
            get
            {
                return this.name;
            }

            set
            {
                string? oldName = this.name;
                this.name = value;
                this.NotifyNameChanged(oldName);
            }
        }

        /// <summary>
        ///  Gets or Sets left node.
        /// </summary>
        public ExpressionTreeNode? Left
        {
            get
            {
                return this.left;
            }

            set
            {
                this.left = value;
                this.NotifyLeftChanged(this.name);
            }
        }

        /// <summary>
        ///  Gets or Sets right node.
        /// </summary>
        public ExpressionTreeNode? Right
        {
            get
            {
                return this.right;
            }

            set
            {
                this.right = value;
                this.NotifyRightChanged(this.name);
            }
        }

        /// <summary>
        ///  Gets or sets a value indicating whether the node is made from a parenthesis token.
        /// </summary>
        public bool IsParenthesisToken
        {
            get => this.isParenthesisToken;
            set => this.isParenthesisToken = value;
        }

        /// <summary>
        ///  Invokes the name changed event and tells subscribers it happened.
        /// </summary>
        /// <param name="oldName">
        ///  Name of the old name in this object.
        /// </param>
        public void NotifyNameChanged([CallerMemberName] string? oldName = "")
        {
            this.NameChanged?.Invoke(this, new PropertyChangedEventArgs(oldName));
        }

        /// <summary>
        ///  Invokes the left changed event and tells subscribers it happened.
        /// </summary>
        /// <param name="text">
        ///  Property of event args.
        /// </param>
        public void NotifyLeftChanged([CallerMemberName] string? text = "")
        {
            this.LeftChanged?.Invoke(this, new PropertyChangedEventArgs(text));
        }

        /// <summary>
        ///  Invokes the right changed event and tells subscribers it happened.
        /// </summary>
        /// <param name="text">
        ///  Property of event args.
        /// </param>
        public void NotifyRightChanged([CallerMemberName] string? text = "")
        {
            this.RightChanged?.Invoke(this, new PropertyChangedEventArgs(text));
        }
    }
}
