﻿// <copyright file="ExpressionTree.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Class used for storing expression tree objects. Can evaluate tree once stored.
    /// </summary>
    internal class ExpressionTree
    {
        /// <summary>
        ///  Root of the tree. Is initialized during construction.
        /// </summary>
        private ExpressionTreeNode? root;

        /// <summary>
        ///  Used to keep track of variables inside of the tree.
        /// </summary>
        private Dictionary<string, double> variableDictionary;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTree"/> class.
        ///  This constructor is designed to create an expression tree based on an inputted expression..
        /// </summary>
        /// <param name="expression">
        ///  Inputted expression.
        /// </param>
        public ExpressionTree(string expression)
        {
            this.variableDictionary = new Dictionary<string, double>();
            this.Compile(expression);
        }

        /// <summary>
        ///  Function used for setting variables used in the expression tree.
        /// </summary>
        /// <param name="variableName">
        ///  Name of variable to be editted.
        /// </param>
        /// <param name="variableValue">
        ///  Variable's new value.
        /// </param>
        public void SetVariable(string variableName, double variableValue)
        {
            // Add the variable to the dictionary with value associated with it if it doesn't exist or update it if it does exist.
            if (variableName != null)
            {
                if (this.variableDictionary.ContainsKey(variableName) == false)
                {
                    if (variableName != string.Empty && (variableName != "(" && variableName != ")"))
                    {
                        this.variableDictionary.Add(variableName, variableValue);
                    }

                    return;
                }
                else
                {
                    this.variableDictionary[variableName] = variableValue;
                    return;
                }
            }
        }

        /// <summary>
        ///  Lists all current variables in the current tree.
        /// </summary>
        /// <returns>
        ///  String list of all variables in dictionary.
        /// </returns>
        // Fixing spacing leads to another warning. Resolution not possible.
#pragma warning disable SA1011 // Closing square brackets should be spaced correctly
        public string[]? ListAllVariables()
#pragma warning restore SA1011 // Closing square brackets should be spaced correctly
        {
            // If the dictionary is empty, return.
            if (this.variableDictionary.Count == 0)
            {
                Console.WriteLine("Variable List is empty");
                return null;
            }

            // If the dictionary isn't empty, list all the variables in it. Then return.
            else
            {
                string[] returnList = new string[this.variableDictionary.Count];
                int i = 0;
                foreach (KeyValuePair<string, double> kvp in this.variableDictionary)
                {
                    // Print pairs.
                    Console.WriteLine("Variable = {0}: \tValue = {1}", kvp.Key, kvp.Value);

                    // Add list items to return list.
                    returnList[i] = kvp.Key;
                    i++;
                }

                return returnList;
            }
        }

        /// <summary>
        ///  Evaluates the expression tree. Returns the result as a double.
        /// </summary>
        /// <returns>
        ///  Returns the double evaluated through the expression or 0 if it fails, the root is null, or that's just the answer.
        /// </returns>
        public double Evaluate()
        {
            if (this.root != null)
            {
                return this.EvaluateHelper(this.root);
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        ///  Compiles and stores the expression inside of root.
        /// </summary>
        /// <param name="expression">
        ///  Expression to be stored in root.
        /// </param>
        /// <returns>
        ///  True if successfully compiled. False if not.
        /// </returns>
        public bool Compile(string expression)
        {
            // Set root to null to reset the expression if there is ont currently.
            this.root = null;

            // Convert the expression to a character array.
            char[] expressionArray = expression.ToCharArray();

            // Check to see if the expression at least length > 1. If it didn't, return.
            if (expressionArray.Length == 0)
            {
                return false;
            }

            // Count parenthesis .
            int leftParenthesisCount = 0;
            int rightParenthesisCount = 0;
            for (int i = 0; i < expressionArray.Length; i++)
            {
                if (expressionArray[i] == '(')
                {
                    leftParenthesisCount++;
                }
                else if (expressionArray[i] == ')')
                {
                    rightParenthesisCount++;
                }
            }

            // Verify left and right braces are equal. If not, throw.
            if (leftParenthesisCount != rightParenthesisCount)
            {
                throw new Exception("Unequal amount of parenthesis");
            }

            // Separate things that aren't operators into tokens. These will become leaves of type either variable or number.
            char[] validSplitters = new char[] { '+', '-', '*', '/', '(', ')' };
            string[] leafTokens = expression.Split(validSplitters);
            string[] expressionTokens = new string[leafTokens.Length * 2];

            // Insert operators back into the array as tokens in the order found.
            // i is used to keep track of the expressionArray index, j for expressionTokens index, and k for leafTokens index.
            expressionTokens[0] = leafTokens[0];
            for (int i = 0, j = 1, k = 1; i < expressionArray.Length; i++)
            {
                if ((expressionArray[i] == '+' || expressionArray[i] == '-') || ((expressionArray[i] == '*' || expressionArray[i] == '/') || (expressionArray[i] == '(' || expressionArray[i] == ')')))
                {
                    // If an operator is found, add the operator in as a string and increment the expressionTokens index. Then
                    // add the next leafToken and increment both the leafTokens index and expressionTokens index.
                    expressionTokens[j] = expressionArray[i].ToString();
                    j++;
                    expressionTokens[j] = leafTokens[k];
                    j++;
                    k++;
                }
            }

            // If there is only 1 token, insert it into the root. Otherwise, create a tree.
            if (expressionTokens.Length == 1)
            {
                this.root = this.CreateNode(expression);
                return true;
            }
            else
            {
                // Add all tokens as ExpressionTreeNodes into a list.
                List<ExpressionTreeNode> tokenNodes = new List<ExpressionTreeNode>();
                ExpressionTreeNode? newNode;
                for (int i = 0; i < expressionTokens.Length - 1; i++)
                {
                    newNode = this.CreateNode(expressionTokens[i]);
                    if (newNode != null)
                    {
                        tokenNodes.Add(newNode);
                    }
                }

                // Set root to the compiled list.
                this.root = this.CompileNodeList(tokenNodes);
                return true;
            }
        }

        /// <summary>
        ///  A helper function for evaluate. Recursively calls itself to evaluate the current expression tree.
        /// </summary>
        /// <param name="node">
        ///  Node to be evaluated.
        /// </param>
        /// <returns>
        ///  Value of the node or the equation it represents.
        /// </returns>
        private double EvaluateHelper(ExpressionTreeNode node)
        {
            // If the node is null, return 0.
            if (node == null)
            {
                return 0;
            }

            // If we are in a leaf, return the value associated with the leaf. Variable node looks up its value in the dictionary.
            if (node.GetType() == typeof(ExpressionTreeNumberNode))
            {
                return Convert.ToDouble(node.Name);
            }
            else if (node.GetType() == typeof(ExpressionTreeVariableNode))
            {
                double nodeValue = 0;
                if (node.Name != null)
                {
                    if (this.variableDictionary.TryGetValue(node.Name, out nodeValue) == true)
                    {
                        return nodeValue;
                    }
                    else
                    {
                        return 0;
                    }
                }

                return 0;
            }

            // If not a leaf, then the node must be an operator. Evaluate the operation the node's children to get an answer to return.
            else
            {
                if (node.GetType() == typeof(ExpressionTreeOperatorNode))
                {
                    ExpressionTreeOperatorNode evaluationNode = (ExpressionTreeOperatorNode)node;

                    // Throw if the children nodes are empty
                    if (evaluationNode.Left == null || evaluationNode.Right == null)
                    {
                        throw new Exception("Invalid operator node used (Children were evaluated to be null)");
                    }

                    // Evaluate the node depending on the operator
                    switch (evaluationNode.OperatorType)
                    {
                        case 0:
                            return this.EvaluateHelper(evaluationNode.Left) + this.EvaluateHelper(evaluationNode.Right);
                        case 1:
                            return this.EvaluateHelper(evaluationNode.Left) - this.EvaluateHelper(evaluationNode.Right);
                        case 2:
                            return this.EvaluateHelper(evaluationNode.Left) * this.EvaluateHelper(evaluationNode.Right);
                        case 3:
                            return this.EvaluateHelper(evaluationNode.Left) / this.EvaluateHelper(evaluationNode.Right);
                        default:
                            throw new Exception("Invalid operator node used (Operatortype was not one of the default types)");
                    }
                }
                else
                {
                    // If the type of the node isn't one of the three we have, then throw an exception.
                    throw new Exception("Invalid node type evaluated");
                }
            }
        }

        /// <summary>
        ///  Compiles the list of nodes into a tree and returns the root of the tree.
        ///  Compiles in this order from the bottom up, variables/numbers, / or * operators, + or - operators.
        ///  *** It happens in this order since the tree evaluates upwards, so order of operations, we want to evaluate the numbers, then
        ///  divisiona nd multiplication and then finally addition and subtraction.
        /// </summary>
        /// <param name="newList">
        ///  List to be decomposed into a tree.
        /// </param>
        /// <returns>
        ///  Expression tree node root.
        /// </returns>
        /// <exception cref="Exception">
        ///  If the expression is invalid, then this exception will be thrown.
        /// </exception>
        private ExpressionTreeNode? CompileNodeList(List<ExpressionTreeNode> newList)
        {
            // Base case, only 1 item in the list or if list is null.
            if (newList.Count == 0)
            {
                return null;
            }
            else if (newList.Count == 1)
            {
                return newList.Last();
            }

            // Make list tokens based on operations. Makes '*' and '/' tokens first, then '+' and '-'. Traverse backwards.
            // In the case of parenthesis, compile again and return an evaluated subtree without parenthesis
            else
            {
                // Remove unecessary null tokens
                for (int i = 0; i < newList.Count; i++)
                {
                    if (newList[i].Name == string.Empty)
                    {
                        newList.Remove(newList[i]);
                    }
                }

                // Create parenthesis pair array to keep track of where parenthesis are
                // Formatted <parenthesisNumber, index>
                Dictionary<int, int> leftParenthesisDictionary = new Dictionary<int, int>();
                Dictionary<int, int> rightParenthesisDictionary = new Dictionary<int, int>();
                leftParenthesisDictionary.Clear();
                rightParenthesisDictionary.Clear();
                int parenthesisIndex = 0;
                for (int i = 0; i < newList.Count; i++)
                {
                    if (newList[i].Name == "(")
                    {
                        if (leftParenthesisDictionary.ContainsKey(parenthesisIndex))
                        {
                            // Mark the next key to check as parenthesisIndex + 1
                            int j = parenthesisIndex + 1;

                            // Iterate to the next unoccupied key
                            for (; leftParenthesisDictionary.ContainsKey(j) != true; j++)
                            {
                            }

                            // Insert the new key at the unoccupied position with value=0
                            leftParenthesisDictionary.Add(j, i);
                            rightParenthesisDictionary.Add(j, 0);
                        }
                        else
                        {
                            // Insert value at current key
                            leftParenthesisDictionary.Add(parenthesisIndex, i);
                            rightParenthesisDictionary.Add(parenthesisIndex, 0);
                            parenthesisIndex++;
                        }
                    }
                    else if (newList[i].Name == ")")
                    {
                        // Key is occupied, look for next available, which is where the next parenthesis should be
                        if (rightParenthesisDictionary.ContainsKey(parenthesisIndex) != true)
                        {
                            // Mark the next key to check as parenthesisIndex + 1
                            int j = parenthesisIndex - 1;

                            // Iterate to the next 0 key
                            for (; rightParenthesisDictionary[j] != 0; j--)
                            {
                            }

                            // Insert the new value at the key
                            rightParenthesisDictionary[j] = i;

                            if (rightParenthesisDictionary[j] <= leftParenthesisDictionary[j] + 1)
                            {
                                throw new Exception("Invalid parenthesis pairs used");
                            }
                        }
                        else
                        {
                            // Insert value at current key
                            rightParenthesisDictionary[parenthesisIndex] = i;
                            parenthesisIndex--;

                            if (rightParenthesisDictionary[parenthesisIndex] <= leftParenthesisDictionary[parenthesisIndex] + 1)
                            {
                                throw new Exception("Invalid parenthesis pairs used");
                            }
                        }
                    }
                }

                // If parenthesis are found, then we need to process them into an understandable list.
                if (rightParenthesisDictionary.Count > 0 && leftParenthesisDictionary.Count > 0)
                {
                    // Print out all parenthesis tokens
                    Console.WriteLine("{0} {1}", leftParenthesisDictionary.Count, rightParenthesisDictionary.Count);
                    for (int i = 0; i < rightParenthesisDictionary.Count && i < leftParenthesisDictionary.Count; i++)
                    {
                        Console.WriteLine("Parenthesis token {0}", i);
                        for (int j = leftParenthesisDictionary[i] + 1; j < rightParenthesisDictionary[i]; j++)
                        {
                            if (newList[j].Name != string.Empty)
                            {
                                Console.Write("<{0}> ", newList[j].Name);
                            }
                        }

                        Console.WriteLine(string.Empty);
                    }

                    // Once we've found the parenthesis tokens, we need to compile them in order and then insert them into a new list to compile.
                    // This keeps the meaning of the parenthesis nodes.
                    List<ExpressionTreeNode> updatedList = new List<ExpressionTreeNode>();
                    List<ExpressionTreeNode> parenthesisTokenList = new List<ExpressionTreeNode>();
                    updatedList.Clear();
                    parenthesisTokenList.Clear();
                    ExpressionTreeNode? parenthesisNode = null;
                    for (int i = 0; i < newList.Count; i++)
                    {
                        // Look in dictionary for parenthesis pairs and where the index
                        for (int j = 0; j < leftParenthesisDictionary.Count; j++)
                        {
                            // If we find an index of a parenthesis, compile the parenthesis node and insert it into the list. Advance i afterwards.
                            if (leftParenthesisDictionary[j] == i)
                            {
                                parenthesisTokenList.Clear();

                                // Add tokens inside of parenthsis into a list, then compile the list and continue.
                                for (int k = i + 1; k < rightParenthesisDictionary[j]; k++)
                                {
                                    parenthesisTokenList.Add(newList[k]);
                                }

                                parenthesisNode = this.CompileNodeList(parenthesisTokenList);

                                // If the compilation was successful, add the new node into the new list to be compiled. Advance i to be just beyond the parenthesis just processed.
                                /*
                                 * The IsParenthesisToken bool value in this tree makes the tree evaluate the node differently. In the case of a parenthesis token, the
                                 * returned node may be any of the three types available. We want the parenthesis token to be evaluated similarly to if it was a variable or constant, meaning that the left and right
                                 * children cannot be changed after it is compiled. With this in mind, we want to make sure the compile function knows not to do this. We mark the
                                 * nodes created from parenthesis tokens with the bool IsParenthesisToken being true. This way, it will be treated as if it were a single node in compilation and
                                 * no members will be overriden. You can see this below in the for loops for the operators.
                                 */
                                if (parenthesisNode != null)
                                {
                                    parenthesisNode.IsParenthesisToken = true;
                                    updatedList.Add(parenthesisNode);
                                    i = rightParenthesisDictionary[j] + 1;
                                }
                            }
                        }

                        // Add next member of list into updatedList if it's still within the allowable index.
                        if (i < newList.Count)
                        {
                            updatedList.Add(newList[i]);
                        }
                    }

                    // After the parenthesis tokens are processed and inserted, we compile the new list and return it.
                    return this.CompileNodeList(updatedList);
                }

                // If a '+' or '-' is found, make lists and CompileThem.
                for (int i = newList.Count - 1; i >= 0; i--)
                {
                    // If the addition or subtraction operators were found, create a node to match it, then create a list to the left and right
                    // of the found value and set the left and right of this new node to the result of the recursion of this function.
                    if ((newList[i].Name == "+" || newList[i].Name == "-") && newList[i].IsParenthesisToken == false)
                    {
                        List<ExpressionTreeNode> leftList = new List<ExpressionTreeNode>();
                        leftList.Clear();
                        List<ExpressionTreeNode> rightList = new List<ExpressionTreeNode>();
                        rightList.Clear();

                        // Compile left tokens from beginning of list to operator
                        for (int j = 0; j < i; j++)
                        {
                            leftList.Add(newList[j]);
                        }

                        // Compile right tokens from operator to end of list.
                        for (int j = i + 1; j < newList.Count; j++)
                        {
                            rightList.Add(newList[j]);
                        }

                        // Add left side to operatorNode
                        newList[i].Left = this.CompileNodeList(leftList);
                        newList[i].Right = this.CompileNodeList(rightList);

                        // Return node after tokens have been added.
                        return newList[i];
                    }
                }

                // If a '*' or '/' is found, make lists and CompileThem
                for (int i = newList.Count - 1; i >= 0; i--)
                {
                    // If the division or multiplication operators were found, create a node to match it, then create a list to the left and right
                    // of the found value and set the left and right of this new node to the result of the recursion of this function.
                    if ((newList[i].Name == "/" || newList[i].Name == "*") && newList[i].IsParenthesisToken == false)
                    {
                        List<ExpressionTreeNode> leftList = new List<ExpressionTreeNode>();
                        leftList.Clear();
                        List<ExpressionTreeNode> rightList = new List<ExpressionTreeNode>();
                        rightList.Clear();

                        // Compile left tokens from beginning of list to operator
                        for (int j = 0; j < i; j++)
                        {
                            leftList.Add(newList[j]);
                        }

                        // Compile right tokens from operator to end of list.
                        for (int j = i + 1; j < newList.Count; j++)
                        {
                            rightList.Add(newList[j]);
                        }

                        // Add left side to operatorNode
                        newList[i].Left = this.CompileNodeList(leftList);
                        newList[i].Right = this.CompileNodeList(rightList);

                        // Return node after tokens have been added.
                        return newList[i];
                    }
                }

                // Code shouldn't reach this point. If it does, throw an error.
                throw new Exception("Invalid list passed into CompileNodeList");
            }
        }

        /// <summary>
        ///  Creates a node based on the inputted name..
        /// </summary>
        /// <param name="nodeName">
        ///  Name of the node to be created.
        /// </param>
        /// <returns>
        ///  The newly created node is returned. The node is upcasted from it's child.
        /// </returns>
        private ExpressionTreeNode? CreateNode(string nodeName)
        {
            // Holders for new node. Assigned to one of them if the algorithm finds it is that type.
            ExpressionTreeOperatorNode? newOperatorNode = null;
            ExpressionTreeNumberNode? newNumberNode = null;
            ExpressionTreeVariableNode? newVariableNode = null;

            // Represents the type of node nodeName is. 0 = Operator, 1 = Numerical, 2 = Variable.
            int nodeType = -1;

            // Used for evaluating if the node is an operator.
            ExpressionTreeOperatorNodeFactory operatorFactory = new ExpressionTreeOperatorNodeFactory();

            // Attempt to create an operator node from the factory
            newOperatorNode = operatorFactory.CreateOperatorNode(nodeName);

            // If successful, nodeType = 0;
            if (newOperatorNode != null)
            {
                nodeType = 0;
            }

            // If the string wasn't assigned to 0, check to see if it's numerical.
            if (nodeType == -1)
            {
                // If the string is equivalent to 0, assign it to be numerical with value 0.
                if (nodeName == "0" || nodeName == "0.0")
                {
                    nodeType = 1;
                    newNumberNode = new ExpressionTreeNumberNode(nodeName);
                }
                else if (this.IsDouble(nodeName) || this.IsInt(nodeName))
                {
                    nodeType = 1;
                    newNumberNode = new ExpressionTreeNumberNode(nodeName);
                }
            }

            // If the string still isn't assigned, it must be a variable. It also must not be an integer or double so we can safely call it node of type variable
            if (nodeType == -1)
            {
                nodeType = 2;
                newVariableNode = new ExpressionTreeVariableNode(nodeName);

                // Set variable in tree dictionary. Default value is 0.
                this.SetVariable(nodeName, 0);
            }

            // Return depending on node type.
            switch (nodeType)
            {
                case 0:
                    return newOperatorNode;
                case 1:
                    return newNumberNode;
                case 2:
                    return newVariableNode;
                default:
                    return null;
            }
        }

        /// <summary>
        ///  Used in node evaluation for determining if a nodeName is numerical.
        /// </summary>
        /// <param name="testString">
        ///  String to be tested for if it is a double.
        /// </param>
        /// <returns>
        ///  Returns true if the inputted string is a double and false if it isn't.
        /// </returns>
        private bool IsDouble(string? testString)
        {
            double holder;
            return double.TryParse(testString, out holder);
        }

        /// <summary>
        ///  Used in node evaluation for determining if a nodeName is numerical.
        /// </summary>
        /// <param name="testString">
        ///  String to be tested for if it is an integer.
        /// </param>
        /// <returns>
        ///  Returns true if the inputted string is an integer and false if it isn't.
        /// </returns>
        private bool IsInt(string? testString)
        {
            int holder;
            return int.TryParse(testString, out holder);
        }
    }
}
