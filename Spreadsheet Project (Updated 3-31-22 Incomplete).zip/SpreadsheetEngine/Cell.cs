﻿// <copyright file="Cell.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    /// <summary>
    ///  Generic cell with row and column.
    /// </summary>
    public abstract class Cell : INotifyPropertyChanged
    {
        /// <summary>
        ///  Used between all cells to determine a chain of references. If there is a cell that references a cell that references a cell, the lock will be set to 1 while the first reference resolves and then 0 afterwards within the 
        ///  UpdateCellInformation event. Used for handling multiple references.
        /// </summary>
        private static int ReferenceLock = 0;

        // According to homework, variables should promote encapsulation so they should be protected instead of private.
        // Warning is suppressed because of this.
        // Page 4 of 9 "So make sure that the member variable is marked as protected. "
#pragma warning disable SA1401 // Fields should be private
        /// <summary>
        ///  Row index of cell.
        /// </summary>
        protected int rowIndex;

        /// <summary>
        ///  Column index of cell.
        /// </summary>
        protected int columnIndex;

        /// <summary>
        ///  Value is either Text or a formula evaluation.
        /// </summary>
        protected string? value;

        /// <summary>
        ///  Text associated with cell.
        /// </summary>
        protected string? text;
#pragma warning restore SA1401 // Fields should be private

        /// <summary>
        /// Initializes a new instance of the <see cref="Cell"/> class.
        /// </summary>
        /// <param name="newRowIndex">
        ///  Assigned rowIndex from constructor.
        /// </param>
        /// <param name="newColumnIndex">
        ///  Assigned columnIndex from constructor.
        /// </param>
        /// <param name="newText">
        ///  Used to initialize text as newText.
        /// </param>
        // public Cell(int newRowIndex, int newColumnIndex, string newText)
        // {
        //    this.rowIndex = newRowIndex;
        //    this.columnIndex = newColumnIndex;
        //    this.text = newText;
        //    this.value = newText;
        //    this.PropertyChanged = null;
        // }

        /// <summary>
        /// Used for determining when something is changes in cell.
        /// </summary>
        public event PropertyChangedEventHandler? PropertyChanged = (sender, e) => { };

        /// <summary>
        ///  Gets function for rowIndex. rowIndex is read only.
        /// </summary>
        public int RowIndex
        {
            get { return this.rowIndex; }
        }

        /// <summary>
        ///  Gets function for columnIndex. columnIndex is read only.
        /// </summary>
        public int ColumnIndex
        {
            get { return this.columnIndex; }
        }

        /// <summary>
        ///  Gets or Sets function for text protected member.
        /// </summary>
        public string? Text
        {
            get
            {
                return this.text;
            }

            set
            {
                // If the value is the same, ignore.
                if (value == this.text)
                {
                    return;
                }
                else
                {
                    this.text = value;
                    this.value = value;
                    this.NotifyPropertyChanged(this.RowIndex.ToString() + "," + this.ColumnIndex.ToString());
               }
            }
        }

        /// <summary>
        ///  Gets or sets function for value.
        /// </summary>
        public string? Value
        {
            get
            {
                return this.value; 
            }

            set
            {
                this.value = value;
            }
        }

        /// <summary>
        /// Sends a propertychanged argument when text is changed.
        /// </summary>
        /// <param name="propertyName">
        /// Name of property changed that triggered the event.
        /// </param>
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Sets the text equal to itself and triggers a property changed event.
        /// </summary>
        /// <param name="sender">
        /// Object that sent the event.
        /// </param>
        /// <param name="e">
        /// Event arguents.
        /// </param>
        public void UpdateCellInformation(object? sender, EventArgs e)
        {
            if (ReferenceLock == 0)
            {
                ReferenceLock++;
                this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));
                ReferenceLock--;
                this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));
            }
        }
    }
}