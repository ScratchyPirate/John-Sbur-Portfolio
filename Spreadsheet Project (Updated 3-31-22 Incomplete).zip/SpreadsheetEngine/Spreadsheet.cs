﻿// <copyright file="Spreadsheet.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Spreadsheet class for homework 4. Stores spreadsheet information in a 2D array of Cell classes.
    /// </summary>
    internal class Spreadsheet
    {
        /// <summary>
        ///  2D array container for all cells in our spreadsheet.
        /// </summary>
        private SpreadsheetCell[,] cellArray;

        /// <summary>
        /// Initializes a new instance of the <see cref="Spreadsheet"/> class with numberOfRows x numberOfColumns as the dimensions.
        /// </summary>
        /// <param name="numberOfRows">
        ///  How big in the y direction the array is.
        /// </param>
        /// <param name="numberOfColumns">
        ///  How big in the x direction the array is.
        /// </param>
        public Spreadsheet(int numberOfRows, int numberOfColumns)
        {
            // set number of Rows to 1 if inputted rows < 1;
            if (numberOfRows < 1)
            {
                numberOfRows = 1;
            }

            // set number of Columns to 1 if inputted columns < 1;
            if (numberOfColumns < 1)
            {
                numberOfColumns = 1;
            }

            this.cellArray = new SpreadsheetCell[numberOfRows, numberOfColumns];

            SpreadsheetCell[,] arrayHolder = this.CellArray;
            SpreadsheetCell newCell;

            // Populate array with new cells.
            for (int i = 0; i < numberOfRows; i++)
            {
                for (int j = 0; j < numberOfColumns; j++)
                {
                    newCell = new SpreadsheetCell(i, j, string.Empty);
                    arrayHolder[i, j] = newCell;
                }
            }

            // Subscribe to all cells
            this.SubscribeToAllCellChangeEvents();

            // Assign cellArray the new edited array.
            this.CellArray = arrayHolder;
        }

        /// <summary>
        ///  Helped event that invokes upon the CellPropertyChanged event evoking.
        /// </summary>
        public event PropertyChangedEventHandler? CellPropertyChangedEventHandler = (sender, e) => { };

        /// <summary>
        ///  Gets or Sets cell array. Used for accessing, modifying, and assigning cellArray.
        /// </summary>
        public SpreadsheetCell[,] CellArray
        {
            get { return this.cellArray; }
            set { this.cellArray = value; }
        }

        /// <summary>
        ///  Gets or Sets rowcount of array. Resizes on Sets.
        /// </summary>
        public int RowCount
        {
            get
            {
                return this.cellArray.GetLength(0);
            }

            set
            {
                this.Resize(value, this.cellArray.GetLength(1));
            }
        }

        /// <summary>
        ///   Gets or Sets columncount of array. Resizes on Sets.
        /// </summary>
        public int ColumnCount
        {
            get
            {
                return this.cellArray.GetLength(1);
            }

            set
            {
                this.Resize(this.cellArray.GetLength(0), value);
            }
        }

        /// <summary>
        ///  Returns requested cell at row and column. Returns null if out of bounds.
        /// </summary>
        /// <param name="rowIndex">
        ///  Row of target cell.
        /// </param>
        /// <param name="columnIndex">
        ///  Column of target cell.
        /// </param>
        /// <returns>
        ///  Returns abstract cell type of cell found.
        /// </returns>
        public Cell? GetCell(int rowIndex, int columnIndex)
        {
            if ((rowIndex >= 0 && rowIndex < this.cellArray.GetLength(0)) && (columnIndex >= 0 && columnIndex < this.cellArray.GetLength(1)))
            {
                return this.cellArray[rowIndex, columnIndex];
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        ///  Resizes the array according to inputed elements. Fails if resizing elements are smaller than current elements.
        /// </summary>
        /// <param name="newRowMax">
        ///  New row bound to be assigned.
        /// </param>
        /// <param name="newColumnMax">
        ///  New column bound to be assigned.
        /// </param>
        /// <returns>
        ///  1 if successful. 0 if fails.
        /// </returns>
        public int Resize(int newRowMax, int newColumnMax)
        {
            // If the new bounds are less than or equal to the current bounds, fail and return 0;
            if (newRowMax <= this.cellArray.GetLength(0) || newColumnMax <= this.cellArray.GetLength(1))
            {
                return 0;
            }

            // Store array, resize array, assign old cells in old array to new cells in new array, return 1.
            SpreadsheetCell[,] arrayHolder = this.CellArray;
            SpreadsheetCell[,] newArray = new SpreadsheetCell[newRowMax, newColumnMax];

            int oldRowBounds = this.cellArray.GetLength(0);
            int oldColumnBounds = this.cellArray.GetLength(1);
            SpreadsheetCell insertCell = new SpreadsheetCell(0, 0, string.Empty);

            for (int i = 0; i < newRowMax; i++)
            {
                for (int j = 0; j < newColumnMax; j++)
                {
                    // If this index exists in the old array, set the new cell to the old cell at this index.
                    if (i < oldRowBounds && j < oldColumnBounds)
                    {
                        insertCell = new SpreadsheetCell(i, j, arrayHolder[i, j].Text);
                    }
                    else
                    {
                        insertCell = new SpreadsheetCell(i, j, string.Empty);
                    }

                    newArray[i, j] = insertCell;
                }
            }

            // Assign resized array to new array.
            this.CellArray = newArray;

            // Resubscribe to all cells
            this.SubscribeToAllCellChangeEvents();

            return 1;
        }

        /// <summary>
        ///  Sets the text information of the cell if the cell exists in the array.
        /// </summary>
        /// <param name="targetRow">
        ///  row of cell to be modified.
        /// </param>
        /// <param name="targetColumn">
        ///  column of cell to be modified.
        /// </param>
        /// <param name="replacementText">
        ///  text to replace old text in modified cell.
        /// </param>
        public void SetCellText(int targetRow, int targetColumn, string replacementText)
        {
            SpreadsheetCell[,] arrayHolder = this.CellArray;

            // If the requested cell is within bounds, set the text of that cell. Otherwise, return.
            if ((targetRow < arrayHolder.GetLength(0) && targetRow >= 0) && (targetColumn < arrayHolder.GetLength(1) && targetColumn >= 0))
            {
                arrayHolder[targetRow, targetColumn].Text = replacementText;
                this.cellArray = arrayHolder;

                // Resubscribe to all cells
                this.SubscribeToAllCellChangeEvents();

                return;
            }
            else
            {
                return;
            }
        }

        /// <summary>
        ///  Sets the value information of the cell if the cell exists in the array.
        /// </summary>
        /// <param name="targetRow">
        ///  row of cell to be modified.
        /// </param>
        /// <param name="targetColumn">
        ///  column of cell to be modified.
        /// </param>
        /// <param name="replacementValue">
        ///  text to replace old value in modified cell.
        /// </param>
        public void SetCellValue(int targetRow, int targetColumn, string replacementValue)
        {
            SpreadsheetCell[,] arrayHolder = this.CellArray;

            // If the requested cell is within bounds, set the text of that cell. Otherwise, return.
            if ((targetRow < arrayHolder.GetLength(0) && targetRow >= 0) && (targetColumn < arrayHolder.GetLength(1) && targetColumn >= 0))
            {
                arrayHolder[targetRow, targetColumn].Value = replacementValue;
                this.cellArray = arrayHolder;

                // Resubscribe to all cells
                this.SubscribeToAllCellChangeEvents();

                return;
            }
            else
            {
                return;
            }
        }

        /// <summary>
        ///  Prints the array to the designated outputWriter.
        /// </summary>
        /// <param name="outputWriter">
        ///  TextWriter designated as output.
        /// </param>
        /// <returns>
        ///  1 upon completion.
        /// </returns>
        public int PrintCellArray(TextWriter outputWriter)
        {
            SpreadsheetCell[,] arrayHolder = this.CellArray;

            for (int i = 0; i < arrayHolder.GetLength(0); i++)
            {
                // Print formatted contents of each cell in a row. Format: <[rowIndex, columnIndex]cellText>\t
                for (int j = 0; j < arrayHolder.GetLength(1); j++)
                {
                    outputWriter.Write("<[" + i.ToString() + "," + j.ToString() + "]" + arrayHolder[i, j].Text + ">\t");
                }

                // Make a new line at the end of each row.
                outputWriter.Write(Environment.NewLine);
            }

            return 1;
        }

        /// <summary>
        ///  Subscriber event for each cell. Activates when cell is changed.
        /// </summary>
        /// <param name="sender">
        ///  Object that sent the event.
        /// </param>
        /// <param name="e">
        ///  Formatted "Cell.RowIndex,Cell.columnIndex".
        /// </param>
        public void CellPropertyChanged(object? sender, EventArgs e)
        {
            // If the sender is null, return.
            if (sender == null)
            {
                return;
            }

            // if sender is of type SpreadsheetCell, convert Value. Otherwise, return.
            if (sender.GetType() == typeof(SpreadsheetCell) && (sender != null))
            {
                // Explicit conversion so we can access methods from SpreadsheetCell.
                SpreadsheetCell senderCell = (SpreadsheetCell)sender;

                int rowValue = senderCell.RowIndex;
                int columnValue = senderCell.ColumnIndex;

                SpreadsheetCell targetCell = this.cellArray[rowValue, columnValue];

                // Make sure text exists in cell text.
                if (targetCell.Text != null)
                {
                    string textHolder = targetCell.Text;
                    char[] charTextHolder = textHolder.ToCharArray();

                    // If the string wasn't loaded in or was empty, return;
                    if (charTextHolder.Length == 0)
                    {
                        return;
                    }

                    // If the first member of charTextHolder is =, evaluate. Otherwise, return.
                    if (charTextHolder[0] == '=')
                    {
                       // Expression tree part. Try to turn the part after '=' into an expression while entering variables as needed for the variable dictionary.
                        var expressionCharStorage = from c in charTextHolder
                               where c != '=' && c != ' '
                                select c;
                        string expression = new string(string.Empty);

                        // Store each non '=' char from the text into the expression string.
                        foreach (char c in expressionCharStorage)
                        {
                            expression += c.ToString();
                        }

                        // Attempt to create an expression tree. If it fails, exit out of the function and leave the text as is.
                        ExpressionTree expressionTree;
                        try
                        {
                            expressionTree = new ExpressionTree(expression);
                        }
                        catch
                        {
                            Console.WriteLine("Expression compile failed.");
                            return;
                        }

                        // Get all variables stored in an array.
                        // Fixing the spacing leads to another warning which asks to revert the spacing back. Resolution not possible.
#pragma warning disable SA1011 // Closing square brackets should be spaced correctly
                        string[]? expressionVariables = expressionTree.ListAllVariables();
#pragma warning restore SA1011 // Closing square brackets should be spaced correctly

                        // For each variable in the array, attempt to set the variable to the grid element corresponding to it. Runs only if variables are present.
                        if (expressionVariables != null)
                        {
                            foreach (string variable in expressionVariables)
                            {
                                // Store variable in a char array.
                                char[] variableArray = variable.ToCharArray();

                                // Used if the text is a value of another cell.
                                int sourceCellColumn = (int)(variableArray[0] - 65);

                                // If the first char is a letter, continue evaluation.
                                // text of that cell.
                                if (sourceCellColumn >= 0 && sourceCellColumn <= 26)
                                {
                                    char[] digits = { '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' };
                                    int numberOfDigits = 0;
                                    int sourceCellRow = 0;

                                    for (int i = 1, j = 0; i != variableArray.Length && i < 10; i++, j++)
                                    {
                                        digits[j] = variableArray[i];
                                        numberOfDigits++;
                                    }

                                    // Store target number in sourceCellColumn.
                                    for (int i = 0; numberOfDigits > 0 && i < 10; numberOfDigits--, i++)
                                    {
                                        sourceCellRow += ((int)digits[i] - 48) * Convert.ToInt32(Math.Pow(10, numberOfDigits - 1));
                                    }

                                    sourceCellRow--;

                                    // Get cell at that location and it's text. If successful and it's a double, set the variable to be that double.
                                    SpreadsheetCell? sourceCell = (SpreadsheetCell?)this.GetCell(sourceCellRow, sourceCellColumn);
                                    if (sourceCell != null)
                                    {
                                        if (sourceCell.Value != null)
                                        {
                                            // Throws when circular reference occurs.
                                            if (sourceCellColumn == columnValue && sourceCellRow == rowValue)
                                            {
                                                throw new Exception("Variable expression contains circular reference");
                                            }

                                            double valueHolder = 0.0;
                                            if (double.TryParse(sourceCell.Value, out valueHolder))
                                            {
                                                // Change the property of the cell.
                                                expressionTree.SetVariable(variable, Convert.ToDouble(sourceCell.Value));

                                                // Add a delegate function that updates the text of this cell (targetCell) that references this variable cell (sourceCell)
                                                // Fires whenever a property is changed in variableCell.
                                                sourceCell.PropertyChanged += targetCell.UpdateCellInformation;

                                                this.CellArray[sourceCellRow, sourceCellColumn] = sourceCell;
                                                this.CellArray[rowValue, columnValue] = targetCell;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        // If a variable is found that is not a cell, return here and do not edit the value. Expression is invalid.
                                        throw new Exception("Variable found wasn't a cell");
                                    }
                                }
                                else
                                {
                                    // If a variable is found that is not a cell, return here and do not edit the value. Expression is invalid.
                                    throw new Exception("Variable found wasn't a cell");
                                }
                            }
                        }

                        // Attempt to evaluate the expression tree. If it fails, exit out of the function and leave the text as it.
                        double result = 0.0;
                        try
                        {
                            result = expressionTree.Evaluate();
                        }
                        catch
                        {
                            Console.WriteLine("Expression evaluate failed.");
                            return;
                        }

                        // if we are at this point, set value to result.
                        // Change the property of the cell.
                        this.SetCellValue(rowValue, columnValue, result.ToString());
                    }
                    else
                    {
                        // Do nothing right now. No = format detected at this point.
                        // Cell value changes only if = is the first symbol in the Text.
                    }
                }

                // Evoke to let the outside world know the property changed.
                this.CellPropertyChangedEventHandler?.Invoke(sender, new PropertyChangedEventArgs("CellPropertyChangedEvent"));
            }
            else
            {
            }
        }

        /// <summary>
        ///  Function used to look at all cells in array and subscribe to the PropertyChanged event
        ///  in each cell.
        /// </summary>
        private void SubscribeToAllCellChangeEvents()
        {
            // Unsubscribe from events if they exist already, then subscribe to all events
            for (int i = 0; i < this.cellArray.GetLength(0); i++)
            {
                for (int j = 0; j < this.cellArray.GetLength(1); j++)
                {
                    // Unsubscribe from this event. (Returns null if not found)
                    this.cellArray[i, j].PropertyChanged -= this.CellPropertyChanged;

                    // Subscribe to event (so only one instance of it exists)
                    this.cellArray[i, j].PropertyChanged += this.CellPropertyChanged;
                }
            }
        }
    }
}
