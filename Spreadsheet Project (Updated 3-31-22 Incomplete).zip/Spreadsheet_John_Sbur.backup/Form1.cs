﻿// <copyright file="Form1.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Spreadsheet_John_Sbur
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    /// <summary>
    ///  Main class that holds information, events, and behaviour of the spreadsheet window.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();

            // Resize for easier viewing
            this.Width = 1000;
            this.Height = 1000;

            string holder = " ";

            // Clear existing columns and rows
            this.dataGridView1.Rows.Clear();
            this.dataGridView1.Columns.Clear();

            // Add columns A-Z.
            for (char i = 'A'; i <= 'Z'; i++)
            {
                holder = i.ToString();
                this.AddColumn(holder);
            }

            // Add rows 1-50
            for (int i = 1; i <= 50; i++)
            {
                holder = i.ToString();
                this.AddRow(holder);
            }

            // Resize row headers so multiple digits are seen.
            this.dataGridView1.RowHeadersWidth = 50;
        }

        /// <summary>
        ///  Function used to add columns into the application.
        /// </summary>
        /// <param name="name">
        ///  Used to mark the name of the column to be added.
        /// </param>
        private void AddColumn(string name)
        {
            // Create and name column
            DataGridViewColumn newColumn = new DataGridViewColumn();
            newColumn.Name = name;

            // Create template cell for column to use as default
            DataGridViewCell cellTemplate = new DataGridViewTextBoxCell();
            cellTemplate.Style.BackColor = Color.White;

            // Set column template to cell
            newColumn.CellTemplate = cellTemplate;

            // Insert new column
            this.dataGridView1.Columns.Add(newColumn);
        }

        /// <summary>
        ///  Function used to add rows into the application.
        /// </summary>
        /// <param name="name">
        ///  Name of row to be added.
        /// </param>
        private void AddRow(string name)
        {
            DataGridViewRow newRow = new DataGridViewRow();
            newRow.HeaderCell.Value = name;
            this.dataGridView1.Rows.Add(newRow);
        }
    }
}
