// <copyright file="SpreadsheetTestClass.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Test_Spreadsheet_John_Sbur
{
    using System;
    using System.Runtime.CompilerServices;
    using Cpts321;
    using NUnit.Framework;

    /// <summary>
    ///  Class that runs tests for spreadsheet if needed.
    /// </summary>
    public class SpreadsheetTestClass
    {
        /// <summary>
        ///  Setup for tests if needed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        ///  Tests creation of cell.
        /// </summary>
        /// <param name="rowIndex">
        ///  Row index of testing cell.
        /// </param>
        /// <param name="columnIndex">
        ///  Column index of testing cell.
        /// </param>
        /// <param name="text">
        ///  Text of testing cell.
        /// </param>
        [Test]

        // Normal cases
        [TestCase(1, 1, "test_name")]

        // Boundary cases
        [TestCase(-1, -1, "")]
        public void TestCreateCell(int rowIndex, int columnIndex, string? text)
        {
            SpreadsheetCell testCell = new SpreadsheetCell(rowIndex, columnIndex, text);
            Assert.AreEqual(rowIndex, testCell.RowIndex);
            Assert.AreEqual(columnIndex, testCell.ColumnIndex);
            Assert.AreEqual(text, testCell.Text);
        }

        /// <summary>
        ///  Tests modifying cell class.
        /// </summary>
        /// <param name="text">
        ///  Text of testing cell.
        /// </param>
        [Test]

        // Normal cases.
        [TestCase("test_name")]

        // Boundary cases.
        [TestCase("test")]
        public void TestModifyCell(string? text)
        {
            SpreadsheetCell testCell = new SpreadsheetCell(1, 1, "test");

            testCell.Text = text;
            Assert.AreEqual(testCell.Text, text);
        }

        /// <summary>
        ///  Tests the resizing function of Spreadsheet as well as the get and set functions for rowCount and columnCount.
        /// </summary>
        /// <param name="type">
        ///  Type of test being invoked. 1 = normal, 2 = boundary, 3 = exception if exists.
        /// </param>
        /// <param name="rowBound">
        ///  rowCount of test array.
        /// </param>
        /// <param name="columnBound">
        ///  columnCount of test array.
        /// </param>
        [Test]

        // Normal cases
        [TestCase(1, 10, 10)]

        // Boundary cases
        [TestCase(2, -1, -1)]
        public void TestResizeArray(int type, int rowBound, int columnBound)
        {
            // Normal cases
            if (type == 1)
            {
                Spreadsheet testSpreadsheet = new Spreadsheet(rowBound, columnBound);

                Assert.AreEqual(testSpreadsheet.RowCount, rowBound);
                Assert.AreEqual(testSpreadsheet.ColumnCount, columnBound);

                testSpreadsheet.Resize(rowBound + 1, columnBound + 1);
                Assert.AreEqual(testSpreadsheet.RowCount, rowBound + 1);
                Assert.AreEqual(testSpreadsheet.ColumnCount, columnBound + 1);

                testSpreadsheet.Resize(-1, -1);
                Assert.AreEqual(testSpreadsheet.RowCount, rowBound + 1);
                Assert.AreEqual(testSpreadsheet.ColumnCount, columnBound + 1);
            }

            // Boundary cases
            else if (type == 2)
            {
                Spreadsheet testSpreadsheet = new Spreadsheet(rowBound, columnBound);

                Assert.AreEqual(testSpreadsheet.RowCount, 1);
                Assert.AreEqual(testSpreadsheet.ColumnCount, 1);

                testSpreadsheet.Resize(-1, -1);

                Assert.AreEqual(testSpreadsheet.RowCount, 1);
                Assert.AreEqual(testSpreadsheet.ColumnCount, 1);
            }
        }

        /// <summary>
        ///  Tests if a cell is recieved successfully and modified successfully.
        /// </summary>
        /// <param name="type">
        ///  Type of test being invoked. 1 = normal, 2 = boundary, 3 = exception if exists.
        /// </param>
        /// <param name="rowIndex">
        ///  Row index of testing cell.
        /// </param>
        /// <param name="columnIndex">
        ///  Column index of testing cell.
        /// </param>
        /// <param name="text">
        ///  Text of testing cell.
        /// </param>
        [Test]

        // Normal Cases
        [TestCase(1, 5, 5, "test")]

        // Boundary cases
        [TestCase(2, -1, -1, "test")]
        public void TestModifySpreadsheetCell(int type, int rowIndex, int columnIndex, string text)
        {
            Spreadsheet testSpreadsheet = new Spreadsheet(10, 10);

            // Normal cases
            if (type == 1)
            {
                testSpreadsheet.SetCellText(rowIndex, columnIndex, text);
                SpreadsheetCell? testCell = (SpreadsheetCell?)testSpreadsheet.GetCell(rowIndex, columnIndex);

                // Warning supressed since null will not be returned in the normal case. If it is, the assert will fail.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                Assert.AreEqual(testCell.Text, text);
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            }

            // Boundary cases
            else if (type == 2)
            {
                testSpreadsheet.SetCellText(rowIndex, columnIndex, text);
                Assert.Null(testSpreadsheet.GetCell(rowIndex, columnIndex));
            }
        }

        /// <summary>
        ///  Tests startup and compile functionalities of expression tree.
        /// </summary>
        /// <param name="type">
        ///  Type of test, 1 = normal, 2 = boundary, 3 = exception.
        /// </param>
        /// <param name="expression">
        ///  Expression inputted for test case.
        /// </param>
        /// <param name="exception">
        ///  When the test is an exception test, used to check to see the type of exception.
        /// </param>
        [Test]

        // Normal cases
        [TestCase(1, "1+1")]
        [TestCase(1, "1-1")]
        [TestCase(1, "1*1")]
        [TestCase(1, "1/1")]
        [TestCase(1, "1+1/1")]
        [TestCase(1, "1/1+1")]
        [TestCase(1, "testVariable1+testVariable2")]
        [TestCase(1, "testVariable1+testVariable1")]

        // Boundary cases
        [TestCase(2, "0/0")]

        // Exception cases
        [TestCase(3, "(()", typeof(Exception))]
        [TestCase(3, "(", typeof(Exception))]
        [TestCase(3, "(1+1", typeof(Exception))]
        [TestCase(3, "((1+1)", typeof(Exception))]
        public void TestCompileExpressionTree(int type, string expression, Type? exception = null)
        {
            if (type == 1 || type == 2)
            {
                ExpressionTree testTree = new ExpressionTree(expression);
                Assert.IsTrue(testTree.Compile(expression));
            }
            else
            {
                if (exception != null)
                {
                    Assert.Throws(exception, () => { ExpressionTree testTree = new ExpressionTree(expression); });
                }
                else
                {
                    Assert.Fail();
                }
            }
        }

        /// <summary>
        ///  Tests evaluation of different expression trees.
        /// </summary>
        /// <param name="type">
        ///  Type of test, 1 = normal, 2 = boundary, 3 = exception.
        /// </param>
        /// <param name="expression">
        ///  Expression to be compiled and later evaluated from the tree.
        /// </param>
        /// <param name="expectedValue">
        ///  Expected outcome of the evaluation.
        /// </param>
        /// <param name="exception">
        ///  When the test is an exception test, used to check to see the type of exception.
        /// </param>
        [Test]

        // Normal cases
        [TestCase(1, "1+1", 2)]
        [TestCase(1, "1-1", 0)]
        [TestCase(1, "1*1", 1)]
        [TestCase(1, "1/1", 1)]
        [TestCase(1, "1+1/1", 2)]
        [TestCase(1, "1/1+1", 2)]
        [TestCase(1, "testVariable1+testVariable2", 0)]
        [TestCase(1, "testVariable1+testVariable1", 0)]
        [TestCase(1, "4+34-90/9*7", -32)]

        // Boundary cases
        [TestCase(2, "0/0", double.NaN)]
        [TestCase(2, "", 0)]

        // Exception cases
        [TestCase(3, "/", double.NaN, typeof(Exception))]
        [TestCase(3, "*-", 0, typeof(Exception))]
        [TestCase(3, "+", 0, typeof(Exception))]
        [TestCase(3, "1+", 1, typeof(Exception))]
        [TestCase(3, "-1", -1, typeof(Exception))]

        public void TestEvaluateExpressionTree(int type, string expression, double expectedValue = 0.0, Type? exception = null)
        {
            if (type == 1 || type == 2)
            {
                ExpressionTree testTree = new ExpressionTree(expression);
                Assert.AreEqual(testTree.Evaluate(), expectedValue);
            }
            else
            {
                if (exception != null)
                {
                    ExpressionTree testTree = new ExpressionTree(expression);
                    Assert.Throws(exception, () => { testTree.Evaluate(); });
                }
                else
                {
                    Assert.Fail();
                }
            }
        }

        /// <summary>
        ///  Tests creation of different operator nodes using the operator node factory. Only boundary and normal cases exist as inputs only allow null or
        ///  an expression tree operator node to be returned.
        /// </summary>
        /// <param name="type">
        ///  Type of test. 1 = normal, 2 = boundary.
        /// </param>
        /// <param name="nodeName">
        ///  Name of test operator node.
        /// </param>
        /// <param name="exception">
        ///  Type of exception to be thrown in an exception test case.
        /// </param>
        [Test]

        // Normal cases
        [TestCase(1, "+")]
        [TestCase(1, "-")]
        [TestCase(1, "*")]
        [TestCase(1, "/")]

        // Boundary cases
        [TestCase(2, "Not an opeator")]
        public void TestOperatorNodeFactoryCreate(int type, string nodeName, Type? exception = null)
        {
            // Create factory to use for testing.
            ExpressionTreeOperatorNodeFactory testFactory = new ExpressionTreeOperatorNodeFactory();
            ExpressionTreeOperatorNode? testNode = null;

            // Normal cases
            if (type == 1)
            {
                testNode = testFactory.CreateOperatorNode(nodeName);
                if (testNode != null)
                {
                    Assert.AreEqual(testNode.GetType(), typeof(ExpressionTreeOperatorNode));
                    Assert.AreEqual(testNode.Name, nodeName);
                }
                else
                {
                    Assert.Fail();
                }
            }

            // Boundary cases
            else if (type == 2)
            {
                testNode = testFactory.CreateOperatorNode(nodeName);
                if (testNode == null)
                {
                    Assert.Pass();
                }
                else
                {
                    Assert.Fail();
                }
            }

            // Exception cases
            else if (type == 3 && exception != null)
            {
                Assert.Throws(exception, () => { testNode = testFactory.CreateOperatorNode(nodeName); });
            }

            // Default catch case.
            else
            {
                Assert.Fail();
            }
        }

        /// <summary>
        ///  Tests evaluating expressions with parenthesis in them.
        /// </summary>
        /// <param name="type">
        ///   Type of test. 1 = normal, 2 = boundary, 3 = exception.
        /// </param>
        /// <param name="nodeName">
        ///  Expression to be inserted.
        /// </param>
        /// <param name="expectedResult">
        /// Expected result from evaluation
        /// </param>
        /// <param name="exception">
        ///  Exception type to be thrown during an exception test case.
        /// </param>
        [Test]

        // Normal cases
        [TestCase(1, "(1+1)", 2)]
        [TestCase(1, "(1+(1))", 2)]
        [TestCase(1, "((((((1+1))))))", 2)]
        [TestCase(1, "(2/(1/2))", 4)]
        [TestCase(1, "(1+1)+(2+2)", 6)]

        // Boundary cases

        // Exception cases
        [TestCase(3, "()", 0, typeof(Exception))]
        [TestCase(3, ")(", 0, typeof(System.Collections.Generic.KeyNotFoundException))]
        [TestCase(3, ")1(+)1(", 0, typeof(System.Collections.Generic.KeyNotFoundException))]
        public void TestEvaluateParenthesis(int type, string nodeName, double expectedResult, Type? exception = null)
        {
            ExpressionTree? testTree = null;

            // Normal and boundary cases
            if (type == 1 || type == 2)
            {
                testTree = new ExpressionTree(nodeName);

                Assert.AreEqual(testTree.Evaluate(), expectedResult);
            }

            // Exception cases
            else if (type == 3 && exception != null)
            {
                Assert.Throws(exception, () => { testTree = new ExpressionTree(nodeName); });
            }

            // Catch case default.
            else
            {
                Assert.Fail();
            }
        }

        /// <summary>
        ///  Tests how changing a variable that is referenced by another cell affects that cell.
        /// </summary>
        [Test]
        public void TestReferenceVariableEvaluation()
        {
            Spreadsheet testSpreadsheet = new Spreadsheet(10,10);

            testSpreadsheet.CellArray[0, 0].Text = "10";
            testSpreadsheet.CellArray[0, 1].Text = "=A1";

            Assert.True(testSpreadsheet.CellArray[0, 0].Value == testSpreadsheet.CellArray[0, 1].Value);

            testSpreadsheet.CellArray[0, 0].Text = "11";

            Assert.True(testSpreadsheet.CellArray[0, 0].Value == testSpreadsheet.CellArray[0, 1].Value);

        }
    }
}