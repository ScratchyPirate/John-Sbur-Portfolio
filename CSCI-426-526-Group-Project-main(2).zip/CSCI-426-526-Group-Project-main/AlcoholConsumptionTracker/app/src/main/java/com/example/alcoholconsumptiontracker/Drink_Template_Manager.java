package com.example.alcoholconsumptiontracker;

public class Drink_Template_Manager {
}
