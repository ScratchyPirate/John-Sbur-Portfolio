﻿// <copyright file="Table.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Final_Exam_Test_Project")]
[assembly: InternalsVisibleTo("Cpts_321_Final_Exam")]

namespace FoodEngine
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Table class for this project.
    ///     This class is the Controller for the project.
    ///     This class is the Creator of Container Objects and Filter Objects.
    /// </summary>
    public class Table
    {
        // Fields
        private List<Container> containerList;
        private List<Food> foodList;
        private Filter<Food> activeContainerFilter;
        private Filter<Food> activeFoodFilter;

        /// <summary>
        /// Initializes a new instance of the <see cref="Table"/> class.
        /// </summary>
        public Table()
        {
            // Initialize fields.
            this.containerList = new List<Container>();
            this.containerList.Clear();
            this.foodList = new List<Food>();
            this.foodList.Clear();
            this.activeContainerFilter = new Filter<Food>();
            this.activeContainerFilter.FilterObject = null;
            this.activeFoodFilter = new Filter<Food>();
            this.activeFoodFilter.FilterObject = null;
        }

        // Event handlers designed to invoke whenever its corresponding property is changed

        /// <summary>
        ///  Designed to invoke whenever its corresponding property is changed.
        /// </summary>
        public event PropertyChangedEventHandler ContainerListChanged = (sender, e) => { };

        /// <summary>
        ///  Designed to invoke whenever its corresponding property is changed.
        /// </summary>
        public event PropertyChangedEventHandler FoodListChanged = (sender, e) => { };

        /// <summary>
        ///  Designed to invoke whenever its corresponding property is changed.
        /// </summary>
        public event PropertyChangedEventHandler ActiveContainerFilterChanged = (sender, e) => { };

        /// <summary>
        ///  Designed to invoke whenever its corresponding property is changed.
        /// </summary>
        public event PropertyChangedEventHandler ActiveFoodFilterChanged = (sender, e) => { };

        /// <summary>
        ///  Gets this.foodList.
        /// </summary>
        public List<Food> FoodList
        {
            get { return this.foodList; }
        }

        /// <summary>
        ///  Gets this.containerList.
        /// </summary>
        public List<Container> ContainerList
        {
            get { return this.containerList; }
        }

        /// <summary>
        ///  Gets activeFoodFilter of table.
        /// </summary>
        public Filter<Food> ActiveFoodFilter
        {
            get { return this.activeFoodFilter; }
        }

        /// <summary>
        ///  Gets activeContainerFilter of table.
        /// </summary>
        public Filter<Food> ActiveContainerFilter
        {
            get { return this.activeContainerFilter; }
        }

        /// <summary>
        ///  Notifies when the ContainerList changes.
        /// </summary>
        /// <param name="sender">
        /// Sender.
        /// </param>
        /// <param name="e">
        /// Args e.
        /// </param>
        public void NotifyContainerListChanged(object? sender, PropertyChangedEventArgs e)
        {
            this.ContainerListChanged?.Invoke(this, e);
        }

        /// <summary>
        ///  Notifies when the FoodList changes.
        /// </summary>
        /// <param name="sender">
        /// Sender.
        /// </param>
        /// <param name="e">
        /// Args e.
        /// </param>
        public void NotifyFoodListChanged(object? sender, PropertyChangedEventArgs e)
        {
            this.FoodListChanged?.Invoke(this, e);
        }

        /// <summary>
        ///  Notifies when the ActiveContainerFilter changes.
        /// </summary>
        /// <param name="sender">
        /// Sender.
        /// </param>
        /// <param name="e">
        /// Args e.
        /// </param>
        public void NotifyActiveContainerFilterChanged(object? sender, PropertyChangedEventArgs e)
        {
            this.ActiveContainerFilterChanged?.Invoke(this, e);
        }

        /// <summary>
        ///  Notifies when the ActiveFoodFilter changes.
        /// </summary>
        /// <param name="sender">
        /// Sender.
        /// </param>
        /// <param name="e">
        /// Args e.
        /// </param>
        public void NotifyActiveFoodFilterChanged(object? sender, PropertyChangedEventArgs e)
        {
            this.ActiveFoodFilterChanged?.Invoke(this, e);
        }

        /// <summary>
        /// Changes the active food filter based on the inputted strings. Uses the change filter function.
        /// </summary>
        /// <param name="filterFoodType">
        ///  Filter's Food's type.
        /// </param>
        /// <param name="filterColor">
        /// Filter's Food's color.
        /// </param>
        /// <param name="filterShape">
        /// Filter's Food's shape.
        /// </param>
        /// <param name="filterTexture">
        /// Filter's Food's texture.
        /// </param>
        /// <param name="filterSize">
        /// Filter's Food's size.
        /// </param>
        /// <param name="filterTaste">
        /// Filter's Food's taste.
        /// </param>
        public void ChangeActiveFoodFilter(
            string filterFoodType,
            string? filterColor = null,
            string? filterShape = null,
            string? filterTexture = null,
            string? filterSize = null,
            string? filterTaste = null)
        {
            // Change the food filter
            Food? oldFilterObject = this.activeFoodFilter.FilterObject;
            this.activeFoodFilter = this.ChangeFilter(
                this.activeFoodFilter,
                filterFoodType,
                filterColor,
                filterShape,
                filterTexture,
                filterSize,
                filterTaste);

            // Invoke the change food filter event.
            this.NotifyActiveFoodFilterChanged(this, new PropertyChangedEventArgs("Food Filter Changed"));
        }

        /// <summary>
        /// Changes the active container filter based on the inputted strings. Uses the change filter function.
        /// </summary>
        /// <param name="filterFoodType">
        ///  Filter's Food's type.
        /// </param>
        /// <param name="filterColor">
        /// Filter's Food's color.
        /// </param>
        /// <param name="filterShape">
        /// Filter's Food's shape.
        /// </param>
        /// <param name="filterTexture">
        /// Filter's Food's texture.
        /// </param>
        /// <param name="filterSize">
        /// Filter's Food's size.
        /// </param>
        /// <param name="filterTaste">
        /// Filter's Food's taste.
        /// </param>
        public void ChangeActiveContainerFilter(
            string filterFoodType,
            string? filterColor = null,
            string? filterShape = null,
            string? filterTexture = null,
            string? filterSize = null,
            string? filterTaste = null)
        {
            // Change the food filter
            Food? oldFilterObject = this.activeContainerFilter.FilterObject;
            this.activeContainerFilter = this.ChangeFilter(
                this.activeContainerFilter,
                filterFoodType,
                filterColor,
                filterShape,
                filterTexture,
                filterSize,
                filterTaste);

            // Invoke the change food filter event.
            this.NotifyActiveContainerFilterChanged(this, new PropertyChangedEventArgs("Container Filter Changed"));
        }

        /// <summary>
        ///  Filters each element in the container list and returns the list of containers with an object matching at least one of the properties of filterObject.
        /// </summary>
        /// <returns>
        ///  List of filtered containers.
        /// </returns>
        public List<Container> FilterContainerList()
        {
            // Return list of containers filtered
            List<Container> returnList = new List<Container>();
            returnList.Clear();

            foreach (Container container in this.ContainerList)
            {
                // Get a filtered list from the activeContainerFilter
                List<Food>? filteredList = this.activeContainerFilter.FilterObjects(container.FoodList);

                // If the list isn't null and the size of the list is greater than 0, add this container to the return list.
                if (filteredList != null)
                {
                    if (filteredList.Count > 0)
                    {
                        returnList.Add(container);
                    }
                }
            }

            // Return list when done
            return returnList;
        }

        /// <summary>
        ///  Filters each element in the food list and returns the list of food with an object matching at least one of the properties of filterObject.
        /// </summary>
        /// <returns>
        ///  List of filtered food.
        /// </returns>
        public List<Food> FilterFoodList()
        {
            // Return list of food filtered
            List<Food> returnList = new List<Food>();
            returnList.Clear();

            // Filter foods
            if (this.activeContainerFilter.FilterObjects(this.foodList) != null)
            {
                // Code paths from if statement ensure that returnList will not be set to null since we check for that.
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8603 // Possible null reference return.
                returnList = this.activeContainerFilter.FilterObjects(this.foodList);
            }

            // Return the filtered list
            return returnList;
#pragma warning restore CS8603 // Possible null reference return.
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
        }

        /// <summary>
        ///  Given a name of a container and a type of food, this adds a new container to the list if it can be added.
        /// </summary>
        /// <param name="newName">
        ///  Name of container being created.
        /// </param>
        /// <param name="containerType">
        ///  Type of container being created.
        /// </param>
        public void AddContainer(string newName, string containerType)
        {
            // If the container exists in the container list already, don't add. Otherwise, continue.
            foreach (Container listContainer in this.containerList)
            {
                if (listContainer.Name == newName)
                {
                    return;
                }
            }

            // Make new container. Subscribe to event changes. Defaults to vegetable container if type isn't recognized.
            Container newContainer = new Container(containerType, newName);
            newContainer.FoodPropertyChanged += this.NotifyContainerListChanged;
            newContainer.ContainerPropertyChanged += this.NotifyContainerListChanged;

            // Add at this point
            this.containerList.Add(newContainer);

            // Notify outside world a change in container list was made.
            this.NotifyContainerListChanged(this, new PropertyChangedEventArgs("Added Container to List"));
        }

        /// <summary>
        ///  Explicitely for changing the name of an existing container.
        /// </summary>
        /// <param name="oldName">
        ///  Name of existing container.
        /// </param>
        /// <param name="newName">
        ///  New name of container.
        /// </param>
        public void ModifyContainer(string oldName, string newName)
        {
            // If the names aren't the same, initiate the change. Otherwise, return.
            if (oldName != newName)
            {
                // If "newName" exists already, we can't change the name and need to return.
                for (int i = 0; i < this.ContainerList.Count; i++)
                {
                    if (this.ContainerList[i].Name == newName)
                    {
                        return;
                    }
                }

                // If the container exists, change the name. Otherwise, return.
                for (int i = 0; i < this.ContainerList.Count; i++)
                {
                    if (this.ContainerList[i].Name == oldName)
                    {
                        this.ContainerList[i].Name = newName;
                    }
                }
            }

            return;
        }

        /// <summary>
        ///  Given a container name. This function removes the container from the list if it exists.
        /// </summary>
        /// <param name="targetContainer">
        /// Name of container to remove.
        /// </param>
        public void RemoveContainer(string targetContainer)
        {
            // If the container exists in the list, delete and proc a propertychanged event
            foreach (Container container in this.containerList)
            {
                if (container.Name == targetContainer)
                {
                    this.containerList.Remove(container);
                    this.NotifyContainerListChanged(this, new PropertyChangedEventArgs("Removed Container from List"));
                    return;
                }
            }
        }

        /// <summary>
        ///  Adds a food to the foodList based on the inputted strings.
        /// </summary>
        /// <param name="foodType">
        ///  Type of food to be created.
        /// </param>
        /// <param name="newName">
        ///  Name of new food to be set. Name cannot be null as we search for foods based on name in this class.
        /// </param>
        /// <param name="newColor">
        ///  Name of color to be set.
        /// </param>
        /// <param name="newShape">
        ///  Name of shape to be set.
        /// </param>
        /// <param name="newTexture">
        ///  Name of texture to be set.
        /// </param>
        /// <param name="newSize">
        ///  Name of size to be set.
        /// </param>
        /// <param name="newTaste">
        ///  Name of taste to be set.
        /// </param>
        public void AddFood(
            string foodType,
            string newName,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Create a new food element
            Food? newFood = FoodFactory.CreateFood(foodType, newName, newColor, newShape, newTexture, newSize, newTaste);

            // 1) If the food was created,
            //     2) (For loop) If the list doesn't contain a food by that name already,
            //         Add it to the list. Otherwise, do not add it to the list.
            if (newFood.GetType() != "NullFood")
            {
                for (int i = 0; i < this.foodList.Count; i++)
                {
                    // If it exists already, don't add it.
                    if (this.foodList[i].Name == newFood.Name)
                    {
                        return;
                    }
                }
            }
            else
            {
                return;
            }

            // Subscribe to the food property changed event
            newFood.PropertyChanged += this.NotifyFoodListChanged;

            // Add at this point
            this.foodList.Add(newFood);

            // Notify outside viewers that a property was changed in food list.
            this.NotifyFoodListChanged(this, new PropertyChangedEventArgs("Added Food to List"));

            return;
        }

        /// <summary>
        ///  New name of food in the context of the list.
        /// </summary>
        /// <param name="oldName">
        ///  Old name of food in list.
        /// </param>
        /// <param name="newName">
        ///  Name of new food to be set. Name cannot be null as we search for foods based on name in this class.
        /// </param>
        /// <param name="newType">
        ///  New type of food being edited.
        /// </param>
        /// <param name="newColor">
        ///  Name of color to be set.
        /// </param>
        /// <param name="newShape">
        ///  Name of shape to be set.
        /// </param>
        /// <param name="newTexture">
        ///  Name of texture to be set.
        /// </param>
        /// <param name="newSize">
        ///  Name of size to be set.
        /// </param>
        /// <param name="newTaste">
        ///  Name of taste to be set.
        /// </param>
        public void ModifyFood(
            string oldName,
            string newName,
            string? newType = null,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // If the food exists in the list, continue.
            // If it doesn't, return.
            // If the name "newname" exists already in the list, don't modify and return.
            bool foodExistsInList = false;
            int foodIndex = 0;
            for (int i = 0; i < this.foodList.Count; i++)
            {
                if (this.foodList[i].Name == oldName)
                {
                    foodExistsInList = true;
                    foodIndex = i;
                }

                if (this.foodList[i].Name == newName && oldName != newName)
                {
                    return;
                }
            }

            if (foodExistsInList == false)
            {
                return;
            }

            // At this point, modify.
            Food modifiedFood = this.foodList[foodIndex];

            if (newType == "Vegetable" || newType == "Fruit")
            {
                Food? newFood = FoodFactory.CreateFood(newType, newName, newColor, newShape, newTexture, newSize, newTaste);
                if (newFood.GetType() != "NullFood")
                {
                    this.foodList[foodIndex] = newFood;
                    this.NotifyFoodListChanged(this, new PropertyChangedEventArgs("Modified Food"));
                }
            }
            else
            {
                this.foodList[foodIndex].Name = newName;
                this.foodList[foodIndex].Color = newColor;
                this.foodList[foodIndex].Shape = newShape;
                this.foodList[foodIndex].Texture = newTexture;
                this.foodList[foodIndex].Size = newSize;
                this.foodList[foodIndex].Taste = newTaste;
            }
        }

        /// <summary>
        ///  Given a food name. This function removes the food name from the list if it exists.
        /// </summary>
        /// <param name="targetFood">
        ///  Name of food to remove.
        /// </param>
        public void RemoveFood(string targetFood)
        {
            // If the container exists in the list, delete and proc a propertychanged event
            foreach (Food food in this.foodList)
            {
                if (food.Name == targetFood)
                {
                    this.foodList.Remove(food);
                    this.NotifyFoodListChanged(this, new PropertyChangedEventArgs("Removed Food from List"));
                    return;
                }
            }
        }

        /// <summary>
        ///  Given a food and container name. This function checks to see both exist in their respective lists and if the food doesn't exist already in the container and if it
        ///  can be inserted in the container. If all of these are true, add the food to the container.
        /// </summary>
        /// <param name="existingFoodName">
        ///  Name of food to be added.
        /// </param>
        /// <param name="existingContainerName">
        ///  Name of container to recieve food.
        /// </param>
        /// <returns>
        /// 1 when successful
        /// 0 when unsuccessful.
        /// </returns>
        public int AddFoodToContainer(string existingFoodName, string existingContainerName)
        {
            // Check if it exists in food list. If it doesn't, exit.
            Food? addingFood = null;
            for (int i = 0; i < this.foodList.Count; i++)
            {
                if (this.foodList[i].Name == existingFoodName)
                {
                    addingFood = this.foodList[i];
                }
            }

            if (addingFood == null)
            {
                return 0;
            }

            // Check if it exists in container list. If it doesn't, exit.
            Container? receivingContainer = null;
            int containerIndex = 0;
            for (int i = 0; i < this.containerList.Count; i++)
            {
                if (this.containerList[i].Name == existingContainerName)
                {
                    containerIndex = i;
                    receivingContainer = this.containerList[i];
                }
            }

            if (receivingContainer == null)
            {
                return 0;
            }

            // Check to see if the food exists in the container. If it doesn't add.
            bool foodExistsInContainer = false;
            for (int i = 0; i < receivingContainer.FoodList.Count; i++)
            {
                if (receivingContainer.FoodList[i].Name == existingFoodName)
                {
                    foodExistsInContainer = true;
                }
            }

            if (foodExistsInContainer == true)
            {
                return 0;
            }

            // Finally check to see if the types match. If they don't match, return.
            if (receivingContainer.ContainerType != addingFood.GetType())
            {
                return 0;
            }

            // Add to the list at this point.
            receivingContainer.FoodList.Add(addingFood);
            receivingContainer.ContainerPropertyChanged += this.NotifyContainerListChanged;
            receivingContainer.FoodPropertyChanged += this.NotifyContainerListChanged;
            receivingContainer.ContainerPropertyChanged += this.NotifyContainerListChanged;
            receivingContainer.FoodPropertyChanged += this.NotifyContainerListChanged;
            this.containerList[containerIndex] = receivingContainer;

            // Invoke container list changed event
            this.NotifyContainerListChanged(this, new PropertyChangedEventArgs("Added Food to Container"));

            return 1;
        }

        /// <summary>
        ///  Given a food and container name. This function checks to see both exist, the container in container list and food within that container.
        ///  If true, remove the food.
        /// </summary>
        /// <param name="existingFoodName">
        ///  Name of food to be removed.
        /// </param>
        /// <param name="existingContainerName">
        ///  Name of container to remove the food.
        /// </param>
        /// <returns>
        /// 1 when successful
        /// 0 when unsuccessful.
        /// </returns>
        public int RemoveFoodFromContainer(string existingFoodName, string existingContainerName)
        {
            // Check to see if the container exists. If it doesn't, return.
            Container? removingContainer = null;
            int containerIndex = 0;
            for (int i = 0; i < this.containerList.Count; i++)
            {
                if (this.containerList[i].Name == existingContainerName)
                {
                    containerIndex = i;
                    removingContainer = this.containerList[i];
                }
            }

            if (removingContainer == null)
            {
                return 0;
            }

            // Check to see if the food exists within the container. If it doesn't, return.
            int? removingFoodIndex = null;
            for (int i = 0; i < removingContainer.FoodList.Count; i++)
            {
                if (removingContainer.FoodList[i].Name == existingFoodName)
                {
                    removingFoodIndex = i;
                }
            }

            if (removingFoodIndex == null)
            {
                return 0;
            }

            // Modify container
            removingContainer.FoodList.RemoveAt((int)removingFoodIndex);

            // Reinsert container into list, making sure to subscribe to container property changed events.
            removingContainer.ContainerPropertyChanged -= this.NotifyContainerListChanged;
            removingContainer.FoodPropertyChanged -= this.NotifyContainerListChanged;
            removingContainer.ContainerPropertyChanged += this.NotifyContainerListChanged;
            removingContainer.FoodPropertyChanged += this.NotifyContainerListChanged;
            this.containerList[containerIndex] = removingContainer;

            // Invoke container list changed event
            this.NotifyContainerListChanged(this, new PropertyChangedEventArgs("Removed Food from Container"));

            return 1;
        }

        /// <summary>
        ///  Given an input of an oldFilter and new properties, this function returns a new filter with
        ///  the updated properties.
        /// </summary>
        /// <param name="oldFilter">
        /// Old filter.
        /// </param>
        /// <param name="newFilterFoodType">
        ///  Filter's Food's type.
        /// </param>
        /// <param name="newFilterColor">
        /// Filter's Food's color.
        /// </param>
        /// <param name="newFilterShape">
        /// Filter's Food's shape.
        /// </param>
        /// <param name="newFilterTexture">
        /// Filter's Food's texture.
        /// </param>
        /// <param name="newFilterSize">
        /// Filter's Food's size.
        /// </param>
        /// <param name="newFilterTaste">
        /// Filter's Food's taste.
        /// </param>
        /// <returns>
        /// A new filter based on inputs.
        /// </returns>
        private Filter<Food> ChangeFilter(
            Filter<Food> oldFilter,
            string newFilterFoodType,
            string? newFilterColor = null,
            string? newFilterShape = null,
            string? newFilterTexture = null,
            string? newFilterSize = null,
            string? newFilterTaste = null)
        {
            // New filter to be created
            Filter<Food> newFilter = new Filter<Food>();

            // If the old filter isn't initialized, initialize it.
            if (oldFilter.FilterObject == null)
            {
                newFilter.FilterObject = FoodFactory.CreateFood(
                    newFilterFoodType,
                    "FilterFood",
                    newFilterColor,
                    newFilterShape,
                    newFilterTexture,
                    newFilterSize,
                    newFilterTaste);
            }

            // If the new filter object's type is changing, reinitialize the filterObject.
            else if (oldFilter.FilterObject.GetType() != newFilterFoodType)
            {
                newFilter.FilterObject = FoodFactory.CreateFood(
                    newFilterFoodType,
                    "FilterFood",
                    newFilterColor,
                    newFilterShape,
                    newFilterTexture,
                    newFilterSize,
                    newFilterTaste);
            }

            // If we are at this point, we can change the filter normally since we aren't changing the type of
            // initializing a new filter.
            else
            {
                newFilter.FilterObject = oldFilter.FilterObject;
                newFilter.FilterObject.Color = newFilterColor;
                newFilter.FilterObject.Shape = newFilterShape;
                newFilter.FilterObject.Texture = newFilterTexture;
                newFilter.FilterObject.Size = newFilterSize;
                newFilter.FilterObject.Taste = newFilterTaste;
            }

            return newFilter;
        }
    }
}
