﻿// <copyright file="Food.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Final_Exam_Test_Project")]
[assembly: InternalsVisibleTo("Cpts_321_Final_Exam")]

namespace FoodEngine
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Abstract class food. Lays the base for inheritance of different food types with properties
    ///  that food should have according to the project specifications.
    /// </summary>
    public abstract class Food
    {
        // Fields
        private string? name;
        private string? color;
        private string? shape;
        private string? texture;
        private string? size;
        private string? taste;

        /// <summary>
        ///  Used for determining when the Property of a Food is changed.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged = (sender, e) => { };

        /// <summary>
        ///  Gets or Sets name.
        /// </summary>
        public string? Name
        {
            get
            {
                return this.name;
            }

            set
            {
                if (this.name != value)
                {
                    this.name = value;
                    this.NotifyPropertyChanged("Name");
                }
            }
        }

        /// <summary>
        ///  Gets or Sets color.
        /// </summary>
        public string? Color
        {
            get
            {
                return this.color;
            }

            set
            {
                if (this.color != value)
                {
                    this.color = value;
                    this.NotifyPropertyChanged("Color");
                }
            }
        }

        /// <summary>
        ///  Gets or Sets shape.
        /// </summary>
        public string? Shape
        {
            get
            {
                return this.shape;
            }

            set
            {
                if (this.shape != value)
                {
                    this.shape = value;
                    this.NotifyPropertyChanged("Shape");
                }
            }
        }

        /// <summary>
        ///  Gets or Sets texture.
        /// </summary>
        public string? Texture
        {
            get
            {
                return this.texture;
            }

            set
            {
                if (this.texture != value)
                {
                    this.texture = value;
                    this.NotifyPropertyChanged("Texture");
                }
            }
        }

        /// <summary>
        ///  Gets or Sets size.
        /// </summary>
        public string? Size
        {
            get
            {
                return this.size;
            }

            set
            {
                if (this.size != value)
                {
                    this.size = value;
                    this.NotifyPropertyChanged("Size");
                }
            }
        }

        /// <summary>
        ///  Gets or Sets taste.
        /// </summary>
        public string? Taste
        {
            get
            {
                return this.taste;
            }

            set
            {
                if (this.taste != value)
                {
                    this.taste = value;
                    this.NotifyPropertyChanged("Taste");
                }
            }
        }

        /// <summary>
        ///  Gets the type of this object, but it's a, inherent property instead of a method.
        /// </summary>
        public virtual string? Type
        {
            get { return "uninitialized"; }
        }

        /// <summary>
        ///  Method that returns the type of the inherited object. Meant to be overriden.
        /// </summary>
        /// <returns>
        ///  The string representing the type of the inherited object. Nothing in the abstract class.
        /// </returns>
        public new abstract string GetType();

        /// <summary>
        /// Sends a propertychanged argument when a property of food is changed.
        /// </summary>
        /// <param name="propertyName">
        /// Name of property changed that triggered the event.
        /// </param>
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
