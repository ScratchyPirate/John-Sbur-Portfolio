﻿// <copyright file="Container.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Final_Exam_Test_Project")]
[assembly: InternalsVisibleTo("Cpts_321_Final_Exam")]

namespace FoodEngine
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Creator class of food. Holds and modifies food objects in a list within itself.
    /// </summary>
    public class Container
    {
        // Fields
        private string name;
        private List<Food> foodList;
        private string containerType;

        /// <summary>
        /// Initializes a new instance of the <see cref="Container"/> class.
        /// </summary>
        /// <param name="newType">
        ///  Type of container to be initialized. Defaults to Vegetable.
        /// </param>
        /// <param name="newName">
        ///  Name of container to be initialized.
        /// </param>
        public Container(string newType, string newName)
        {
            this.name = newName;
            this.foodList = new List<Food>();
            this.foodList.Clear();

            if (newType == "Vegetable")
            {
                this.containerType = "Vegetable";
            }
            else if (newType == "Fruit")
            {
                this.containerType = "Fruit";
            }
            else
            {
                this.containerType = "Vegetable";
            }
        }

        /// <summary>
        /// Food modified event handler. When a food is modified, this event handler is designed to invoke.
        /// </summary>
        public event PropertyChangedEventHandler FoodPropertyChanged = (sender, e) => { };

        /// <summary>
        /// Container modified event handler. When a property not related to food is modified, this event handler is designed to invoke
        /// </summary>
        public event PropertyChangedEventHandler ContainerPropertyChanged = (sender, e) => { };

        /// <summary>
        ///  Gets or Sets containerType. Set only occurs if the container is signifying a changing container type.
        /// </summary>
        public string ContainerType
        {
            get
            {
                return this.containerType;
            }

            set
            {
                if (this.foodList.Count == 0)
                {
                    this.containerType = value;
                }
            }
        }

        /// <summary>
        ///  Gets foodList. Meant to be read only as we want the user to edit the list through this
        ///  class' methods.
        /// </summary>
        public List<Food> FoodList
        {
            get { return this.foodList; }
        }

        /// <summary>
        ///  Gets or Sets name.
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                if (this.name != value)
                {
                    this.name = value;

                    // Notify outside viewers that a property was changed in container.
                    this.NotifyContainerPropertyChanged(this, new PropertyChangedEventArgs("Container Name Changed"));
                }
            }
        }

        /// <summary>
        ///  Adds a food to the foodList based on the inputted strings.
        /// </summary>
        /// <param name="foodType">
        ///  Type of food to be created.
        /// </param>
        /// <param name="newName">
        ///  Name of new food to be set. Name cannot be null as we search for foods based on name in this class.
        /// </param>
        /// <param name="newColor">
        ///  Name of color to be set.
        /// </param>
        /// <param name="newShape">
        ///  Name of shape to be set.
        /// </param>
        /// <param name="newTexture">
        ///  Name of texture to be set.
        /// </param>
        /// <param name="newSize">
        ///  Name of size to be set.
        /// </param>
        /// <param name="newTaste">
        ///  Name of taste to be set.
        /// </param>
        /// <returns>
        ///  1 if successfully added. 0 if not.
        /// </returns>
        public int AddFood(
            string foodType,
            string newName,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Create a new food element
            Food? newFood = FoodFactory.CreateFood(foodType, newName, newColor, newShape, newTexture, newSize, newTaste);

            // 1) If the food was created,
            //  2) If the type of the food matches this container's type,
            //     3) (For loop) If the container doesn't contain a food by that name already,
            //         Add it to the list. Otherwise, do not add it to the list.
            if (newFood.GetType() != "NullFood")
            {
                if (newFood.GetType() == this.containerType)
                {
                    for (int i = 0; i < this.foodList.Count; i++)
                    {
                        // If it exists already, don't add it.
                        if (this.foodList[i].Name == newFood.Name)
                        {
                            return 0;
                        }
                    }

                    // Subscribe to the food property changed event
                    newFood.PropertyChanged += this.NotifyFoodPropertyChanged;

                    // Add at this point
                    this.foodList.Add(newFood);

                    // Notify outside viewers that a property was changed in container.
                    this.NotifyContainerPropertyChanged(this, new PropertyChangedEventArgs("Added Food"));
                    return 1;
                }
            }

            return 0;
        }

        /// <summary>
        ///  Modifies an exiting food based on its name to match the parameters.
        /// </summary>
        /// <param name="oldName">
        ///  Name of the food in the list to be modified.
        /// </param>
        /// <param name="newName">
        ///  Name of new food to be set.
        /// </param>
        /// <param name="newColor">
        ///  Name of color to be set.
        /// </param>
        /// <param name="newShape">
        ///  Name of shape to be set.
        /// </param>
        /// <param name="newTexture">
        ///  Name of texture to be set.
        /// </param>
        /// <param name="newSize">
        ///  Name of size to be set.
        /// </param>
        /// <param name="newTaste">
        ///  Name of taste to be set.
        /// </param>
        /// <returns>
        ///  1 if we modified the food.
        ///  0 if we didn't modify the food.
        /// </returns>
        public int ModifyFood(
            string oldName,
            string newName,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Parse through and make sure that the newName of the food doesn't already exist. If it does, don't modify
            // and return. Only do this if the name is changing.
            if (oldName != newName)
            {
                for (int i = 0; i < this.foodList.Count; i++)
                {
                    // If it exists already, don't add it.
                    if (this.foodList[i].Name == newName)
                    {
                        return 0;
                    }
                }
            }

            // Try and find the food in the list. If we find it, modify it. Otherwise, continue.
            for (int i = 0; i < this.foodList.Count; i++)
            {
                // If it exists already, don't add it.
                if (this.foodList[i].Name == oldName)
                {
                    this.foodList[i].Name = newName;
                    this.foodList[i].Color = newColor;
                    this.foodList[i].Shape = newShape;
                    this.FoodList[i].Texture = newTexture;
                    this.foodList[i].Size = newSize;
                    this.foodList[i].Taste = newTaste;

                    return 1;
                }
            }

            return 0;
        }

        /// <summary>
        ///  Removes a food in the list based on its name.
        /// </summary>
        /// <param name="targetName">
        ///  Name of food to be removed.
        /// </param>
        /// <returns>
        ///  1 if successfully removed.
        ///  0 if unsuccessfully removed.
        /// </returns>
        public int RemoveFood(string targetName)
        {
            for (int i = 0; i < this.foodList.Count; i++)
            {
                // If it exists already, don't add it.
                if (this.foodList[i].Name == targetName)
                {
                    // Remove the item from the subscription list
                    this.foodList[i].PropertyChanged -= this.NotifyFoodPropertyChanged;

                    // Remove item and return.
                    this.foodList.RemoveAt(i);

                    // Notify outside viewers that a property was changed in container.
                    this.NotifyContainerPropertyChanged(this, new PropertyChangedEventArgs("Deleted Food"));
                    return 1;
                }
            }

            return 0;
        }

        /// <summary>
        ///  Clears the list of food items.
        /// </summary>
        public void Clear()
        {
            this.foodList.Clear();

            // Notify outside viewers that a property was changed in container.
            this.NotifyContainerPropertyChanged(this, new PropertyChangedEventArgs("Cleared Food List"));
        }

        /// <summary>
        /// Procs when a property of a food is changed. Notifies the outside classes containing "Container" that a
        /// food in its list was changed.
        /// </summary>
        /// <param name="sender">
        /// Food that send the event.
        /// </param>
        /// <param name="e">
        ///  Arguments from the event.
        /// </param>
        public void NotifyFoodPropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            this.FoodPropertyChanged?.Invoke(sender, e);
        }

        /// <summary>
        /// Procs when a property specific to container is changed. Notifies the outside classes containing "Container" that a
        /// property was changed.
        /// </summary>
        /// <param name="sender">
        /// Food that send the event.
        /// </param>
        /// <param name="e">
        ///  Arguments from the event.
        /// </param>
        public void NotifyContainerPropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            this.ContainerPropertyChanged?.Invoke(this, e);
        }
    }
}
