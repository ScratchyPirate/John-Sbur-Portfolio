﻿// <copyright file="Vegetable.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Final_Exam_Test_Project")]
[assembly: InternalsVisibleTo("Cpts_321_Final_Exam")]

namespace FoodEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Class derived from Food.
    /// </summary>
    internal class Vegetable : Food
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Vegetable"/> class.
        /// </summary>
        /// <param name="newName">
        ///  Name of new food to be set.
        /// </param>
        /// <param name="newColor">
        ///  Name of color to be set.
        /// </param>
        /// <param name="newTexture">
        ///  Name of texture to be set.
        /// </param>
        /// <param name="newShape">
        ///  Name of shape to be set.
        /// </param>
        /// <param name="newSize">
        ///  Name of size to be set.
        /// </param>
        /// <param name="newTaste">
        ///  Name of taste to be set.
        /// </param>
        public Vegetable(
            string? newName = null,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            this.Name = newName;
            this.Color = newColor;
            this.Shape = newShape;
            this.Texture = newTexture;
            this.Size = newSize;
            this.Taste = newTaste;
        }

        /// <summary>
        ///  Gets type. Overriden property from food.
        /// </summary>
        public override string Type
        {
            get { return "Vegetable"; }
        }

        /// <summary>
        ///  Returns "Vegetable", representing that this class is from the abstract class Food, but is of type Vegetable.
        /// </summary>
        /// <returns>
        ///  Type of Food this class is.
        /// </returns>
        public override string GetType()
        {
            return "Vegetable";
        }
    }
}
