﻿// <copyright file="Filter.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Final_Exam_Test_Project")]
[assembly: InternalsVisibleTo("Cpts_321_Final_Exam")]

namespace FoodEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Template filter class meant to filter objects of the same type.
    /// </summary>
    /// <typeparam name="T">
    ///  Type of object being filtered.
    /// </typeparam>
    public class Filter<T>
    {
        /// <summary>
        ///  Object used for filtering other objects.
        /// </summary>
        private T? filterObject;
        private PropertyInfo[] objectProperties;

        /// <summary>
        /// Initializes a new instance of the <see cref="Filter{T}"/> class.
        ///  Default constructor for filter. Loads properties of T into objectProperties.
        /// </summary>
        public Filter()
        {
            Type filterType = typeof(T);
            this.objectProperties = filterType.GetProperties();
        }

        /// <summary>
        ///  Gets or Sets filterObject.
        /// </summary>
        public T? FilterObject
        {
            get { return this.filterObject; }
            set { this.filterObject = value; }
        }

        /// <summary>
        ///  Filter function. Takes an unfilteredList of type T and uses LINQ to filter list objects into a list
        ///  and return the filtered list.
        /// </summary>
        /// <param name="unfilteredList">
        ///  List of objects to be filtered.
        /// </param>
        /// <returns>
        ///  Filtered List.
        /// </returns>
        public List<T>? FilterObjects(List<T> unfilteredList)
        {
            // If the filterObject hasn't been initialized, return null. Otherwise, continue.
            if (this.filterObject == null || this.objectProperties == null)
            {
                return null;
            }
            else
            {
                // List to be returned at the end of the function
                List<T> returnList = new List<T>();
                returnList.Clear();

                // For each property in objectProperties, we compare each element in the unfilteredList to the
                // filter object. If any of them match, we add it to the returnList if it hasn't already been added.
                foreach (PropertyInfo objectProperty in this.objectProperties)
                {
                    if (objectProperty.ToString() != null)
                    {
                        // Cannot be null as this if statement checks for that.
#pragma warning disable CS8604 // Possible null reference argument.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                        var filterObjectPropertyValue = objectProperty.GetValue(this.filterObject);
                        Type filterObjectPropertyType = objectProperty.PropertyType;

                        // Modified name of property so that the expression tree runs normally
                        // Properties are formatted "Library PropertyName", which if sent like that to the expression tree
                        // causes runtime errors. This modifiedObjectPropertyName is just the "PropertyName" portion which
                        // has been shown to run smoothly.
                        string modifiedObjectPropertyName = objectProperty.ToString().Split(' ')[1];

                        // If the value of the filterObject isn't null at that point, we continue. If it is, skip to the next property.
                        if (filterObjectPropertyValue != null)
                        {
                            // Set up expression tree and compile it.
                            var parameter = Expression.Parameter(typeof(T));
                            var condition =
                                Expression.Lambda<Func<T, bool>>(
                                    Expression.Equal(
                                        Expression.Property(parameter, modifiedObjectPropertyName),
                                        Expression.Constant(filterObjectPropertyValue, filterObjectPropertyType)),
                                    parameter)
                            .Compile();

#pragma warning restore CS8602 // Dereference of a possibly null reference.
#pragma warning restore CS8604 // Possible null reference argument.

                            // Make a list using LINQ from the expression tree
                            List<T> matchList = unfilteredList.Where(condition).ToList();

                            // For each object in matchList, if it's not in the returnList already, add it to the list
                            foreach (T match in matchList)
                            {
                                if (returnList.Contains(match) != true)
                                {
                                    returnList.Add(match);
                                }
                            }
                        }
                    }
                }

                return returnList;
            }
        }
    }
}
