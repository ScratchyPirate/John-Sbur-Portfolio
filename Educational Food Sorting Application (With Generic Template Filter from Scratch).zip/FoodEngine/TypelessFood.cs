﻿// <copyright file="TypelessFood.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Final_Exam_Test_Project")]
[assembly: InternalsVisibleTo("Cpts_321_Final_Exam")]

namespace FoodEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  If the type of a food isn't recognized during implementation. This class serves as a representation of a typeless food.
    /// </summary>
    internal class TypelessFood : Food
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TypelessFood"/> class.
        /// </summary>
        /// <param name="newName">
        ///  Name of new food to be set.
        /// </param>
        /// <param name="newColor">
        ///  Name of color to be set.
        /// </param>
        /// <param name="newTexture">
        ///  Name of texture to be set.
        /// </param>
        /// <param name="newShape">
        ///  Name of shape to be set.
        /// </param>
        /// <param name="newSize">
        ///  Name of size to be set.
        /// </param>
        /// <param name="newTaste">
        ///  Name of taste to be set.
        /// </param>
        public TypelessFood(
            string? newName = null,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            this.Name = newName;
            this.Color = newColor;
            this.Shape = newShape;
            this.Texture = newTexture;
            this.Size = newSize;
            this.Taste = newTaste;
        }

        /// <summary>
        ///  Gets type. Overriden property from food.
        /// </summary>
        public override string Type
        {
            get { return "NullFood"; }
        }

        /// <summary>
        ///  Returns "Vegetable", representing that this class is from the abstract class Food, but is of type Vegetable.
        /// </summary>
        /// <returns>
        ///  Type of Food this class is.
        /// </returns>
        public override string GetType()
        {
            return "NullFood";
        }
    }
}
