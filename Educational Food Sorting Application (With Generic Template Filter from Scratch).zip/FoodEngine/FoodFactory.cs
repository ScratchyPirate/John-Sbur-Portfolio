﻿// <copyright file="FoodFactory.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Final_Exam_Test_Project")]
[assembly: InternalsVisibleTo("Cpts_321_Final_Exam")]

namespace FoodEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  FactoryClass that creates food objects.
    /// </summary>
    public class FoodFactory
    {
        /// <summary>
        ///  Factory method for creating food objects.
        /// </summary>
        /// <param name="type">
        ///  Type of food to be created. In this project, it is expected to be either "Vegetable" or "Fruit".
        ///  If it is neither, the factory returns null.
        /// </param>
        /// <param name="newName">
        ///  Name of new food to be set.
        /// </param>
        /// <param name="newColor">
        ///  Name of color to be set.
        /// </param>
        /// <param name="newShape">
        ///  Name of shape to be set.
        /// </param>
        /// <param name="newTexture">
        ///  Name of texture to be set.
        /// </param>
        /// <param name="newSize">
        ///  Name of size to be set.
        /// </param>
        /// <param name="newTaste">
        ///  Name of taste to be set.
        /// </param>
        /// <returns>
        ///  Typeless if the factory fails recognize the food type
        ///  and the expected food type otherwise (vegetable and fruit).
        /// </returns>
        public static Food CreateFood(
            string? type,
            string? newName = null,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Local food to be returned
            Food newFood;

            // Set up newFood's type based on "type". If it can't, return null.
            if (type == "Vegetable")
            {
                newFood = new Vegetable(newName, newColor, newShape, newTexture, newSize, newTaste);
            }
            else if (type == "Fruit")
            {
                newFood = new Fruit(newName, newColor, newShape, newTexture, newSize, newTaste);
            }
            else
            {
                newFood = new TypelessFood(newName, newColor, newShape, newTexture, newSize, newTaste);
            }

            // Return new initialized food at this point
            return newFood;
        }
    }
}
