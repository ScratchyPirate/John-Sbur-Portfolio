﻿// <copyright file="Form2.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Cpts_321_Final_Exam
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using FoodEngine;

    /// <summary>
    ///  Form used for creating food items.
    /// </summary>
    public partial class Form2 : Form
    {
        // Field
        private Food? newFood;
        private string? foodName;
        private string? foodType;
        private string? foodColor;
        private string? foodShape;
        private string? foodTexture;
        private string? foodSize;
        private string? foodTaste;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form2"/> class.
        /// </summary>
        public Form2()
        {
            this.InitializeComponent();

            // Set the MaximizeBox to false to remove the maximize box.
            this.MaximizeBox = false;

            this.newFood = null;
            this.foodName = this.textBox1.Text;

            this.comboBox1.SelectedIndex = 0;
            this.foodType = this.comboBox1.SelectedItem.ToString();

            this.comboBox4.SelectedIndex = 0;
            this.foodColor = this.comboBox4.SelectedItem.ToString();

            this.comboBox3.SelectedIndex = 0;
            this.foodShape = this.comboBox3.SelectedItem.ToString();

            this.comboBox2.SelectedIndex = 0;
            this.foodTexture = this.comboBox2.SelectedItem.ToString();

            this.comboBox6.SelectedIndex = 0;
            this.foodSize = this.comboBox6.SelectedItem.ToString();

            this.comboBox5.SelectedIndex = 0;
            this.foodTaste = this.comboBox5.SelectedItem.ToString();
        }

        /// <summary>
        ///  Gets this.newFood.
        /// </summary>
        public Food? NewFood
        {
            get { return this.newFood; }
        }

        /// <summary>
        /// Gets or Sets the title of the window.
        /// </summary>
        public string FormTitle
        {
            get { return this.Text; }
            set { this.Text = value; }
        }

        /// <summary>
        ///  Gets or Sets the textbox1 text string.
        /// </summary>
        public string TextBox1
        {
            get { return this.textBox1.Text; }
            set { this.textBox1.Text = value; }
        }

        // The following functions add properties to the food.
        // Default winforms functions need to be initialized with lowercase text.
#pragma warning disable SA1300 // Element should begin with upper-case letter

        /// <summary>
        ///  Changes name to match textbox name.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            this.foodName = this.textBox1.Text;
        }

        /// <summary>
        ///  Changes item to match combobox selected item.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.foodType = this.comboBox1.SelectedItem.ToString();
        }

        /// <summary>
        ///  Changes item to match combobox selected item.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.foodColor = this.comboBox4.SelectedItem.ToString();
        }

        /// <summary>
        ///  Changes item to match combobox selected item.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.foodTexture = this.comboBox2.SelectedItem.ToString();
        }

        /// <summary>
        ///  Changes item to match combobox selected item.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.foodShape = this.comboBox3.SelectedItem.ToString();
        }

        /// <summary>
        ///  Changes item to match combobox selected item.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.foodSize = this.comboBox6.SelectedItem.ToString();
        }

        /// <summary>
        ///  Changes item to match combobox selected item.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.foodTaste = this.comboBox5.SelectedItem.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Type initialized to vegetable. Cannot be null.
#pragma warning disable CS8604 // Possible null reference argument.
            this.newFood = FoodFactory.CreateFood(this.foodType, this.foodName, this.foodColor, this.foodShape, this.foodTexture, this.foodSize, this.foodTaste);
#pragma warning restore CS8604 // Possible null reference argument.
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
#pragma warning restore SA1300 // Element should begin with upper-case letter
    }
}
