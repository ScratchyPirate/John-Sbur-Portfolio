﻿// <copyright file="Form3.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Cpts_321_Final_Exam
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using FoodEngine;

    /// <summary>
    ///  Form used for creating container items.
    /// </summary>
    public partial class Form3 : Form
    {
        // Default winform event functions need lowercase letters.
#pragma warning disable SA1300 // Element should begin with upper-case letter

        // Fields
        private FoodEngine.Container? newContainer;
        private string containerName;
        private string containerType;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form3"/> class.
        /// </summary>
        // Default item is vegetable. Cannot be null.
#pragma warning disable CS8601 // Possible null reference assignment.
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        public Form3()
        {
            this.InitializeComponent();

            // Set the MaximizeBox to false to remove the maximize box.
            this.MaximizeBox = false;

            this.newContainer = null;

            // Initialize name and type.
            this.containerName = string.Empty;
            this.comboBox1.SelectedIndex = 0;
            this.containerType = this.comboBox1.SelectedItem.ToString();
        }
#pragma warning restore CS8601 // Possible null reference assignment.
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        /// <summary>
        ///  Gets this.newFood.
        /// </summary>
        public FoodEngine.Container? NewContainer
        {
            get { return this.newContainer; }
        }

        /// <summary>
        ///  Gets or sets a value indicating whether gets or Sets the visibility of the combination box associated with type.
        /// </summary>
        public bool TypeComboBoxVisible
        {
            get { return this.comboBox1.Visible; }
            set { this.comboBox1.Visible = value; }
        }

        /// <summary>
        ///  Gets or sets a value indicating whether "type" label visibility.
        /// </summary>
        public bool TypeLableVisible
        {
            get { return this.label1.Visible; }
            set { this.label1.Visible = value; }
        }

        /// <summary>
        /// Gets or Sets the title of the window.
        /// </summary>
        public string FormTitle
        {
            get { return this.Text; }
            set { this.Text = value; }
        }

        /// <summary>
        ///  Gets or Sets the textbox1 text string.
        /// </summary>
        public string TextBox1
        {
            get { return this.textBox1.Text; }
            set { this.textBox1.Text = value; }
        }

        /// <summary>
        ///  Updates name to match textbox's name.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            this.containerName = this.textBox1.Text;
        }

        /// <summary>
        ///  Updates type to match combo box's type.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Both combo box options are not null.
#pragma warning disable CS8601 // Possible null reference assignment.
            this.containerType = this.comboBox1.SelectedItem.ToString();
#pragma warning restore CS8601 // Possible null reference assignment.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Set container and exit
            this.newContainer = new FoodEngine.Container(this.containerType, this.containerName);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Exit without setting and set container to null
            this.newContainer = null;
            this.Close();
        }
#pragma warning restore SA1300 // Element should begin with upper-case letter

    }
}
