﻿// <copyright file="GlobalSuppressions.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("StyleCop.CSharp.NamingRules", "SA1300:Element should begin with upper-case letter", Justification = "Default winforms functions are set to lower case by default and shouldn't be checked", Scope = "member", Target = "~M:Cpts_321_Final_Exam.Form1.addToolStripMenuItem1_Click(System.Object,System.EventArgs)")]
[assembly: SuppressMessage("StyleCop.CSharp.NamingRules", "SA1300:Element should begin with upper-case letter", Justification = "^", Scope = "member", Target = "~M:Cpts_321_Final_Exam.Form2.textBox1_TextChanged(System.Object,System.EventArgs)")]
