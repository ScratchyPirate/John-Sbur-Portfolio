// <copyright file="Form1.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Cpts_321_Final_Exam
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using FoodEngine;

    // Disabled since winforms default function names are lower case and need to be for the program to work properly.
#pragma warning disable SA1300 // Element should begin with upper-case letter

    /// <summary>
    ///  UI of the project. This project is event driven and this class facilitates the events.
    /// </summary>
    public partial class Form1 : Form
    {
        // Fields
        private Table formTable;

        // Style cop makes fixing the spacing impossible.
#pragma warning disable SA1018 // Nullable type symbols should be spaced correctly
        private string?[] ? undoCommand;
#pragma warning restore SA1018 // Nullable type symbols should be spaced correctly

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();

            // Set the MaximizeBox to false to remove the maximize box.
            this.MaximizeBox = false;

            // Initialize this form's table.
            this.formTable = new Table();

            // Subscribe list event changes to their respective display functions
            // FoodListChanged -> DisplayFoodList
            // ContainerListChanged -> DisplayContainerList
            this.formTable.ContainerListChanged += this.DisplayContainerList;
            this.formTable.ContainerListChanged += this.DisplayFilteredContainerListByContainer;
            this.formTable.ContainerListChanged += this.DisplayFilteredContainerListByFood;
            this.formTable.FoodListChanged += this.DisplayFoodList;
            this.formTable.ActiveContainerFilterChanged += this.DisplayFilteredContainerListByContainer;
            this.formTable.ActiveFoodFilterChanged += this.DisplayFilteredContainerListByFood;

            // Initialize the undo command.
            // Format
            // undoCommand = {command to perform, arg1, arg2, ..., argn}
            this.undoCommand = new string?[] { };
            this.undoToolStripMenuItem.Visible = false;
        }

        // ************************************** Functions Related To Displaying Lists **************************************

        /// <summary>
        ///  Displays contents of table's container list to the container list textboxes.
        /// </summary>
        /// <param name="sender">
        /// sender.
        /// </param>
        /// <param name="e">
        /// args e.
        /// </param>
        public void DisplayContainerList(object? sender, PropertyChangedEventArgs e)
        {
            // Set up a new blank string
            string containerListText = string.Empty;

            // For each container in the container list, add it to the string.
            foreach (FoodEngine.Container container in this.formTable.ContainerList)
            {
                // Add name of container to string
                containerListText += "Container Name: " + container.Name;
                containerListText += Environment.NewLine;

                // Add type of container to string
                containerListText += "Type: " + container.ContainerType;
                containerListText += Environment.NewLine;

                // For each food in the container, add it to the string.
                foreach (Food food in container.FoodList)
                {
                    // Food's name
                    containerListText += "     " + "Food Name: " + food.Name + Environment.NewLine;

                    // Food's type
                    containerListText += "     " + "Type: " + food.GetType() + Environment.NewLine;

                    // Food's color
                    containerListText += "     " + "Color: " + food.Color + Environment.NewLine;

                    // Food's shape
                    containerListText += "     " + "Shape: " + food.Shape + Environment.NewLine;

                    // Food's texture
                    containerListText += "     " + "Texture: " + food.Texture + Environment.NewLine;

                    // Food's size
                    containerListText += "     " + "Size: " + food.Size + Environment.NewLine;

                    // Food's taste
                    containerListText += "     " + "Taste: " + food.Taste + Environment.NewLine;
                }

                // Add boarder text
                containerListText += "-------------------------------------------------------------------------------------" + Environment.NewLine;
            }

            // Make the text of each container list equal to the new string.
            this.textBox3.Text = containerListText;
            this.textBox4.Text = containerListText;
            this.textBox7.Text = containerListText;
        }

        /// <summary>
        ///  Displays contents of table's food list to the food list textboxes.
        /// </summary>
        /// <param name="sender">
        /// sender.
        /// </param>
        /// <param name="e">
        /// args e.
        /// </param>
        public void DisplayFoodList(object? sender, PropertyChangedEventArgs e)
        {
            // Set up a new blank string
            string foodListText = string.Empty;

            // For each container in the container list, add it to the string.
            foreach (Food food in this.formTable.FoodList)
            {
                // Add name of container to string
                foodListText += "Food Name: " + food.Name;
                foodListText += Environment.NewLine;

                // Food's type
                foodListText += "     " + "Type: " + food.GetType() + Environment.NewLine;

                // Food's color
                foodListText += "     " + "Color: " + food.Color + Environment.NewLine;

                // Food's shape
                foodListText += "     " + "Shape: " + food.Shape + Environment.NewLine;

                // Food's texture
                foodListText += "     " + "Texture: " + food.Texture + Environment.NewLine;

                // Food's size
                foodListText += "     " + "Size: " + food.Size + Environment.NewLine;

                // Food's taste
                foodListText += "     " + "Taste: " + food.Taste + Environment.NewLine;

                // Boarder Text
                foodListText += "-------------------------------------------------------------------------------------" + Environment.NewLine;
            }

            // Make the text of each food list equal to the new string.
            this.textBox1.Text = foodListText;
        }

        /// <summary>
        ///  Displays contents of table's container list filtered based on the activeContainerFilter to the filtered container list textboxes.
        /// </summary>
        /// <param name="sender">
        /// sender.
        /// </param>
        /// <param name="e">
        /// args e.
        /// </param>
        public void DisplayFilteredContainerListByContainer(object? sender, PropertyChangedEventArgs e)
        {
            // Set up a new blank string
            string containerListText = string.Empty;

            // Get the filtered container list
            List<FoodEngine.Container> filteredContainerList = this.formTable.FilterContainerList();

            // Display the filter, leaving out null objects
            containerListText += "Active Filter: " + Environment.NewLine;

            if (this.formTable.ActiveContainerFilter != null)
            {
                if (this.formTable.ActiveContainerFilter.FilterObject != null)
                {
                    if (this.formTable.ActiveContainerFilter.FilterObject.GetType() != "NullFood")
                    {
                        // Food's type
                        containerListText += "     " + "Type: " + this.formTable.ActiveContainerFilter.FilterObject.GetType() + Environment.NewLine;
                    }

                    if (this.formTable.ActiveContainerFilter.FilterObject.Color != null)
                    {
                        // Food's color
                        containerListText += "     " + "Color: " + this.formTable.ActiveContainerFilter.FilterObject.Color + Environment.NewLine;
                    }

                    if (this.formTable.ActiveContainerFilter.FilterObject.Shape != null)
                    {
                        // Food's shape
                        containerListText += "     " + "Shape: " + this.formTable.ActiveContainerFilter.FilterObject.Shape + Environment.NewLine;
                    }

                    if (this.formTable.ActiveContainerFilter.FilterObject.Texture != null)
                    {
                        // Food's texture
                        containerListText += "     " + "Texture: " + this.formTable.ActiveContainerFilter.FilterObject.Texture + Environment.NewLine;
                    }

                    if (this.formTable.ActiveContainerFilter.FilterObject.Size != null)
                    {
                        // Food's size
                        containerListText += "     " + "Size: " + this.formTable.ActiveContainerFilter.FilterObject.Size + Environment.NewLine;
                    }

                    if (this.formTable.ActiveContainerFilter.FilterObject.Taste != null)
                    {
                        // Food's taste
                        containerListText += "     " + "Taste: " + this.formTable.ActiveContainerFilter.FilterObject.Taste + Environment.NewLine;
                    }
                }
            }

            containerListText += "-------------------------------------------------------------------------------------" + Environment.NewLine;

            // For each container in the container list, add it to the string.
            foreach (FoodEngine.Container container in filteredContainerList)
            {
                // Add name of container to string
                containerListText += "Container Name: " + container.Name;
                containerListText += Environment.NewLine;

                // Add type of container to string
                containerListText += "Type: " + container.ContainerType;
                containerListText += Environment.NewLine;

                // For each food in the container, add it to the string.
                foreach (Food food in container.FoodList)
                {
                    // Food's name
                    containerListText += "     " + "Food Name: " + food.Name + Environment.NewLine;

                    // Food's type
                    containerListText += "     " + "Type: " + food.GetType() + Environment.NewLine;

                    // Food's color
                    containerListText += "     " + "Color: " + food.Color + Environment.NewLine;

                    // Food's shape
                    containerListText += "     " + "Shape: " + food.Shape + Environment.NewLine;

                    // Food's texture
                    containerListText += "     " + "Texture: " + food.Texture + Environment.NewLine;

                    // Food's size
                    containerListText += "     " + "Size: " + food.Size + Environment.NewLine;

                    // Food's taste
                    containerListText += "     " + "Taste: " + food.Taste + Environment.NewLine;
                }

                // Add boarder text.
                containerListText += "-------------------------------------------------------------------------------------" + Environment.NewLine;
            }

            // Make the text of each container list equal to the new string.
            this.textBox5.Text = containerListText;
        }

        /// <summary>
        ///  Displays contents of table's container list filtered based on the activeFoodFilter to the filtered food container list textboxes.
        /// </summary>
        /// <param name="sender">
        /// sender.
        /// </param>
        /// <param name="e">
        /// args e.
        /// </param>
        public void DisplayFilteredContainerListByFood(object? sender, PropertyChangedEventArgs e)
        {
            // Set up a new blank string
            string containerListText = string.Empty;

            // Display the filter, leaving out null objects
            containerListText += "Active Filter: " + Environment.NewLine;

            if (this.formTable.ActiveFoodFilter != null)
            {
                if (this.formTable.ActiveFoodFilter.FilterObject != null)
                {
                    if (this.formTable.ActiveFoodFilter.FilterObject.GetType() != "NullFood")
                    {
                        // Food's type
                        containerListText += "     " + "Type: " + this.formTable.ActiveFoodFilter.FilterObject.GetType() + Environment.NewLine;
                    }

                    if (this.formTable.ActiveFoodFilter.FilterObject.Color != null)
                    {
                        // Food's color
                        containerListText += "     " + "Color: " + this.formTable.ActiveFoodFilter.FilterObject.Color + Environment.NewLine;
                    }

                    if (this.formTable.ActiveFoodFilter.FilterObject.Shape != null)
                    {
                        // Food's shape
                        containerListText += "     " + "Shape: " + this.formTable.ActiveFoodFilter.FilterObject.Shape + Environment.NewLine;
                    }

                    if (this.formTable.ActiveFoodFilter.FilterObject.Texture != null)
                    {
                        // Food's texture
                        containerListText += "     " + "Texture: " + this.formTable.ActiveFoodFilter.FilterObject.Texture + Environment.NewLine;
                    }

                    if (this.formTable.ActiveFoodFilter.FilterObject.Size != null)
                    {
                        // Food's size
                        containerListText += "     " + "Size: " + this.formTable.ActiveFoodFilter.FilterObject.Size + Environment.NewLine;
                    }

                    if (this.formTable.ActiveFoodFilter.FilterObject.Taste != null)
                    {
                        // Food's taste
                        containerListText += "     " + "Taste: " + this.formTable.ActiveFoodFilter.FilterObject.Taste + Environment.NewLine;
                    }
                }
            }

            containerListText += "-------------------------------------------------------------------------------------" + Environment.NewLine;

            // For each container in the container list, add it to the string.
            foreach (FoodEngine.Container container in this.formTable.ContainerList)
            {
                // Add name of container to string
                containerListText += "Container Name: " + container.Name;
                containerListText += Environment.NewLine;

                // Add type of container to string
                containerListText += "Type: " + container.ContainerType;
                containerListText += Environment.NewLine;

                // Get the filtered food list from the container.
                // If it's null, stop printing for this container.
                if (this.formTable.ActiveFoodFilter != null)
                {
                    Filter<Food> tableContainerFilter = this.formTable.ActiveFoodFilter;

                    // Filter the container based on the filter.
                    List<Food>? filteredContainerFood = tableContainerFilter.FilterObjects(container.FoodList);

                    // If the list returned isn't null, display each food item filtered from the list
                    if (filteredContainerFood != null)
                    {
                        // For each filtered food in the container, add it to the string.
                        foreach (Food food in filteredContainerFood)
                        {
                            // Food's name
                            containerListText += "     " + "Food Name: " + food.Name + Environment.NewLine;

                            // Food's type
                            containerListText += "     " + "Type: " + food.GetType() + Environment.NewLine;

                            // Food's color
                            containerListText += "     " + "Color: " + food.Color + Environment.NewLine;

                            // Food's shape
                            containerListText += "     " + "Shape: " + food.Shape + Environment.NewLine;

                            // Food's texture
                            containerListText += "     " + "Texture: " + food.Texture + Environment.NewLine;

                            // Food's size
                            containerListText += "     " + "Size: " + food.Size + Environment.NewLine;

                            // Food's taste
                            containerListText += "     " + "Taste: " + food.Taste + Environment.NewLine;
                        }
                    }
                }

                // Add boarder text
                containerListText += "-------------------------------------------------------------------------------------" + Environment.NewLine;
            }

            // Make the text of the filtered food container list equal to the new string.
            this.textBox6.Text = containerListText;
        }

        // ************************************** Functions Related To Undo **************************************

        /// <summary>
        ///  Performs a command based on the undo string array currently stored in this form. String array is built when a command executes and
        ///  is designed to let this function know what to perform to undo the last action. Fails if the array is empty (null).
        /// </summary>
        public void Undo()
        {
            // If undo is empty, return. Otherwise, continue.
            if (this.undoCommand == null)
            {
                return;
            }
            else
            {
                // If the first element is "Food", perform an action related to food list. "Container" for container list. Return otherwise.
                if (this.undoCommand[0] == "Food" && this.undoCommand.Length >= 2)
                {
                    // If "Add", remove the item added
                    if (this.undoCommand[1] == "Add" && this.undoCommand.Length >= 3)
                    {
                        // Cannot be null based on how we have set it up at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.RemoveFood(this.undoCommand[2]);
#pragma warning restore CS8604 // Possible null reference argument.
                    }

                    // If "Modify", remove the item added
                    else if (this.undoCommand[1] == "Modify")
                    {
                        // Cannot be null based on how we have set it up at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.ModifyFood(this.undoCommand[3], this.undoCommand[2], this.undoCommand[4], this.undoCommand[5], this.undoCommand[6], this.undoCommand[7], this.undoCommand[8], this.undoCommand[9]);
#pragma warning restore CS8604 // Possible null reference argument.
                    }

                    // If "Add", remove the item added
                    else if (this.undoCommand[1] == "Remove")
                    {
                        // Cannot be null based on how we have set it up at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.AddFood(this.undoCommand[3], this.undoCommand[2], this.undoCommand[4], this.undoCommand[5], this.undoCommand[6], this.undoCommand[7], this.undoCommand[8]);
#pragma warning restore CS8604 // Possible null reference argument.
                    }
                }
                else if (this.undoCommand[0] == "Container" && this.undoCommand.Length >= 2)
                {
                    // If "Add", remove the container.
                    if (this.undoCommand[1] == "Add")
                    {
                        // Cannot be null at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.RemoveContainer(this.undoCommand[2]);
#pragma warning restore CS8604 // Possible null reference argument.
                    }

                    // If "Modify", change the container property
                    else if (this.undoCommand[1] == "Modify")
                    {
                        // Cannot be null at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.ModifyContainer(this.undoCommand[3], this.undoCommand[2]);
#pragma warning restore CS8604 // Possible null reference argument.
                    }

                    // If "Remove", restore container.
                    else if (this.undoCommand[1] == "Remove")
                    {
                        // Cannot be null at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.AddContainer(this.undoCommand[2], this.undoCommand[3]);

                        // ReAdd food items into container that was just added
                        Food currentFood = FoodFactory.CreateFood(null);
                        for (int i = 4; i < this.undoCommand.Length;)
                        {
                            // If we encounter food. Reset the currentFood. Store it in the container if it was initialized
                            if (this.undoCommand[i] == "Food")
                            {
                                // If initialized, store.
                                if (currentFood != null)
                                {
                                    if (currentFood.Name != null)
                                    {
                                        // Add to container
                                        int result = this.formTable.AddFoodToContainer(currentFood.Name, this.undoCommand[2]);

                                        if (result == 0)
                                        {
                                            this.formTable.AddFood(currentFood.GetType(), currentFood.Name, currentFood.Color, currentFood.Shape, currentFood.Texture, currentFood.Size, currentFood.Taste);
                                            this.formTable.AddFoodToContainer(currentFood.Name, this.undoCommand[2]);
                                            this.formTable.RemoveFood(currentFood.Name);
                                        }
                                    }
                                }

                                // Reset food
                                currentFood = FoodFactory.CreateFood(null);

                                i++;
                            }
                            else
                            {
                                // Get current food from string array.
                                currentFood = FoodFactory.CreateFood(this.undoCommand[3], this.undoCommand[i], this.undoCommand[i + 2], this.undoCommand[i + 1], this.undoCommand[i + 3], this.undoCommand[i + 4], this.undoCommand[i + 5]);
                                i += 6;
                            }
                        }
#pragma warning restore CS8604 // Possible null reference argument.
                    }

                    // If "Add to", remove added food from container.
                    else if (this.undoCommand[1] == "Add To")
                    {
                        // Cannot be null at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.RemoveFoodFromContainer(this.undoCommand[2], this.undoCommand[3]);
#pragma warning restore CS8604 // Possible null reference argument.
                    }

                    // If "Remove from", restore removed food to container.
                    else if (this.undoCommand[1] == "Remove From")
                    {
                        // Cannot be null at this point.
#pragma warning disable CS8604 // Possible null reference argument.
                        this.formTable.AddFoodToContainer(this.undoCommand[2], this.undoCommand[3]);
#pragma warning restore CS8604 // Possible null reference argument.
                    }
                }

                else
                {
                    return;
                }

                // Reset undoCommand and make the button invisible again.
                this.undoCommand = null;
                this.undoToolStripMenuItem.Visible = false;
            }
        }

        /// <summary>
        ///  On undo button clicked. Undo last action within first tab.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Undo();
        }

        // ************************************** Functions Related To Changing to Food List **************************************

        /// <summary>
        ///  Event for adding a new food to the food list. Dialog box is displayed for adding food.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void addToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Locals used for keeping track of the new food
            Food? food;

            // Get information about food from a custom dialog box.
            Form2 foodCreateForm = new Form2();
            foodCreateForm.ShowDialog();
            food = foodCreateForm.NewFood;

            // If the food is null, return.
            if (food == null)
            {
                return;
            }

            // If the food's name was never entered, return.
            else if (food.Name == null || food.Name == string.Empty)
            {
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show("Food Name Missing", "Create Food Error", buttons);
            }

            // Otherwise, continue and try to insert the new food into the list.
            else
            {
                int foodListSizeBefore = this.formTable.FoodList.Count;
                this.formTable.AddFood(food.GetType(), food.Name, food.Color, food.Shape, food.Texture, food.Size, food.Taste);
                int foodListSizeAfter = this.formTable.FoodList.Count;

                // If the size after inserting isn't changed, then we didn't insert and need to display an error.
                if (foodListSizeAfter == foodListSizeBefore)
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Food Already Exists in Food List", "Create Food Error", buttons);
                }
                else
                {
                    // Add to undo stack if successful. Tells the undo function what to do.
                    this.undoCommand = new string[3] { "Food", "Add", food.Name };

                    // Make the button visible if it isn't already
                    this.undoToolStripMenuItem.Visible = true;
                }
            }
        }

        /// <summary>
        ///  On leaving the modify textbox. This checks to see if the food entered exists in the food list and if it does, modify it.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void toolStripTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            // If the enter button wasn't pressed. Return. Otherwise, continue.
            if (e.KeyCode != Keys.Enter)
            {
                return;
            }

            // If the string isn't the empty string, search for the food in food list.
            if (this.toolStripTextBox1.Text != string.Empty)
            {
                // If the food exists, continue. Otherwise, return.
                Food? modifyingFood = null;
                string? oldFoodName = string.Empty;
                int foodIndex = 0;
                for (int i = 0; i < this.formTable.FoodList.Count; i++)
                {
                    if (this.formTable.FoodList[i].Name == this.toolStripTextBox1.Text)
                    {
                        modifyingFood = this.formTable.FoodList[i];
                        oldFoodName = this.formTable.FoodList[i].Name;
                        foodIndex = i;
                    }
                }

                if (modifyingFood == null || modifyingFood.Name == null)
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Food Not Found in List", "Modify Food Error", buttons);

                    // Clear textbox
                    this.toolStripTextBox1.Text = string.Empty;

                    // Return
                    return;
                }

                // Since the food exists, modify the food and return it if the modification was successful
                // Get information about food from a custom dialog box.
                Form2 foodCreateForm = new Form2();
                foodCreateForm.TextBox1 = modifyingFood.Name;
                foodCreateForm.Text = "Modifying Food";
                foodCreateForm.ShowDialog();
                modifyingFood = foodCreateForm.NewFood;

                // If the food is null, return.
                if (modifyingFood == null || oldFoodName == null)
                {
                }

                // If the food's name was never entered, return.
                else if (modifyingFood.Name == null || modifyingFood.Name == string.Empty)
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Food Name Missing", "Modify Food Error", buttons);
                }

                // Otherwise, continue and try to insert the new food into the list.
                else
                {
                    // Old food storage
                    Food oldFood = this.formTable.FoodList[foodIndex];

                    // Modify at this point.
                    this.formTable.ModifyFood(
                        oldFoodName,
                        modifyingFood.Name,
                        modifyingFood.GetType(),
                        modifyingFood.Color,
                        modifyingFood.Shape,
                        modifyingFood.Texture,
                        modifyingFood.Size,
                        modifyingFood.Taste);

                    // If the modification failed. It likely means that the newname of the food being entered already exists in the list
                    // Let the user know this
                    if (this.formTable.FoodList[foodIndex].Name == oldFoodName && oldFoodName != modifyingFood.Name)
                    {
                        MessageBoxButtons buttons = MessageBoxButtons.OK;
                        MessageBox.Show("New Name of Food Already Exists", "Modify Food Error", buttons);
                    }
                    else
                    {
                        // Add to undo command
                        this.undoCommand = new string?[]
                        {
                            "Food",
                            "Modify",
                            oldFoodName,
                            oldFood.Name,
                            oldFood.GetType(),
                            oldFood.Color,
                            oldFood.Shape,
                            oldFood.Texture,
                            oldFood.Size,
                            oldFood.Taste,
                        };

                        // Make the button visible if it isn't already
                        this.undoToolStripMenuItem.Visible = true;
                    }
                }

                // Clear textbox
                this.toolStripTextBox1.Text = string.Empty;
            }
        }

        /// <summary>
        ///  On leaving the remove textbox. This checks to see if the food entered exists in the food list and if it does, remove it.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void toolStripTextBox2_KeyDown(object sender, KeyEventArgs e)
        {
            // If the key entered wasn't the enter key, exit.
            if (e.KeyCode != Keys.Enter)
            {
                return;
            }

            // Get the food to be removed if it exists
            Food targetFood = FoodFactory.CreateFood(null);
            foreach (Food food in this.formTable.FoodList)
            {
                if (food.Name == this.toolStripTextBox2.Text)
                {
                    targetFood = food;
                }
            }

            // Remove the food from the list.
            int foodListSizeBeforeRemoval = this.formTable.FoodList.Count;
            this.formTable.RemoveFood(this.toolStripTextBox2.Text);
            int foodListSizeAfterRemoval = this.formTable.FoodList.Count;

            // If it fails to remove, output message to the user.
            if (foodListSizeAfterRemoval == foodListSizeBeforeRemoval)
            {
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show("Food Not Found in List", "Remove Food Error", buttons);
            }
            else
            {
                // Add to undo command
                this.undoCommand = new string?[]
                {
                    "Food",
                    "Remove",
                    targetFood.Name,
                    targetFood.GetType(),
                    targetFood.Color,
                    targetFood.Shape,
                    targetFood.Texture,
                    targetFood.Size,
                    targetFood.Taste,
                };

                // Make the button visible if it isn't already
                this.undoToolStripMenuItem.Visible = true;
            }

            // Clear textbox
            this.toolStripTextBox2.Text = string.Empty;
        }

        // ************************************** Functions Related To Changing Container List **************************************

        /// <summary>
        ///  Adds a new container to the container list on add container button clicked.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Locals used for keeping track of the new food
            FoodEngine.Container? newContainer;

            // Get information about food from a custom dialog box.
            Form3 containerCreateForm = new Form3();
            containerCreateForm.ShowDialog();
            newContainer = containerCreateForm.NewContainer;

            // If the food is null, return.
            if (newContainer == null)
            {
                return;
            }

            // If the food's name was never entered, return.
            else if (newContainer.Name == string.Empty)
            {
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show("Container Name Missing", "Create Container Error", buttons);
            }

            // Otherwise, continue and try to insert the new food into the list.
            else
            {
                int containerListSizeBefore = this.formTable.ContainerList.Count;
                this.formTable.AddContainer(newContainer.Name, newContainer.ContainerType);
                int containerListSizeAfter = this.formTable.ContainerList.Count;

                // If the size after inserting isn't changed, then we didn't insert and need to display an error.
                if (containerListSizeAfter == containerListSizeBefore)
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Container Already Exists in Container List", "Create Container Error", buttons);
                }
                else
                {
                    // Add to undo command
                    this.undoCommand = new string?[]
                    {
                            "Container",
                            "Add",
                            newContainer.Name,
                    };

                    // Make the button visible if it isn't already
                    this.undoToolStripMenuItem.Visible = true;
                }
            }
        }

        /// <summary>
        ///  On leaving the modify textbox. This checks to see if the container entered exists in the container list and if it does, modify it.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void toolStripTextBox3_KeyDown(object sender, KeyEventArgs e)
        {
            // If the enter button wasn't pressed. Return. Otherwise, continue.
            if (e.KeyCode != Keys.Enter)
            {
                return;
            }

            // If the string isn't the empty string, search for the container in container list.
            if (this.toolStripTextBox3.Text != string.Empty)
            {
                // If the food exists, continue. Otherwise, return.
                FoodEngine.Container? modifyingContainer = null;
                string? oldContainerName = string.Empty;
                int containerIndex = 0;
                for (int i = 0; i < this.formTable.ContainerList.Count; i++)
                {
                    if (this.formTable.ContainerList[i].Name == this.toolStripTextBox3.Text)
                    {
                        modifyingContainer = this.formTable.ContainerList[i];
                        oldContainerName = this.formTable.ContainerList[i].Name;
                        containerIndex = i;
                    }
                }

                if (modifyingContainer == null || modifyingContainer.Name == null)
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Container Not Found in List", "Modify Container Error", buttons);

                    // Clear textbox
                    this.toolStripTextBox3.Text = string.Empty;

                    // Return
                    return;
                }

                // Since the container exists, modify the container and return it if the modification was successful
                // Get information about container from a custom dialog box.
                Form3 containerModifyForm = new Form3();
                containerModifyForm.TextBox1 = modifyingContainer.Name;
                containerModifyForm.Text = "Modifying Container";
                containerModifyForm.TypeComboBoxVisible = false;
                containerModifyForm.TypeLableVisible = false;
                containerModifyForm.ShowDialog();
                modifyingContainer = containerModifyForm.NewContainer;

                // If the container was null afterwards, return.
                if (modifyingContainer == null)
                {
                }

                // If the food's name was never entered, return.
                else if (modifyingContainer.Name == null || modifyingContainer.Name == string.Empty)
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Container Name Missing", "Modify Container Error", buttons);
                }

                // Otherwise, continue and try to insert the new container into the list.
                else
                {
                    this.formTable.ModifyContainer(
                        oldContainerName,
                        modifyingContainer.Name);

                    // If the modification failed. It likely means that the newname of the food being entered already exists in the list
                    // Let the user know this
                    if (this.formTable.ContainerList[containerIndex].Name == oldContainerName && oldContainerName != modifyingContainer.Name)
                    {
                        MessageBoxButtons buttons = MessageBoxButtons.OK;
                        MessageBox.Show("New Name of Container Already Exists", "Modify Container Error", buttons);
                    }
                    else
                    {
                        // Add to undo command
                        this.undoCommand = new string?[]
                        {
                            "Container",
                            "Modify",
                            oldContainerName,
                            modifyingContainer.Name,
                        };

                        // Make the button visible if it isn't already
                        this.undoToolStripMenuItem.Visible = true;
                    }
                }

                // Clear textbox
                this.toolStripTextBox3.Text = string.Empty;
            }
        }

        /// <summary>
        ///  On leaving the remove textbox. This checks to see if the container entered exists in the container list and if it does, remove it.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void toolStripTextBox4_KeyDown(object sender, KeyEventArgs e)
        {
            // If the enter button wasn't pressed. Return. Otherwise, continue.
            if (e.KeyCode != Keys.Enter)
            {
                return;
            }

            // Get container to remove if it exists
            FoodEngine.Container targetContainer = new FoodEngine.Container("null", "null");
            foreach (FoodEngine.Container container in this.formTable.ContainerList)
            {
                if (container.Name == this.toolStripTextBox4.Text)
                {
                    targetContainer = container;
                }
            }

            // Remove the food from the list.
            int containerListSizeBeforeRemoval = this.formTable.ContainerList.Count;
            this.formTable.RemoveContainer(this.toolStripTextBox4.Text);
            int containerListSizeAfterRemoval = this.formTable.ContainerList.Count;

            // If it fails to remove, output message to the user.
            if (containerListSizeAfterRemoval == containerListSizeBeforeRemoval)
            {
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show("Container Not Found in List", "Remove Container Error", buttons);
            }
            else
            {
                // Get each element into a List
                List<string?> undoCommandList = new List<string?>();
                undoCommandList.Add("Container");
                undoCommandList.Add("Remove");
                undoCommandList.Add(targetContainer.Name);
                undoCommandList.Add(targetContainer.ContainerType);

                foreach (Food food in targetContainer.FoodList)
                {
                    undoCommandList.Add("Food");
                    undoCommandList.Add(food.Name);
                    undoCommandList.Add(food.Shape);
                    undoCommandList.Add(food.Color);
                    undoCommandList.Add(food.Texture);
                    undoCommandList.Add(food.Size);
                    undoCommandList.Add(food.Taste);
                }

                undoCommandList.Add("Food");

                // Store list into undoCommand
                this.undoCommand = undoCommandList.ToArray();

                // Make the button visible if it isn't already
                this.undoToolStripMenuItem.Visible = true;
            }

            // Clear textbox
            this.toolStripTextBox4.Text = string.Empty;
        }

        /// <summary>
        ///  Despite the misleading name. This is responsible for adding a food from the foodlist to the container list.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void removeFoodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Buttons local variable.
            MessageBoxButtons buttons;

            // Create a new double input box.
            Form4 inputForm = new Form4();
            inputForm.Label1 = "Food to Add";
            inputForm.Label2 = "Container to Receive";
            inputForm.Title = "Add Food to Container";
            inputForm.ShowDialog();

            // Get both inputs
            string? targetFood = inputForm.Text1;
            string? targetContainer = inputForm.Text2;

            // If either are null, display and error and return
            if (targetFood == null || targetContainer == null)
            {
                buttons = MessageBoxButtons.OK;
                MessageBox.Show("One or more entries are missing", "Add Food to Container Error", buttons);
                return;
            }

            // Attempt to add the food to the container
            int result = this.formTable.AddFoodToContainer(targetFood, targetContainer);

            // If it was unsuccessfully added, display an error message.
            if (result == 0)
            {
                buttons = MessageBoxButtons.OK;
                MessageBox.Show("Failed to Add Food to Container", "Add Food to Container Error", buttons);
            }
            else
            {
                // Add to undo command
                this.undoCommand = new string?[]
                {
                    "Container",
                    "Add To",
                    targetFood,
                    targetContainer,
                };

                // Make the button visible if it isn't already
                this.undoToolStripMenuItem.Visible = true;
            }
        }

        /// <summary>
        ///  This is responsible for from a food a container in the container list.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void removeFoodToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Buttons local variable.
            MessageBoxButtons buttons;

            // Create a new double input box.
            Form4 inputForm = new Form4();
            inputForm.Label1 = "Food to Remove";
            inputForm.Label2 = "Container to Remove";
            inputForm.Title = "Remove Food from Container";
            inputForm.ShowDialog();

            // Get both inputs
            string? targetFood = inputForm.Text1;
            string? targetContainer = inputForm.Text2;

            // If either are null, display and error and return
            if (targetFood == null || targetContainer == null)
            {
                buttons = MessageBoxButtons.OK;
                MessageBox.Show("One or more entries are missing", "Remove Food from Container Error", buttons);
                return;
            }

            // Attempt to add the food to the container
            int result = this.formTable.RemoveFoodFromContainer(targetFood, targetContainer);

            // If it was unsuccessfully added, display an error message.
            if (result == 0)
            {
                buttons = MessageBoxButtons.OK;
                MessageBox.Show("Failed to Remove Food from Container", "Remove Food from Container Error", buttons);
            }
            else
            {
                // Add to undo command
                this.undoCommand = new string?[]
                {
                    "Container",
                    "Remove From",
                    targetFood,
                    targetContainer,
                };

                // Make the button visible if it isn't already
                this.undoToolStripMenuItem.Visible = true;
            }
        }

        // ************************************** Functions Related To Changing Active Food Filter **************************************

        /// <summary>
        ///  On click of the change food filter button. Open Form5 and attempt to change the filter.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void changeFilterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Make a new form5 and display it
            Form5 changeFilterForm = new Form5();
            changeFilterForm.ShowDialog();

            // Get the filter from the form. If it's null, don't change the filter. Otherwise, change the filter.
            if (changeFilterForm.NewFilter == null)
            {
                return;
            }
            else
            {
                this.formTable.ChangeActiveFoodFilter(
                    changeFilterForm.NewFilter.GetType(),
                    changeFilterForm.NewFilter.Color,
                    changeFilterForm.NewFilter.Shape,
                    changeFilterForm.NewFilter.Texture,
                    changeFilterForm.NewFilter.Size,
                    changeFilterForm.NewFilter.Taste);
            }
        }

        // ************************************** Functions Related To Changing Active Container Filter **************************************

        /// <summary>
        ///  On click of the change container filter button. Open Form5 and attempt to change the filter.
        /// </summary>
        /// <param name="sender">
        ///  Sender.
        /// </param>
        /// <param name="e">
        ///  Args.
        /// </param>
        private void changeFilterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Make a new form5 and display it
            Form5 changeFilterForm = new Form5();
            changeFilterForm.ShowDialog();

            // Get the filter from the form. If it's null, don't change the filter. Otherwise, change the filter.
            if (changeFilterForm.NewFilter == null)
            {
                return;
            }
            else
            {
                this.formTable.ChangeActiveContainerFilter(
                    changeFilterForm.NewFilter.GetType(),
                    changeFilterForm.NewFilter.Color,
                    changeFilterForm.NewFilter.Shape,
                    changeFilterForm.NewFilter.Texture,
                    changeFilterForm.NewFilter.Size,
                    changeFilterForm.NewFilter.Taste);
            }
        }

#pragma warning restore SA1300 // Element should begin with upper-case letter
    }
}