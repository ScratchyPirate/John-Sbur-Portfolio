﻿// <copyright file="Form5.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Cpts_321_Final_Exam
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using FoodEngine;

    /// <summary>
    ///  Form associated with changing a filter object in the program.
    /// </summary>
    public partial class Form5 : Form
    {
        // Fields
        private Food? newFilterObject;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form5"/> class.
        /// </summary>
        public Form5()
        {
            this.InitializeComponent();

            // Set the MaximizeBox to false to remove the maximize box.
            this.MaximizeBox = false;

            this.newFilterObject = FoodFactory.CreateFood(string.Empty);

            this.comboBox1.SelectedIndex = 0;
            this.comboBox4.SelectedIndex = 0;
            this.comboBox3.SelectedIndex = 0;
            this.comboBox2.SelectedIndex = 0;
            this.comboBox6.SelectedIndex = 0;
            this.comboBox5.SelectedIndex = 0;
        }

        /// <summary>
        ///  Gets filter type.
        /// </summary>
        public string? Type
        {
            get
            {
                if (this.comboBox1.SelectedItem.ToString() == "None")
                {
                    return null;
                }
                else
                {
                    return this.comboBox1.SelectedItem.ToString();
                }
            }
        }

        /// <summary>
        ///  Gets color.
        /// </summary>
        public string? Color
        {
            get
            {
                if (this.comboBox4.SelectedItem.ToString() == "None")
                {
                    return null;
                }
                else
                {
                    return this.comboBox4.SelectedItem.ToString();
                }
            }
        }

        /// <summary>
        ///  Gets Shape.
        /// </summary>
        public string? Shape
        {
            get
            {
                if (this.comboBox3.SelectedItem.ToString() == "None")
                {
                    return null;
                }
                else
                {
                    return this.comboBox3.SelectedItem.ToString();
                }
            }
        }

        /// <summary>
        ///  Gets texture.
        /// </summary>
        public string? Texture
        {
            // Cannot be null as newFilter is initialized in the beginning and GetType is as well.
            get
            {
                if (this.comboBox2.SelectedItem.ToString() == "None")
                {
                    return null;
                }
                else
                {
                    return this.comboBox2.SelectedItem.ToString();
                }
            }
        }

        /// <summary>
        ///  Gets size.
        /// </summary>
        public string? SizeText
        {
            // Cannot be null as newFilter is initialized in the beginning and GetType is as well.
            get
            {
                if (this.comboBox6.SelectedItem.ToString() == "None")
                {
                    return null;
                }
                else
                {
                    return this.comboBox6.SelectedItem.ToString();
                }
            }
        }

        /// <summary>
        ///  Gets taste.
        /// </summary>
        public string? Taste
        {
            // Cannot be null as newFilter is initialized in the beginning and GetType is as well.
            get
            {
                if (this.comboBox5.SelectedItem.ToString() == "None")
                {
                    return null;
                }
                else
                {
                    return this.comboBox5.SelectedItem.ToString();
                }
            }
        }

        /// <summary>
        ///  Gets this form's filter object.
        /// </summary>
        public Food? NewFilter
        {
            get { return this.newFilterObject; }
        }

        // Default winform names are meant to be lower case.
#pragma warning disable SA1300 // Element should begin with upper-case letter

        /// <summary>
        ///  On submit button clicked, makes a filter object based on selected combinations and closes the window.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void button1_Click(object sender, EventArgs e)
        {
            this.newFilterObject = FoodFactory.CreateFood(this.Type, "FilterObject", this.Color, this.Shape, this.Texture, this.SizeText, this.Taste);
            this.Close();
        }

        /// <summary>
        ///  On cancel button clicked, sets filter object to null and closes the window.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void button2_Click(object sender, EventArgs e)
        {
            this.newFilterObject = null;
            this.Close();
        }

#pragma warning restore SA1300 // Element should begin with upper-case letter

    }
}
