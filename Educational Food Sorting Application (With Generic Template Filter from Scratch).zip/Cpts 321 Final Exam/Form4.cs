﻿// <copyright file="Form4.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Cpts_321_Final_Exam
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using FoodEngine;

    /// <summary>
    ///  Meant to be a customizable 2 input textbox where it can be ran, elements can be changed, and the text values afterwards can be accessed.
    /// </summary>
    public partial class Form4 : Form
    {
        // Fields
        private string? text1;
        private string? text2;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form4"/> class.
        /// </summary>
        public Form4()
        {
            this.InitializeComponent();

            this.text1 = null;
            this.text2 = null;
        }

        // ************** Getters and Setters **************

        /// <summary>
        ///  Gets or Sets form title.
        /// </summary>
        public string Title
        {
            get { return this.Text; }
            set { this.Text = value; }
        }

        /// <summary>
        ///  Gets or sets form label1.
        /// </summary>
        public string Label1
        {
            get { return this.label1.ToString(); }
            set { this.label1.Text = value; }
        }

        /// <summary>
        ///  Gets or sets form label2.
        /// </summary>
        public string Label2
        {
            get { return this.label2.ToString(); }
            set { this.label2.Text = value; }
        }

        /// <summary>
        ///  Gets text1.
        /// </summary>
        public string? Text1
        {
            get { return this.text1; }
        }

        /// <summary>
        ///  Gets text2.
        /// </summary>
        public string? Text2
        {
            get { return this.text2; }
        }

        /// <summary>
        ///  Cancel button being clicked sets the values of each text to their textbox counterparts and closes the form.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        // Default winforms functions need not be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void button1_Click(object sender, EventArgs e)
        {
            this.text1 = this.textBox1.Text;
            this.text2 = this.textBox2.Text;
            this.Close();
        }

        /// <summary>
        ///  Cancel button being clicked sets the values of each text to null and closes the form.
        /// </summary>
        /// <param name="sender">
        /// s.
        /// </param>
        /// <param name="e">
        /// e.
        /// </param>
        private void button2_Click(object sender, EventArgs e)
        {
            this.text1 = null;
            this.text2 = null;
            this.Close();
        }
#pragma warning restore SA1300 // Element should begin with upper-case letter

    }
}
