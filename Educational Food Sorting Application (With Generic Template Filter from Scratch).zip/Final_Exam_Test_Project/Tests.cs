// <copyright file="Tests.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Final_Exam_Test_Project
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using FoodEngine;
    using NUnit.Framework;

    /// <summary>
    ///  Test class for the final exam project.
    /// </summary>
    public class Tests
    {
        /// <summary>
        ///  No setup required for tests to execute. Goes unused.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        ///  Tests the factory method for FoodFactory. Makes sure that the food created is of the type
        ///  requested.
        /// </summary>
        /// <param name="type">
        ///  Type of test being done. 1 = normal, 2 = boundary, 3 = exception.
        /// </param>
        /// <param name="foodType">
        ///  Type of food to be initialized.
        /// </param>
        /// <param name="newName">
        ///  New food Property.
        /// </param>
        /// <param name="newColor">
        ///  New food Property..
        /// </param>
        /// <param name="newShape">
        ///  New food Property...
        /// </param>
        /// <param name="newTexture">
        ///  New food Property......
        /// </param>
        /// <param name="newSize">
        ///  New food Property....
        /// </param>
        /// <param name="newTaste">
        ///  New food Property.....
        /// </param>
        [Test]

        // Normal tests
        [TestCase(1, "Fruit", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        [TestCase(1, "Vegetable", "NewVegetable", "VegetableColor", "VegetableShape", "VegetableTexture", "VegetableSize", "VegetableTaste")]
        [TestCase(1, "Fruit", "FruitName")]
        [TestCase(1, "Vegetable", "VegetableName")]

        // Boundary tests
        [TestCase(2, "Not a food", "Not a food name")]
        [TestCase(2, "Also not a food", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        public void TestFoodFactoryMethod(
            int type,
            string foodType,
            string newName,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Normal case
            if (type == 1)
            {
                Food? testFood;

                testFood = FoodFactory.CreateFood(foodType, newName, newColor, newShape, newTexture, newSize, newTaste);

                // If testFood is null, fail at this point since we failed to create a food object.
                if (testFood == null)
                {
                    Assert.Fail();
                }
                else
                {
                    // Make sure that each element is initialized correctly..
                    Assert.AreEqual(foodType, testFood.GetType());
                    Assert.AreEqual(newName, testFood.Name);
                    Assert.AreEqual(newColor, testFood.Color);
                    Assert.AreEqual(newShape, testFood.Shape);
                    Assert.AreEqual(newTexture, testFood.Texture);
                    Assert.AreEqual(newSize, testFood.Size);
                    Assert.AreEqual(newTaste, testFood.Taste);
                }
            }

            // Boundary case
            else if (type == 2)
            {
                Food? testFood;

                testFood = FoodFactory.CreateFood(foodType, newName, newColor, newShape, newTexture, newSize, newTaste);

                Assert.IsNull(testFood);
            }
        }

        /// <summary>
        ///  Tests the adding function for container to add new food objects.
        /// </summary>
        /// <param name="type">
        ///  Type of test being done. 1 = normal, 2 = boundary, 3 = exception.
        /// </param>
        /// <param name="foodType">
        ///  Type of food to be initialized.
        /// </param>
        /// <param name="newName">
        ///  New food Property.
        /// </param>
        /// <param name="newColor">
        ///  New food Property..
        /// </param>
        /// <param name="newShape">
        ///  New food Property...
        /// </param>
        /// <param name="newTexture">
        ///  New food Property......
        /// </param>
        /// <param name="newSize">
        ///  New food Property....
        /// </param>
        /// <param name="newTaste">
        ///  New food Property.....
        /// </param>
        [Test]

        // Normal tests
        [TestCase(1, "Fruit", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        [TestCase(1, "Vegetable", "NewVegetable", "VegetableColor", "VegetableShape", "VegetableTexture", "VegetableSize", "VegetableTaste")]
        [TestCase(1, "Fruit", "NewFruit")]
        [TestCase(1, "Vegetable", "NewVegetable")]

        // Boundary tests
        [TestCase(2, "Not a food", "Not a food name")]
        [TestCase(2, "Also not a food", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        public void TestContainerAddFood(
            int type,
            string foodType,
            string newName,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Normal tests
            if (type == 1)
            {
                Container testContainer = new Container(foodType, "name");

                // Test adding the food
                Assert.AreEqual(1, testContainer.AddFood(foodType, newName, newColor, newShape, newTexture, newSize, newTaste));

                // Test making sure a food can't be added if it already exists.
                Assert.AreEqual(0, testContainer.AddFood(foodType, newName, newColor, newShape, newTexture, newSize, newTaste));
            }

            // Boundary tests
            else if (type == 2)
            {
                Container testContainer = new Container(foodType, "name");

                Assert.AreEqual(0, testContainer.AddFood(foodType, newName, newColor, newShape, newTexture, newSize, newTaste));
            }
        }

        /// <summary>
        ///  Tests modification of food items within the foodList in container.
        ///  requested.
        /// </summary>
        /// <param name="type">
        ///  Type of test being done. 1 = normal, 2 = boundary, 3 = exception.
        /// </param>
        /// <param name="foodType">
        ///  Type of food to be initialized.
        /// </param>
        /// <param name="newName">
        ///  New food Property.
        /// </param>
        /// <param name="newColor">
        ///  New food Property..
        /// </param>
        /// <param name="newShape">
        ///  New food Property...
        /// </param>
        /// <param name="newTexture">
        ///  New food Property......
        /// </param>
        /// <param name="newSize">
        ///  New food Property....
        /// </param>
        /// <param name="newTaste">
        ///  New food Property.....
        /// </param>
        [Test]

        // Normal tests
        [TestCase(1, "Fruit", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        [TestCase(1, "Vegetable", "NewVegetable", "VegetableColor", "VegetableShape", "VegetableTexture", "VegetableSize", "VegetableTaste")]
        [TestCase(1, "Fruit", "NewFruit")]
        [TestCase(1, "Vegetable", "NewVegetable")]

        // Boundary tests
        [TestCase(2, "Fruit", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        [TestCase(2, "Vegetable", "NewVegetable", "VegetableColor", "VegetableTexture", "VegetableShape", "VegetableSize", "VegetableTaste")]
        public void TestContainerModifyFood(
            int type,
            string foodType,
            string newName,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Normal tests
            if (type == 1)
            {
                Container testContainer = new Container(foodType, "name");

                Assert.AreEqual(1, testContainer.AddFood(foodType, newName));

                Assert.AreEqual(1, testContainer.ModifyFood(newName, newName + " string", newColor, newShape, newTexture, newSize, newTaste));
            }

            // Boundary tests
            else if (type == 2)
            {
                Container testContainer = new Container(foodType, "name");

                Assert.AreEqual(1, testContainer.AddFood(foodType, newName));
                Assert.AreEqual(1, testContainer.AddFood(foodType, "testName"));

                // Test to make sure the name can't be modified to match an existing name.
                Assert.AreEqual(0, testContainer.ModifyFood(newName, "testName"));

                // Test to make sure the name of something not in the container can't be modified
                Assert.AreEqual(0, testContainer.ModifyFood(newName + " arbitrary string", "testName"));
            }
        }

        /// <summary>
        ///  Tests removal of food items within the foodList in container.
        ///  requested.
        /// </summary>
        /// <param name="type">
        ///  Type of test being done. 1 = normal, 2 = boundary, 3 = exception.
        /// </param>
        /// <param name="foodType">
        ///  Type of food to be initialized.
        /// </param>
        /// <param name="newName">
        ///  New food Property.
        /// </param>
        /// <param name="newColor">
        ///  New food Property..
        /// </param>
        /// <param name="newShape">
        ///  New food Property...
        /// </param>
        /// <param name="newTexture">
        ///  New food Property......
        /// </param>
        /// <param name="newSize">
        ///  New food Property....
        /// </param>
        /// <param name="newTaste">
        ///  New food Property.....
        /// </param>
        [Test]

        // Normal tests
        [TestCase(1, "Fruit", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        [TestCase(1, "Vegetable", "NewVegetable", "VegetableColor", "VegetableTexture", "VegetableShape", "VegetableSize", "VegetableTaste")]
        [TestCase(1, "Fruit", "NewFruit")]
        [TestCase(1, "Vegetable", "NewVegetable")]

        // Boundary tests
        [TestCase(2, "Fruit", "NewFruit", "FruitColor", "FruitShape", "FruitTexture", "FruitSize", "FruitTaste")]
        [TestCase(2, "Vegetable", "NewVegetable", "VegetableColor", "VegetableTexture", "VegetableShape", "VegetableSize", "VegetableTaste")]
        public void TestContainerRemoveFood(
            int type,
            string foodType,
            string newName,
            string? newColor = null,
            string? newShape = null,
            string? newTexture = null,
            string? newSize = null,
            string? newTaste = null)
        {
            // Normal tests
            if (type == 1)
            {
                Container testContainer = new Container(foodType, "name");

                Assert.AreEqual(1, testContainer.AddFood(foodType, newName));

                Assert.AreEqual(1, testContainer.RemoveFood(newName));
            }

            // Boundary tests
            else if (type == 2)
            {
                Container testContainer = new Container(foodType, "name");

                Assert.AreEqual(1, testContainer.AddFood(foodType, newName));

                // Test to make sure the removal function won't remove if the name can't be found.
                Assert.AreEqual(0, testContainer.RemoveFood(newName + "arbitrary string"));

                // Test to make sure the removal function won't remove the name after it has already been removed.
                Assert.AreEqual(1, testContainer.RemoveFood(newName));
                Assert.AreEqual(0, testContainer.RemoveFood(newName));
            }
        }

        /// <summary>
        /// Tests adding, modifying, and removing from the table food list.
        /// </summary>
        [Test]
        public void TestAddModifyRemoveTableFoodList()
        {
            Table testTable = new Table();

            // Adding a food like normal
            testTable.AddFood("Vegetable", "VegetableName");
            Assert.IsTrue(testTable.FoodList.Count == 1);

            // Making sure we can't add food that already exist. (Nothing is inserted)
            testTable.AddFood("Vegetable", "VegetableName");
            Assert.IsTrue(testTable.FoodList.Count == 1);

            // Make sure we can modify elements of food
            testTable.ModifyFood("VegetableName", "VegetableName", "NewColor");
            Assert.IsTrue(testTable.FoodList[0].Color == "NewColor");

            // Make sure we can't modify food to be the same name as another food
            testTable.AddFood("Vegetable", "AnotherVegetableName");
            testTable.ModifyFood("VegetableName", "AnotherVegetableName", "NewColor");
            Assert.IsTrue(testTable.FoodList[0].Name == "VegetableName");

            // Make sure we can remove food from the list
            testTable.RemoveFood("AnotherVegetableName");
            testTable.RemoveFood("VegetableName");
            Assert.IsTrue(testTable.FoodList.Count == 0);
        }

        /// <summary>
        ///  Tests adding, modifying, and removing from the table container list.
        /// </summary>
        [Test]
        public void TestAddModifyRemoveTableContainerList()
        {
            Table testTable = new Table();

            // Adding a container like normal
            testTable.AddContainer("VegetableContainer", "Vegetable");
            Assert.IsTrue(testTable.ContainerList.Count == 1);
            Assert.IsTrue(testTable.ContainerList[0].ContainerType == "Vegetable");

            // Making sure we can't add containers that already exist. (Nothing is inserted)
            testTable.AddContainer("VegetableContainer", "Vegetable");
            Assert.IsTrue(testTable.ContainerList.Count == 1);

            // Make sure we add to containers in the containers list and that we can't add food items already in the list to the container.
            testTable.AddFood("Vegetable", "VegetableName");
            Assert.IsTrue(testTable.FoodList.Count == 1);
            testTable.AddFoodToContainer("VegetableName", "VegetableContainer");
            Assert.IsTrue(testTable.ContainerList[0].FoodList.Count == 1);
            testTable.AddFoodToContainer("VegetableName", "VegetableContainer");
            Assert.IsTrue(testTable.ContainerList[0].FoodList.Count == 1);

            // Make sure we can't modify container to be the same name as another container
            testTable.AddContainer("VegetableContainer2", "Vegetable");
            testTable.ModifyContainer("VegetableContainer", "VegetableContainer2");
            Assert.IsTrue(testTable.ContainerList[0].Name == "VegetableContainer");

            // Make sure we can modify container name
            testTable.ModifyContainer("VegetableContainer", "VegetableContainer3");
            Assert.IsTrue(testTable.ContainerList[0].Name == "VegetableContainer3");

            // Make sure we can remove food from the list
            testTable.RemoveContainer("VegetableContainer3");
            testTable.RemoveContainer("VegetableContainer2");
            Assert.IsTrue(testTable.ContainerList.Count == 0);
        }

        /// <summary>
        ///  Tests filtering containers by food property.
        /// </summary>
        [Test]
        public void TestFilter()
        {
            // Make a new filter with a vegetable filter object.
            Filter<Food> testFilter = new Filter<Food>();
            testFilter.FilterObject = new Vegetable("vegetableName", "Yellow");

            // Initialize a list and add items that would be filtered and ones that won't
            List<Food> testList = new List<Food>();
            Food matchingItem = new Vegetable("testName", "Yellow");
            Food mismatchingItem = new Fruit("testName", "Blue");
            testList.Add(matchingItem);
            testList.Add(mismatchingItem);
            testList.Add(matchingItem);
            testList.Add(matchingItem);
            testList.Add(mismatchingItem);

            // Filter the list.
            List<Food>? filteredList = testFilter.FilterObjects(testList);

            // If the list is null, we fail here.
            if (filteredList == null)
            {
                Assert.Fail();
                return;
            }

            // If the list contains the matching item, pass.
            Assert.IsTrue(filteredList.Contains(matchingItem) == true);

            // If the list doesn't contain the mismatching item, pass
            Assert.IsTrue(filteredList.Contains(mismatchingItem) == false);

            // If there 1 filtered object as all 3 should be accepted, but if the object is already in the list once, no more instants can be added.
            Assert.IsTrue(filteredList.Count == 1);

            // Add another match item to the list and make sure the count is two after filtering
            Food matchingItem2 = new Vegetable("testName2", "Yellow");
            testList.Add(matchingItem2);
            filteredList = testFilter.FilterObjects(testList);

            // If the list is null, we fail here.
            if (filteredList == null)
            {
                Assert.Fail();
                return;
            }

            // "make sure the count is two after filtering"
            Assert.IsTrue(filteredList.Count == 2);
        }
    }
}