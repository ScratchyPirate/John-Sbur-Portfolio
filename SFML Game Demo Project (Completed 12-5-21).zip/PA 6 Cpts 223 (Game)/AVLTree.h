#pragma once


/*
	PA 6
	File Collaborators: John Sbur Jerry Fregoso
	Created: 12/4/20
	Last Updated: 12/11/20

	Purpose: Store and balance objects in a data structure so drawing can be efficient

*/

#include "AVLNode.h"

//Used from John Sbur's PA 3
template <class NODETYPE>
class AVLTree {

private:

	NODETYPE* root;
	string label;

public:

	//Default constructor
	AVLTree(){

		root = NULL;
		label = "";

	}


	//Destructor
	~AVLTree() {

		this->clear();
		label = "";

	}


	//Setters and Getters
	void set_root(NODETYPE* address) {
		root = address;
	}
	void set_label(string new_label) {
		label = new_label;
	}
	NODETYPE* get_root() {
		return root;
	}
	string get_label() {
		return label;
	}


	//Checks to see if the tree is empty
	int isEmpty() {

		if (root != NULL) {
			return 0;
		}
		else {
			return 1;

		}
	}


	//Returns height of the entered node
	int height(AVLNode<Object>* current) {

		return current->get_height();

	}


	//Insert function and its helper. Helper balances as it inserts
	void insert(Object new_data) {

		//Create new_node based on inputted data
		AVLNode<Object>* new_node = new AVLNode<Object>(1, nullptr, nullptr, new_data);

		//Insert the node through the tree if the tree isn't empty. Make the root the node if the tree is empty
		if (root == nullptr) {

			this->set_root(new_node);

		}
		else {

			this->set_root(insert_helper(new_node, root));
			
		}

	}
	AVLNode<Object>* insert_helper(AVLNode<Object>* target_node, AVLNode<Object>* current) {

		//Get data for comparison
		Object* current_data = nullptr;
		Object* target_data = new Object(target_node->get_data());
		AVLNode<Object>* current_left = nullptr;
		AVLNode<Object>* current_right = nullptr;
		Object* current_left_data = nullptr;
		Object* current_right_data = nullptr;
		bool current_initialized = false;
		bool left_initialized = false;
		bool right_initialized = false;

		//Makes sure there's no access violations
		if (current != nullptr) {

			current_data = new Object(current->get_data());
			current_initialized = true;

			current_left = current->get_left();
			current_right = current->get_right();

			if (current_left != nullptr) {
				current_left_data = new Object(current_left->get_data());
				left_initialized = true;
			}
			if (current_right != nullptr) {
				current_right_data = new Object(current_right->get_data());
				right_initialized = true;
			}

		}

		//If there isn't anything here, set the leaf to the target
		if (current_initialized == false) {
			return target_node;
		}

		//Initialize balance_factor
		int balance_factor = 0;

		//Do recursive insertion
		if (current_data->get_ID() > target_data->get_ID()) {

			current->set_left(insert_helper(target_node, current->get_left()));

		}
		else if(current_data->get_ID() <=  target_data->get_ID()){

			current->set_right(insert_helper(target_node, current->get_right()));

		}
		
		//Sets the height of the current node in the recursion
		current->set_height(1 + this->find_max_between_2_heights(current));

		//Get the balance factor to see if the subtree is balanced
		if (current->get_left() == NULL && current->get_right() == NULL) {
			balance_factor = 0;
		}
		else if (current->get_left() == NULL) {
			balance_factor = height(current->get_right()) * -1;
		}
		else if (current->get_right() == NULL) {
			balance_factor = height(current->get_left());
		}
		else {
			balance_factor = height(current->get_left()) - height(current->get_right());
		}
		//balance_factor = height(current->get_left()) - height(current->get_right());
		

		//Left Left
		//if (left_initialized) {
			if (balance_factor > 1 && target_data->get_ID() < current_left_data->get_ID()) {

				return rotate_right(current);

			}
		//}
		//if (right_initialized) {
			//Right Right
			if (balance_factor < -1 && target_data->get_ID() > current_right_data->get_ID()) {

				return rotate_left(current);

			}
		//}
		//if (left_initialized && right_initialized) {
			//Left Right
			if (balance_factor > 1 && target_data->get_ID() > current_left_data->get_ID())
			{
				current->set_left(rotate_left(current->get_left()));
				return rotate_right(current);
			}
			//Right Left
			if (balance_factor < -1 && target_data->get_ID() < current_right_data->get_ID())
			{
				current->set_right(rotate_right(current->get_right()));
				return rotate_left(current);

			}
		//}
		
		
	
		return current;

	}


	//Remove function and its helper. Balances as it recursively removes
	void remove(Object target) {

		if (root != nullptr) {

			this->set_root(remove_helper(root, target));

		}
		else {

			cout << endl << endl << "REMOVE FAIL: Nothing to remove" << endl << endl;

		}

	}
	AVLNode<Object>* remove_helper(AVLNode<Object>* current, Object target) {

		//Get data for comparison
		Object* current_data = nullptr;
		AVLNode<Object>* current_left = nullptr;
		AVLNode<Object>* current_right = nullptr;
		Object* current_left_data = nullptr;
		Object* current_right_data = nullptr;
		bool current_initialized = false;
		bool left_initialized = false;
		bool right_initialized = false;

		AVLNode<Object>* temp;

		//Makes sure there's no access violations
		if (current != nullptr) {

			current_data = new Object(current->get_data());
			current_initialized = true;

			current_left = current->get_left();
			current_right = current->get_right();

			if (current_left != nullptr) {
				current_left_data = new Object(current_left->get_data());
				left_initialized = true;
			}
			if (current_right != nullptr) {
				current_right_data = new Object(current_right->get_data());
				right_initialized = true;
			}

		}

		//If there isn't anything here, set the leaf to the target
		if (current_initialized == false) {
			return current;
		}


		//Recursively look for node to delete. Deletes node if the data matches the target
		if (target.get_ID() == current_data->get_ID()) {

			//No leaves case
			if (!left_initialized && !right_initialized) {

				delete current;

			}
			//1 Leaf case
			else if (!right_initialized) {

				temp = new AVLNode<Object>(current->get_left());
				*current = *temp;
				delete temp;

			}
			else if (!left_initialized) {

				temp = new AVLNode<Object>(current->get_right());
				*current = *temp;
				delete temp;

			}
			//2 Leaves case			
			else {
				
				temp = new AVLNode<Object>(find_min_node_helper(current->get_right()));
				current->set_data(temp->get_data());
				current->set_right(remove_helper(current->get_right(), temp->get_data()));

			}

		}
		else if (target.get_ID() < current_data->get_ID()) {

			current->set_left(remove_helper(current->get_left(), target));

		}
		else if (target.get_ID() >= current_data->get_ID()) {

			current->set_right(remove_helper(current->get_right(), target));

		}

		//Check to see if the current was changed to null
		if (current == nullptr) {
			return current;
		}

		
		//Sets the height of the current node in the recursion after changes are made
		current->set_height(1 + this->find_max_between_2_heights(current));

		//Initialize balance_factor
		int balance_factor = 0;

		//Get the balance factor to see if the subtree is balanced after deletion
		if (current->get_left() == NULL && current->get_right() == NULL) {
			balance_factor = 0;
		}
		else if (current->get_left() == NULL) {
			balance_factor = height(current->get_right()) * -1;
		}
		else if (current->get_right() == NULL) {
			balance_factor = height(current->get_left());
		}
		else {
			balance_factor = height(current->get_left()) - height(current->get_right());
		}

		//Left Left
		if (balance_factor > 1 && height(current_left->get_left()) - height(current_left->get_right()) >= 0) {

			return rotate_right(current);

		}		
		//Left Right
		else if (balance_factor > 1 && height(current_left->get_left()) - height(current_left->get_right()) < 0){

			return rotate_right(current);

		}
		//Right Right
		else if (balance_factor < -1 && height(current_right->get_left()) - height(current_right->get_right()) <= 0) {

			return rotate_left(current);

		}
		//Right Left
		else if (balance_factor < -1 && height(current_right->get_left()) - height(current_right->get_right()) > 0)
		{

			return rotate_left(current);

		}
		

		return current;

	}


	//Deletes all members in the tree
	void clear() {

		if (this->root != NULL) {
			this->clear_helper(this->root);
		}

		this->root = NULL;
	}


	//Clears the entered subtree
	void clear_helper(AVLNode<Object>* target_root) {

		if (target_root != NULL) {

			clear_helper(target_root->get_left());
			clear_helper(target_root->get_right());
			delete target_root;

		}

	}


	//Finds max and min cancer rates in the tree with their helpers
	float findMax() {

		return this->find_max_helper(root);

	}
	float find_max_helper(AVLNode<Object>* root) {

		if (!root->get_right()) {
			Object* temp = new Object(root->get_data());
			return temp->get_ID();
		}
		
		return find_max_helper(root->get_right());

	}
	float findMin() {

		return this->find_min_helper(root);

	}
	float find_min_helper(AVLNode<Object>* root) {

		if (!root->get_left()) {
			Object* temp = new Object(root->get_data());
			return temp->get_ID();
		}

		return find_min_helper(root->get_left());

	}
	//Finds the nodes that contain the max and min values
	AVLNode<Object>* find_max_node() {

		return this->find_max_node_helper(root);

	}
	AVLNode<Object>* find_max_node_helper(AVLNode<Object>* root) {

		if (!root->get_right()) {
			return root;
		}

		return find_max_node_helper(root->get_right());

	}
	AVLNode<Object>* find_min_node() {

		return this->find_min_node_helper(root);

	}
	AVLNode<Object>* find_min_node_helper(AVLNode<Object>* root) {

		if (!root->get_left()) {
			return root;
		}

		return find_min_node_helper(root->get_left());

	}


	//Print in reverse order and its helper
	void printInOrder(sf::RenderWindow* target_window) {

		this->print_helper(this->root, target_window);

	}
	void print_helper(AVLNode<Object>* root, sf::RenderWindow* target_window) {

		if (!root) {
			return;
		}

		print_helper(root->get_left(), target_window);

		Object* temp = new Object(root->get_data());
		
		temp->drawObject(target_window);

		print_helper(root->get_right(), target_window);

	}

	//Special print all for bullets (Unused in final)
	void print_bullets(sf::RenderWindow* target_window) {

		int target = -1; 
		this->print_bullets_helper(this->root, target_window, &target);

		
		if (target != -1) {
			Object temp;
			temp.set_ID(target);
			this->remove(temp);
		}
		
	}
	void print_bullets_helper(AVLNode<Object>* root, sf::RenderWindow* target_window, int* destroy_target) {

		if (!root) {
			return;
		}

		print_bullets_helper(root->get_left(), target_window, destroy_target);

		Object* temp = new Object(root->get_data());

		//funny spin bullet
		temp->set_rotation(temp->get_rotation() + 20);

		//move bullet. check to see if it's on screen and if not, get rid of it to save memory
		if (temp->get_name() == "d") {
			temp->moveObject('d', 10);
			if (temp->get_object_position().y > 1100) {
				*destroy_target = temp->get_ID();
			}
			temp->drawObject(target_window);
			root->set_data(*temp);
		}
		else if (temp->get_name() == "u") {
			temp->moveObject('u', 10);
			if (temp->get_object_position().y < -100) {
				*destroy_target = temp->get_ID();
			}
			temp->drawObject(target_window);
			root->set_data(*temp);
		}
		else if (temp->get_name() == "l") {
			temp->moveObject('l', 10);
			if (temp->get_object_position().x < -100) {
				*destroy_target = temp->get_ID();
			}
			temp->drawObject(target_window);
			root->set_data(*temp);
		}
		else {
			temp->moveObject('r', 10);
			if (temp->get_object_position().x > 1100) {
				*destroy_target = temp->get_ID();
			}
			temp->drawObject(target_window);
			root->set_data(*temp);
		}

		print_bullets_helper(root->get_right(), target_window, destroy_target);
	

	}

	//finds max value between 2 heights of subtrees
	int find_max_between_2_heights(AVLNode<Object>* node) {

		if (node != nullptr) {

			AVLNode<Object>* left = node->get_left();
			AVLNode<Object>* right = node->get_right();

			if (left == nullptr && right == nullptr) {
				return 0;
			}
			else if (left == nullptr) {
				return right->get_height();
			}
			else if (right == nullptr) {
				return left->get_height();
			}
			else if (left->get_height() > right->get_height()) {
				return left->get_height();
			}
			else {
				return right->get_height();
			}

		}
		else {
			return 0;
		}
		

	}


	//Rotation functions
	AVLNode<Object>* rotate_left(AVLNode<Object>* current) {

		//Create nodes to hold nodes as they rotate
		AVLNode<Object>* temp1 = current->get_right();
		AVLNode<Object>* temp2 = temp1->get_left();

		//Rotate left
		/*
			c			1
			 \		   /
			  1 ----> c
			 /		   \
			2		    2
		*/
		temp1->set_left(current);
		current->set_right(temp2);


		//Make heights accurate after rotation  
		current->set_height(find_max_between_2_heights(current) + 1);
		temp1->set_height(find_max_between_2_heights(temp1) + 1);
		//temp2 height remains unchanged

		return temp1;

	}
	AVLNode<Object>* rotate_right(AVLNode<Object>* current) {

		//Create nodes to hold nodes as they rotate
		AVLNode<Object>* temp1 = current->get_left();
		AVLNode<Object>* temp2 = temp1->get_right();

		//Rotate right
		/*
			c			1
		   /			 \
		  1     ---->     c
		   \		     /
			2		    2

		*/
		temp1->set_right(current);
		current->set_left(temp2);

		//Make heights accurate after rotation  
		current->set_height(find_max_between_2_heights(current) + 1);
		temp1->set_height(find_max_between_2_heights(temp1) + 1);
		//temp2 height remains unchanged

		return temp1;

	}
	
};