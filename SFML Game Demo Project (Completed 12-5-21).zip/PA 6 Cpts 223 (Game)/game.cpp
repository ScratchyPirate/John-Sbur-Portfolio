/*
    PA 6
    File Collaborators: John Sbur Jerry Fregoso
    Created: 12/4/20
    Last Updated: 12/11/20

    Purpose: Simulate the game and define any game related functions

*/

#include "AVLTree.h"
#include "Object.h"
#include "Texture_Data.h"
#include "Map.h"

//Checks to see if 2 objects have collided. Return 1 if true and 0 if false
int check_collision(Object object1, Object object2) {

    if (object1.get_x() + object1.get_dimensions().x / 4 > object2.get_x() && object1.get_x() - object1.get_dimensions().x / 4 < object2.get_x()) {

        if (object1.get_y() + object1.get_dimensions().y / 4 > object2.get_y() && object1.get_y() - object1.get_dimensions().y / 4 < object2.get_y()) {
            return 1;
        }

    }
    return 0;

}

//Checks and only removes 1 enemy and bullet at a time so as to avoid slow down
int mass_check_bullet_collision(list<Object>* bullets, list<Object>* enemies) {

    for (list<Object>::iterator e = enemies->begin(); e != enemies->end(); e++) {

        for (list<Object>::iterator b = bullets->begin(); b != bullets->end(); b++) {

            if (check_collision(*e, *b) && b->get_property() == texture_property::PLAYER) {
                bullets->erase(b);
                enemies->erase(e);
                return 1;
            }          

        }

    }
    return 0;

}

//Checks and removes health if hit by an enemy bullet
int mass_check_enemy_bullet_collision(list<Object>* bullets, Object* player) {

    for (list<Object>::iterator b = bullets->begin(); b != bullets->end(); b++) {

        if (check_collision(*player, *b) && b->get_property() == texture_property::ENEMY) {
            bullets->erase(b);
            return 1;
        }

    }
    return 0;
}

//Print all for enemies
void print_enemies(list<Object>* enemies, sf::RenderWindow* active_window, list<Object>* bullets, Object player) {

    //set up bullet in case of shoot
    Object enemy_bullet("bullet.png", 0, 0, .4, .4, 10, 10, texture_property::ENEMY, "r", 0, 1);


    for (list<Object>::iterator i = enemies->begin(); i != enemies->end(); i++) {

        //Move up and down in a preset pattern
        if (i->get_name() != "d" && i->get_name() != "u") {
            i->set_name("u");
            i->set_ID(0);
        }
        else if (i->get_name() == "d") {
            if (i->get_ID() < 4) {
                i->moveObject('d', 10);
                i->set_ID(i->get_ID() + 1);
                /*if (i->get_path() == "front_enemy.png") {
                    i->changeTexture("front_enemy_walk.png");
                }*/
                if (i->get_path() == "front_enemy.png") {
                    i->changeTexture("front_enemy_walk.png");
                }
                else if(i->get_path() == "front_good_guy_walk.png") {
                    i->changeTexture("front_good_guy.png");
                }
            }
            else {
                i->set_ID(0);
                i->set_name("u");
            }
        }
        else if (i->get_name() == "u") {
            if (i->get_ID() < 4) {
                i->moveObject('u', 10);
                i->set_ID(i->get_ID() + 1);
                /*if (i->get_path() == "front_enemy_walk.png") {
                    i->changeTexture("front_enemy.png");
                }*/
                if (i->get_path() == "front_enemy_walk.png") {
                    i->changeTexture("front_enemy.png");
                }
                else if(i->get_path() == "front_good_guy.png"){
                    i->changeTexture("front_good_guy_walk.png");
                }
            }
            else {
                i->set_ID(0);
                i->set_name("d");
            }
        }

        //Determine when to shoot
        if (i->get_y() > player.get_y() && i->get_y() < player.get_y() + player.get_dimensions().y / 2 && i->get_ID() == 0) {

            if (player.get_x() < i->get_x()) {
                enemy_bullet.set_ID(0);
                enemy_bullet.setObjectPosition(i->get_x(), i->get_y());
                enemy_bullet.set_name("l");               
            }
            else {
                enemy_bullet.set_ID(0);
                enemy_bullet.setObjectPosition(i->get_x(), i->get_y());
                enemy_bullet.set_name("r");
            }
            enemy_bullet.changeTexture("bullet.png");

            bullets->push_front(enemy_bullet);

        }

        i->drawObject(active_window);

    }

}

//Special print all case for bullets. Cleans up out of range bullets as it goes
void print_bullets(list<Object>* bullets, sf::RenderWindow* active_window) {

    //Deletes bullets out of bounds
    Object temp = bullets->front();

    //check to see if it's on screen and if not, get rid of it to save memory (just front to save on time)
    if (temp.get_name() == "d" && temp.get_object_position().y > 1100) {
        bullets->pop_front();
    }
    else if (temp.get_name() == "u" && temp.get_object_position().y < -100) {
        bullets->pop_front();
    }
    else if (temp.get_name() == "l" && temp.get_object_position().x < -100) {
        bullets->pop_front();
    }
    else if (temp.get_object_position().x > 1100) {
        bullets->pop_front();
    }


    for (list<Object>::iterator i = bullets->begin(); i != bullets->end(); i++) {


        //funny spin bullet
        i->set_rotation(temp.get_rotation() + 10);

        //move bullet. check to see if it's on screen and if not, get rid of it to save memory
        i->changeTexture("bullet.png");
        
        if (i->get_name() == "d") {
            i->moveObject('d', 10);
            i->drawObject(active_window);
        }
        else if (i->get_name() == "u") {
            i->moveObject('u', 10);
            i->drawObject(active_window);
        }
        else if (i->get_name() == "l") {
            i->moveObject('l', 10);
            i->drawObject(active_window);
        }
        else {
            i->moveObject('r', 10);
            i->drawObject(active_window);
        }

    }

}

//Print hearts
void print_list(list<Object>* hearts, sf::RenderWindow* active_window) {

    for (list<Object>::iterator i = hearts->begin(); i != hearts->end(); i++) {
        i->drawObject(active_window);
    }

}

//Cutscene plays when the player kills the good guy
void lose_cutscene1(sf::RenderWindow* active_window) {

    //Background
    sf::RectangleShape background(sf::Vector2f(1000, 1000));
    background.setFillColor(sf::Color::White);
    background.setPosition(0, 0);

    //Actual cutscene with 2 frames
    Object good_guy("front_good_guy.png", 0, 0, 2, 2, 100, 100, texture_property::ENEMY, "good guy", 0, 1);
    active_window->draw(background);
    good_guy.drawObject(active_window);
    active_window->display();
    Sleep(2000);
    active_window->draw(background);
    good_guy.changeTexture("front_good_guy_angry.png");
    good_guy.drawObject(active_window);
    active_window->display();
    Sleep(2000);

}

//Main game
void game(sf::RenderWindow* screen) {

    //Create holding event
    sf::Event event;

    //Background for some events
    sf::RectangleShape background(sf::Vector2f(1000, 1000));
    background.setFillColor(sf::Color::White);
    background.setPosition(0, 0);

    //Hearts representing health
    list<Object> health;
    Object heart("Heart.png", 10, 10, .1, .1);
    health.push_back(heart);
    heart.set_x(80);
    health.push_back(heart);
    heart.set_x(150);
    health.push_back(heart);


    //Load Map and create rooms
    Map gameMap;
    gameMap.createRoom1();
    gameMap.createRoom2();
    gameMap.createRoom3();
    gameMap.createOpenRoom3();

    //Initialize hurm
    Object hurm("front_character_gun.png", 50, 300, .4, .4, 100, 100, texture_property::PLAYER, "hurm", 0, 1);
    int player_health = 3;

    //Initialize friendly character and they key
    Object good_guy("front_good_guy.png", 50, 800, .4, .4, 100, 100, texture_property::ENEMY, "good guy", 0, 1);
    list<Object> good;
    good.push_back(good_guy);
    Object key("key.png", 400, 400, .2, .2, 100, 100, texture_property::ITEM, "key", 0, 1);


    //Initialize enemies (For each map)
    list<Object> map_1_enemies;
    Object temp("front_enemy.png", 800, 600, .4, .4, 200, 200, texture_property::ENEMY, "1", 0, 2);
    //Object temp("elephly_-_Copy.png", 800, 600, .4, .4, 200, 200, texture_property::ENEMY, "1", 0, 2);
    map_1_enemies.push_front(temp);
    temp.set_x(800);
    temp.set_y(800);
    map_1_enemies.push_front(temp);
    list<Object> map_2_enemies;
    Object temp2("front_enemy.png", 100, 500, .4, .4, 100, 100, texture_property::ENEMY, "2", 0, 3);
    //Object temp2("elephly_-_Copy.png", 100, 500, .4, .4, 200, 200, texture_property::ENEMY, "1", 0, 2);
    map_2_enemies.push_front(temp2);
    temp2.set_x(500);
    temp2.set_y(800);
    map_2_enemies.push_front(temp2);
    list<Object> map_3_enemies;
    temp2.set_x(0);
    temp2.set_y(200);
    map_3_enemies.push_front(temp2);
    temp2.set_x(600);
    temp2.set_y(700);
    map_3_enemies.push_front(temp2);


    //Initialize bullets
    list<Object> bullets;
    Object player_bullet("bullet.png", 0, 0, .4, .4, 10, 10, texture_property::PLAYER, "player_bullet", 0, 1);
    int player_current_bullet = 0;
    string player_direction = "l";
    Object enemy_bullet("bullet.png", 0, 0, .4, .4, 10, 10, texture_property::ENEMY, "enemy_bullet", 0, 1);
    int enemy_current_bullet = 0;

    //Player info
    Object player_info("player_info.png", 500, 10, .9, .45, 10, 10, texture_property::PLAYER, "info", 0, 1);

    //Player directions
    Object directions("directions.png", 500, 130, .9, .45, 10, 10, texture_property::PLAYER, "directions", 0, 1);

    //Game over screen
    Object game_over_screen("dead_screen.png", 0, 0, 2, 2);

    //Win screen
    Object win_screen("win_screen.png", 0, 0, 2, 2);

    //General Varibales
    int counter = 0;
    int switcher = 0;
    int switcher_good_guy = 0;
    bool has_gun = false;
    bool playing = true;
    int current_map = 1;
    int bullet_timer = 0;
    int enemies_killed = 0;
    bool has_key = false;


    //While the window for the game isn't closed
    while (screen->isOpen() && playing)
    {

        //Close screen if the window x button is pressed
        while (screen->pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                screen->close();
        }

        //Cycle animation for hurm
        if (counter == 15) {

            switch (switcher) {

            case 0:

                hurm.changeTexture("front_character_walk_gun.png");
                //hurm.setScale(.4, .4);
                counter = 0;
                switcher = 1;
                break;

            case 1:
                hurm.changeTexture("front_character_gun.png");
                //hurm.setScale(.4, .4);
                counter = 0;
                switcher = 0;
                break;

            default:
                switcher = 1;
                counter = 0;
                break;

            }
        }

        screen->clear();

        //hurm.set_rotation(hurm.get_rotation() + 10);


        if (current_map == 1) {

            //Get button inputs and move hurm accordingly. Different events happen upon different locations being met
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {

                if (hurm.get_y() >= 200) {
                    hurm.moveObject('u', 10);
                    player_direction = 'u';  
                }
               
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) {

                if (hurm.get_x() >= 0) {
                    hurm.moveObject('l', 10);
                    player_direction = "l";
                }
                
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {

                hurm.moveObject('d', 10);
                player_direction = "d";

                if (hurm.get_y() > 850 && current_map == 1) {
                    current_map = 2;
                    hurm.setObjectPosition(hurm.get_x(), 200);
                    bullets.clear();
                }
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) {
                if (hurm.get_x() <= 850) {
                    hurm.moveObject('r', 10);
                    player_direction = "r";
                }               
            }

            //Print key in map 1 when all enemies are killed           
            gameMap.Room1.printInOrder(screen);
            if (enemies_killed == 6 && !has_key) {
                key.drawObject(screen);
            }
            print_enemies(&map_1_enemies, screen, &bullets, hurm);

            //Pick up key
            if (check_collision(key, hurm) && enemies_killed == 6) {
                has_key = true;
            }

        }
        else if (current_map == 2) {

            //Get button inputs and move hurm accordingly. Different events happen upon different locations being met
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {
                hurm.moveObject('u', 10);
                player_direction = 'u';

                if (hurm.get_y() < 200) {
                    current_map = 1;
                    hurm.setObjectPosition(hurm.get_x(), 900);
                    bullets.clear();
                }

            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) {
                if (hurm.get_x() >= 0) {
                    hurm.moveObject('l', 10);
                    player_direction = "l";
                }
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {
                if (hurm.get_y() <= 850) {
                    hurm.moveObject('d', 10);
                    player_direction = "d";
                }
               
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) {
                hurm.moveObject('r', 10);
                player_direction = "r";

                if (hurm.get_x() > 850) {
                    current_map = 3;
                    hurm.setObjectPosition(0, hurm.get_y());
                    bullets.clear();
                }
            }

            gameMap.Room2.printInOrder(screen);
            print_enemies(&map_2_enemies, screen, &bullets, hurm);


        }
        else if (current_map == 3) {

            //Get button inputs and move hurm accordingly. Different events happen upon different locations being met
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {
                if (hurm.get_y() >= 200) {
                    hurm.moveObject('u', 10);
                    player_direction = 'u';
                }

            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) {
               
                hurm.moveObject('l', 10);
                player_direction = "l";
                if (hurm.get_x() < -50) {
                    current_map = 2;
                    hurm.setObjectPosition(900, hurm.get_y());
                    bullets.clear();
                }
                
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {
                if (hurm.get_y() <= 850) {
                    hurm.moveObject('d', 10);
                    player_direction = "d";
                }

            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) {
                if (has_key && hurm.get_x() + 10 > 850) {
                    playing = false;
                }
                else if (hurm.get_x() <= 850) {
                    hurm.moveObject('r', 10);
                    player_direction = "r";
                }

            }

            //If the player has the key, print out the room with the open door
            if (has_key) {
                gameMap.OpenRoom3.printInOrder(screen);
            }
            else {
                gameMap.Room3.printInOrder(screen);
            }
            print_enemies(&map_3_enemies, screen, &bullets, hurm);
            print_enemies(&good, screen, &bullets, hurm);


        }
        

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {

            if (bullet_timer == 5) {
                player_bullet.set_ID(player_current_bullet);
                player_bullet.setObjectPosition(hurm.get_x(), hurm.get_y());
                player_current_bullet++;
                player_bullet.set_name(player_direction);
                bullets.push_front(player_bullet);

                bullet_timer = 0;
            }

        }
        


        //Print out all bullets and check to see if an enemy is hit
        if (!bullets.empty()) {

            print_bullets(&bullets, screen);

            //Check if anything is hit
            if (current_map == 1 && !map_1_enemies.empty()) {
                enemies_killed += mass_check_bullet_collision(&bullets, &map_1_enemies);
            }
            else if (current_map == 2 && !map_2_enemies.empty()) {
                enemies_killed += mass_check_bullet_collision(&bullets, &map_2_enemies);
            }
            else if (current_map == 3 && (!map_3_enemies.empty() || !good.empty())) {
                enemies_killed += mass_check_bullet_collision(&bullets, &map_3_enemies);
                mass_check_bullet_collision(&bullets, &good);

                //If the good_guy is dead, end the game. Game Over
                if (good.empty()) {
                    playing = false;
                    lose_cutscene1(screen);
                    player_health = 0;
                }
            }

            //Check to see if the player is hit. act accordingly
            if (mass_check_enemy_bullet_collision(&bullets, &hurm)) {
                player_health--;
                health.pop_back();
            }
            
            //Game over if the player's health reaches 0
            if (player_health <= 0) {
                cout << "debug game over";
                playing = false;
            }

        }


        //Draw the health and player. Display everything written to screen
        print_list(&health, screen);
        hurm.drawObject(screen);
        screen->display();

        //Made so bullets can't be spammed and lag the game
        if (bullet_timer != 5) {
            bullet_timer++;
        }

        counter++;
    }

    //Print screen depending on player's result
    screen->clear();
    screen->draw(background);
    if (player_health <= 0) {
        game_over_screen.drawObject(screen);
    }
    else {
        win_screen.drawObject(screen);
    }
    screen->display();
    while (screen->isOpen() && playing == false) {

        while (screen->pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                screen->close();
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
            playing = true;
        }
    }
    
    

}

void displayHealth(sf::RenderWindow* windowPtr, int health, sf::Sprite* heartPtr) {
	//display health
	for (int i = 0; i < health; i++) {
		//draw wall to window
		heartPtr->setPosition(90 * i + 70, 65);
		windowPtr->draw(*heartPtr);
	}
}