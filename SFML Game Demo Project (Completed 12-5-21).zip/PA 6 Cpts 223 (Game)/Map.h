#ifndef MAP_H
#define MAP_H

/*
	PA 6
	File Collaborators: John Sbur Jerry Fregoso
	Created: 12/4/20
	Last Updated: 12/11/20

	Purpose: Store map data for the entire game

*/

#include "Object.h"
#include "AVLTree.h"

//The entire game map spaced out between multiple sub-maps
class Map {
public:

	//rooms 
	AVLTree<AVLNode<Object>> Room1;
	AVLTree<AVLNode<Object>> Room2;
	AVLTree<AVLNode<Object>> Room3;
	AVLTree<AVLNode<Object>> OpenRoom3;


	//global variables for map
	Object ground;

	Map() {


		//set priority
		ground.setScale(1.3, 1.7);
		ground.setObjectPosition(-10, 65);


		//create room1
		createRoom1();
		//create room2
		createRoom2();
		createRoom3();
		createOpenRoom3();


	}
	~Map() {

	}

	void createRoom1(void) {
		ground.changeTexture("Room1.png");
		ground.set_ID(1);
		//insert ground
		Room1.insert(ground);

	}
	void createRoom2(void) {
		ground.changeTexture("Room2.png");
		ground.set_ID(1);
		//insert ground
		Room2.insert(ground);
	}
	void createRoom3(void) {
		ground.changeTexture("Room3.png");
		ground.set_ID(1);
		Room3.insert(ground);
	}
	void createOpenRoom3(void) {
		ground.changeTexture("Room3Open.png");
		ground.set_ID(1);
		OpenRoom3.insert(ground);
	}

};

#endif MAP_H