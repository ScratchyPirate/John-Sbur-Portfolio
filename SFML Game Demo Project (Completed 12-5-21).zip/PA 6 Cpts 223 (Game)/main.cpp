
/*
    PA 6
    Project Collaborators: John Sbur Jerry Fregoso
    Created: 12/4/20
    Last Updated: 12/11/20

    Requirements fufilled:
    Graphics -- Using SFML
    Test Cases -- (Last updated 4/5)
    Game implemented -- Hurm's dungeon
    +Data structure used: AVL Tree (for storing map data. see Map.hpp)
    +Directions: Displayed in game
    +Game: Top-Down Dungeon Crawler. Directions in game
    Comments -- Yes they are here and there and everywhere

    Note: This game is intended to look bad as part of it's charm and wasn't a lazy attempt. The art style is 
    based on the popular game, hurm's odyssey. Here's the link to download https://blebgo.itch.io/hurms-odyssey

*/

#include "AVLTree.h"
#include "Object.h"
#include "Texture_Data.h"

int main() {

    //For random numbers
	srand(time(NULL));

    //Create Window
    sf::RenderWindow window(sf::VideoMode(1000,1000), "Hurm's Dungeon");
    sf::Event event;
    window.setFramerateLimit(20);

    //Create background in this scope
    sf::RectangleShape background(sf::Vector2f(1000, 1000));
    background.setFillColor(sf::Color::White);
    background.setPosition(0, 0);

    //Create menu object
    Object menu_object("title_screen.png", 0,0,2,2,10000,10000,texture_property::SOLID,"menu",0,1);


    //Main menu
    while (window.isOpen())
    {

        //If x is pressed, close game
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        //Start game if 1 is pressed
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num1)) {
            game(&window);
        }
        //End game if 2 is pressed
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num2)) {
            window.close();
        }
        //Start testing if 3 is pressed
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num3)) {
            test(&window);
        }
        

        //Draw and display to screen menu related objects
        window.clear();
        window.draw(background);
        menu_object.drawObject(&window);
        window.display();

    }
    

	

	return 0;

}