#ifndef HEADER_GUARD
#define HEADER_GUARD

#define _CRT_SECURE_NO_WARNINGS

/*
    PA 6
    File Collaborators: John Sbur Jerry Fregoso
    Created: 12/4/20
    Last Updated: 12/11/20

    Purpose: Store declarations for functions and also include libraries for PA 6

*/

#include <iostream>
#include <cstring>	
#include <queue>
#include <initializer_list>
#include <fstream>
#include <string>
#include <iostream>
#include <vector>
#include <list>
#include <stdexcept>
#include <stack>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace std;

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <Windows.h>
#include <conio.h>
#include <time.h>    


//menu option function declarations
void game(sf::RenderWindow* screen);
void test(sf::RenderWindow* screen);

//Properties for texture that give them different effects.
//Player (Controllable), Enemy (Interactable), Solid (Cannot walk through)
enum class texture_property {

	PLAYER, 
	ENEMY, 
	SOLID,
    ITEM

};


#endif