#ifndef OBJECT_H
#define OBJECT_H

/*
	PA 6
	File Collaborators: John Sbur Jerry Fregoso
	Created: 12/4/20
	Last Updated: 12/11/20

	Purpose: Create a class to house individual objects used in the game

*/

#include "declarations.h"

//Object class. Used for storing sprite data and texture data for each game object.
class Object {
private:

	sf::Texture aTexture;
	sf::Sprite aSprite;
	string path;
	int ID;
	double x;
	double y;
	sf::Vector2f scale;
	texture_property this_property;
	string name;
	double angle;

public:

	//Default constructor
	Object() {

		path = "";
		ID = 0;
		x = 0.0;
		y = 0.0;
		this_property = texture_property::PLAYER;
		name = "";

	}

	//Explicit constructor
	Object(std::string imgDirectory) {
		if (!aTexture.loadFromFile(imgDirectory)) {
			std::cerr << "Error\n";
		}
		path = imgDirectory;
		aSprite.setTexture(aTexture);
		scale = aSprite.getScale();
		path = "";
		ID = 0;
		x = 0.0;
		y = 0.0;
		this_property = texture_property::PLAYER;
		name = "";
		angle = 0;
	}

	//Explicit constructor
	Object(std::string imgDirectory, float positionX, float positionY) {
		if (!aTexture.loadFromFile(imgDirectory)) {
			std::cerr << "Error\n";
		}
		path = imgDirectory;
		aSprite.setTexture(aTexture);
		scale = aSprite.getScale();
		aSprite.setPosition(positionX, positionY);
		path = imgDirectory;
		ID = 0;
		x = positionX;
		y = positionY;
		this_property = texture_property::PLAYER;
		name = "";
		angle = 0;
	}

	//Explicit constructor
	Object(std::string imgDirectory, float positionX, float positionY, float scaleX, float scaleY) {
		if (!aTexture.loadFromFile(imgDirectory)) {
			std::cerr << "Error\n";
		}
		path = imgDirectory;
		aSprite.setTexture(aTexture);
		scale = aSprite.getScale();
		aSprite.setPosition(positionX, positionY);
		aSprite.setScale(scaleX, scaleY);
		path = imgDirectory;
		ID = 0;
		x = positionX;
		y = positionY;
		this_property = texture_property::PLAYER;
		name = "";
		angle = 0;
	}

	//Explicit constructor
	Object(string imgDirectory, float positionX, float positionY, float scaleX, float scaleY, float dimensionx, float dimensiony, texture_property new_property, string new_name, double new_angle, int new_id) {
		if (!aTexture.loadFromFile(imgDirectory)) {
			std::cerr << "Error\n";
		}
		this->changeTexture(imgDirectory);
		path = imgDirectory;
		aSprite.setTexture(aTexture);
		scale = aSprite.getScale();
		aSprite.setPosition(positionX, positionY);
		aSprite.setScale(scaleX, scaleY);
		path = imgDirectory;
		ID = new_id;
		x = positionX;
		y = positionY;
		this_property = new_property;
		name = new_name;
		angle = new_angle;
		this->set_rotation(new_angle);
	}

	//Copy constructor
	explicit Object(Object* new_data) {

		this->changeTexture(new_data->get_path());

		this->setObjectPosition(new_data->get_x(), new_data->get_y());
		sf::Vector2f temp1(new_data->get_object_scale());
		this->setScale(temp1.x, temp1.y);
		this->setDimensions(new_data->get_dimensions().x, new_data->get_dimensions().y);
		this->set_ID(new_data->get_ID());
		this->set_x(new_data->get_x());
		this->set_y(new_data->get_y());
		this->set_property(new_data->get_property());
		this->set_name(new_data->get_name());
		this->set_rotation(new_data->get_rotation());

	}

	//Copy Assignment
	Object& operator=(Object& source) {

		this->changeTexture(source.get_path());

		this->setObjectPosition(source.get_x(), source.get_y());
		this->setDimensions(source.get_dimensions().x, source.get_dimensions().y);
		this->path = source.path;
		this->ID = source.ID;
		this->scale = source.scale;
		this->x = source.x;
		this->y = source.y;
		this->this_property = source.this_property;
		this->name = source.name;
		this->angle = source.angle;

		return *this;

	}

	//Texture setter and getter
	void changeTexture(string path1) {
		path = path1;
		aTexture.loadFromFile(path);
		aSprite.setTexture(aTexture);
	}
	string get_path() {
		return path;
	}

	//Draws object to inputted window
	void drawObject(sf::RenderWindow* windowPtr) {
		aSprite.scale(scale);
		aSprite.rotate(angle);
		windowPtr->draw(aSprite);
	}

	//Setters and Getters
	void setObjectPosition(float new_x, float new_y) {
		aSprite.setPosition(new_x, new_y);
		x = new_x;
		y = new_y;
	}
	void setScale(float new_x, float new_y) {
		aSprite.setScale(new_x, new_y);
		scale = aSprite.getScale();
	}
	void setDimensions(float new_x, float new_y) {
		sf::Vector2f targetSize(new_x, new_y);
		aSprite.setScale(targetSize.x / aSprite.getLocalBounds().width, targetSize.y / aSprite.getLocalBounds().height);
	}
	void set_ID(int new_id) {
		ID = new_id;
	}
	void set_x(double new_x) {
		x = new_x;
		aSprite.setPosition(new_x, y);
	}
	void set_y(double new_y) {
		y = new_y;
		aSprite.setPosition(x, new_y);
	}
	void set_property(texture_property new_property) {
		this_property = new_property;
	}
	void set_name(string new_name) {
		name = new_name;
	}
	void set_rotation(float new_angle) {
		aSprite.rotate(-angle);
		aSprite.rotate(new_angle);
		angle = new_angle;
	}

	sf::Vector2f get_object_position() {
		sf::Vector2f this_position(x, y);
		return this_position;
	}
	sf::Vector2f get_object_scale() {
		return aSprite.getScale();
	}
	sf::Vector2f get_dimensions() {
		sf::Vector2f this_dimensions(aSprite.getLocalBounds().width, aSprite.getLocalBounds().height);
		return this_dimensions;
	}
	int get_ID() {
		return ID;
	}
	double get_x() {
		return x;
	}
	double get_y() {
		return y;
	}
	texture_property get_property() {
		return this_property;
	}

	void set_property(char x) {
		if (x == 's') {
			this_property = texture_property::SOLID;
		}
		else if (x == 'e') {
			this_property = texture_property::ENEMY;
		}
	}
	string get_name() {
		return name;
	}
	float get_rotation() {
		return angle;
	}

	//Moves the object by changing it's position
	void moveObject(char direction, float moveSpeed) {
		sf::Vector2f position;
		if (direction == 'u') {
			aSprite.move(0, -moveSpeed);
		}
		else if (direction == 'd') {
			aSprite.move(0, moveSpeed);
		}
		else if (direction == 'l') {
			aSprite.move(-moveSpeed, 0);
		}
		else if (direction == 'r') {
			aSprite.move(moveSpeed, 0);
		}
		position = aSprite.getPosition();
		x = position.x;
		y = position.y;
	}
};


//Object related functions
int check_collision(Object object1, Object object2);
int mass_check_bullet_collision(list<Object>* bullets, list<Object>* enemies);
int mass_check_enemy_bullet_collision(list<Object>* bullets, Object* player);
void print_enemies(list<Object>* enemies, sf::RenderWindow* active_window, list<Object>* bullets, Object player);
void print_bullets(list<Object>* bullets, sf::RenderWindow* active_window);
void print_list(list<Object>* hearts, sf::RenderWindow* active_window);

#endif