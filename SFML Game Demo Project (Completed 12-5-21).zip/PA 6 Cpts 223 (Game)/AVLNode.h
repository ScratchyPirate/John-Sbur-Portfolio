#pragma once


/*
	PA 6
	File Collaborators: John Sbur Jerry Fregoso
	Created: 12/4/20
	Last Updated: 12/11/20

	Purpose: Store data for the AVL tree

*/

#include "Object.h"

//Used from John Sbur's PA 3
//DATATYPE is always Object for this project
template <class DATATYPE>
class AVLNode {

private:

	DATATYPE Data;
	AVLNode<DATATYPE>* left;
	AVLNode<DATATYPE>* right;
	int height;


public:

	//Default Constructor
	AVLNode() {

		left = NULL;
		right = NULL;
		height = 0;

	}

	//Copy constructor
	AVLNode(int new_height, AVLNode<DATATYPE>* new_left, AVLNode<DATATYPE>* new_right, DATATYPE new_data) {

		height = new_height;
		left = new_left;
		right = new_right;
		Data = new_data;

	}

	//Copy constructor from existing object
	explicit AVLNode(AVLNode* new_data) {

		this->set_height(new_data->get_height());
		this->set_left(new_data->get_left());
		this->set_right(new_data->get_right());
		this->set_data(new_data->get_data());

	}

	//Destructor
	~AVLNode() {

		//if (this != 0xDDDDDDDD) {
		//delete left;
		//delete right;
		//}
		left = nullptr;
		right = nullptr;
		height = 0;

	}

	//AVLNode Copy Assignment
	AVLNode& operator=(AVLNode& source) {

		this->height = source.height;
		this->left = source.left;
		this->right = source.right;
		this->Data = source.Data;

		return *this;

	}


	//Setters and getters
	void set_data(DATATYPE new_data) {
		if (this != NULL) {
			Data = new_data;
		}
	}
	void set_left(AVLNode<DATATYPE>* new_left) {
		left = new_left;
	}
	void set_right(AVLNode<DATATYPE>* new_right) {
		right = new_right;
	}
	void set_height(int new_height) {
		height = new_height;	
	}
	Object get_data() {
		return Data;
	}
	AVLNode<DATATYPE>* get_left() {
		return left;
	}
	AVLNode<DATATYPE>* get_right() {
		return right;
	}
	int get_height() {
		return height;
	}



};