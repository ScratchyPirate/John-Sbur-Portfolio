﻿// <copyright file="SpreadsheetCell.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Intermediate class used to instantiate used of Cell class for speadsheet.
    /// </summary>
    public class SpreadsheetCell : Cell
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SpreadsheetCell"/> class.
        /// </summary>
        /// <param name="newRowIndex">
        ///  Assigned rowIndex from constructor.
        /// </param>
        /// <param name="newColumnIndex">
        ///  Assigned columnIndex from constructor.
        /// </param>
        /// <param name="newText">
        ///  Used to initialize text as newText.
        /// </param>
        public SpreadsheetCell(int newRowIndex, int newColumnIndex, string? newText)
        {
            this.rowIndex = newRowIndex;
            this.columnIndex = newColumnIndex;

            // If newtext is null, assign the text and value to the empty string. Ensures string isn't empty.
            if (newText == null)
            {
                this.text = string.Empty;
                this.value = string.Empty;
            }
            else
            {
                this.text = newText;
                this.value = newText;
            }
        }
    }
}
