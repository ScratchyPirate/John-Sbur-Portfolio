﻿// <copyright file="ExpressionTreeNumberNode.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Node designed to hold numerical values.
    /// </summary>
    public class ExpressionTreeNumberNode : ExpressionTreeNode
    {
        // Represents the value of the node as a double.
        private double value;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTreeNumberNode"/> class.
        /// </summary>
        /// <param name="variableName">
        ///  The name of the variable being created.
        /// </param>
        public ExpressionTreeNumberNode(string variableName)
        {
            this.IsParenthesisToken = false;

            // Set children nodes to null
            this.Left = null;
            this.Right = null;

            // Subcribe to the RestrictChildrenNodes function to make sure the children are always null.
            this.LeftChanged += this.RestrictChildrenNodes;
            this.RightChanged += this.RestrictChildrenNodes;

            // Subscribe to the RestrictVariableName function
            this.NameChanged += this.RestrictVariableName;

            // Assign name to variableName. Throws if name is invalid.
            this.Name = variableName;
        }

        /// <summary>
        ///  Gets value in this node.
        /// </summary>
        public double Value
        {
            get { return this.value; }
        }

        /// <summary>
        ///  This function is subscribed to the left and right node changed events. If they are changed, it sets them to null as an
        ///  insurance policy. Variable nodes shouldn't have children.
        /// </summary>
        /// <param name="sender">
        ///  Object that sent this. It's this node.
        /// </param>
        /// <param name="e">
        ///  Arguments passed into the invoked event.
        /// </param>
        public void RestrictChildrenNodes(object? sender, EventArgs e)
        {
            this.Left = null;
            this.Right = null;
        }

        /// <summary>
        ///  Used as a check when variable name is assigned. If the name assigned is an integer, double, or 0, throw an exception.
        /// </summary>
        /// <param name="sender">
        ///  Object that sent the event. Usually this.
        /// </param>
        /// <param name="e">
        ///  Arguments passed into event.
        /// </param>
        /// <exception cref="Exception">
        ///  Exception thrown when name assignment is invalid.
        /// </exception>
        public void RestrictVariableName(object? sender, EventArgs e)
        {
            if (this.Name == "0" || this.Name == "0.0")
            {
                // Try to extract an integer and double from the string.
                double holder1;
                int holder2;

                // If we can convert the name into a double or integer, assign value to that. Otherwise, throw.
                if (double.TryParse(this.Name, out holder1) == true)
                {
                    this.value = holder1;
                }
                else if (int.TryParse(this.Name, out holder2) == true)
                {
                    this.value = holder2;
                }
                else
                {
                    throw new Exception("Invalid assignment if non-variable name to this.Name");
                }
            }
            else
            {
                this.value = 0;
            }
        }
    }
}
