﻿// <copyright file="Cell.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    /// <summary>
    ///  Generic cell with row and column.
    /// </summary>
    public abstract class Cell : INotifyPropertyChanged
    {
        /// <summary>
        /// Used for keeping track of the number of changed invoked.
        /// </summary>
        // Needs to be public for use in program.
#pragma warning disable SA1401 // Fields should be private
        public static int ChangesInvoked = 0;
#pragma warning restore SA1401 // Fields should be private

        // According to homework, variables should promote encapsulation so they should be protected instead of private.
        // Warning is suppressed because of this.
        // Page 4 of 9 "So make sure that the member variable is marked as protected. "
#pragma warning disable SA1401 // Fields should be private
        /// <summary>
        ///  Row index of cell.
        /// </summary>
        protected int rowIndex;

        /// <summary>
        ///  Column index of cell.
        /// </summary>
        protected int columnIndex;

        /// <summary>
        ///  Value is either Text or a formula evaluation.
        /// </summary>
        protected string? value;

        /// <summary>
        ///  Text associated with cell.
        /// </summary>
        protected string? text;

        /// <summary>
        ///  Color assiciated with cell.
        /// </summary>
        protected int bGCOLOR = -1;
#pragma warning restore SA1401 // Fields should be private

        /// <summary>
        ///  Used between all cells to determine a chain of references. If there is a cell that references a cell that references a cell, the lock will be set to 1 while the first reference resolves and then 0 afterwards within the
        ///  UpdateCellInformation event. Used for handling multiple references.
        /// </summary>
        private static int referenceLock = 0;

        /// <summary>
        /// Used for determining when something is changes in cell.
        /// </summary>
        public event PropertyChangedEventHandler? PropertyChanged = (sender, e) => { };

        /// <summary>
        ///  Gets function for rowIndex. rowIndex is read only.
        /// </summary>
        public int RowIndex
        {
            get { return this.rowIndex; }
        }

        /// <summary>
        ///  Gets function for columnIndex. columnIndex is read only.
        /// </summary>
        public int ColumnIndex
        {
            get { return this.columnIndex; }
        }

        /// <summary>
        ///  Gets or Sets text for this cell without invoking the propertychanged event.
        /// </summary>
        public string? SafeText
        {
            get { return this.text; }
            set { this.text = value; }
        }

        /// <summary>
        ///  Gets or Sets function for text protected member.
        /// </summary>
        public string? Text
        {
            get
            {
                return this.text;
            }

            set
            {
                // If the value is the same, ignore.
                if (value == this.text)
                {
                    return;
                }
                else
                {
                    if (value == null)
                    {
                        this.text = string.Empty;
                        this.value = string.Empty;
                    }
                    else
                    {
                        this.text = value;
                        this.value = value;
                    }

                    this.NotifyPropertyChanged(this.RowIndex.ToString() + "," + this.ColumnIndex.ToString());
               }
            }
        }

        /// <summary>
        ///  Gets or sets function for value.
        /// </summary>
        public string? Value
        {
            get
            {
                return this.value;
            }

            set
            {
                if (value == null)
                {
                    this.value = string.Empty;
                }
                else
                {
                    this.value = value;
                }
            }
        }

        /// <summary>
        ///  Gets or Sets bGCOLOR.
        /// </summary>
        public int BGCOLOR
        {
            get
            {
                return this.bGCOLOR;
            }

            set
            {
                // If the value is the same, ignore.
                if (value == this.bGCOLOR)
                {
                    return;
                }
                else
                {
                    this.bGCOLOR = value;
                    this.NotifyPropertyChanged(this.RowIndex.ToString() + "," + this.ColumnIndex.ToString());
                }
            }
        }

        /// <summary>
        /// Sends a propertychanged argument when text is changed.
        /// </summary>
        /// <param name="propertyName">
        /// Name of property changed that triggered the event.
        /// </param>
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Sets the text equal to itself and triggers a property changed event.
        /// </summary>
        /// <param name="sender">
        /// Object that sent the event.
        /// </param>
        /// <param name="e">
        /// Event arguents.
        /// </param>
        public void UpdateCellInformation(object? sender, EventArgs e)
        {
            if (referenceLock == 0)
            {
                referenceLock++;
                this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));
                ChangesInvoked++;
                referenceLock--;
                this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));
            }
        }
    }
}