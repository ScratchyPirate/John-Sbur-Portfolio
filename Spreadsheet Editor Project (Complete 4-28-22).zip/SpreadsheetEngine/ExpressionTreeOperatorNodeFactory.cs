﻿// <copyright file="ExpressionTreeOperatorNodeFactory.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Factory responsible for creating different types of operator nodes.
    /// </summary>
    internal class ExpressionTreeOperatorNodeFactory
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTreeOperatorNodeFactory"/> class.
        /// </summary>
        public ExpressionTreeOperatorNodeFactory()
        {
        }

        /// <summary>
        ///  Creates different ExpressionTreeOperatorNodes depending on the inputted string.
        /// </summary>
        /// <param name="newString">
        ///  String input of the new operator node.
        /// </param>
        /// <returns>
        ///  Null if the creation fails or the new operator node.
        /// </returns>
        public ExpressionTreeOperatorNode? CreateOperatorNode(string newString)
        {
            switch (newString)
            {
                // If the name is the name of an operator, make the new node an ExpressionTreeOperatorNode.
                case "+":
                    return new ExpressionTreeOperatorNode(0);
                case "-":
                    return new ExpressionTreeOperatorNode(1);
                case "*":
                    return new ExpressionTreeOperatorNode(2);
                case "/":
                    return new ExpressionTreeOperatorNode(3);
                default:
                    return null;
            }
        }
    }
}
