﻿// <copyright file="ExpressionTreeOperatorNode.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Node specifically used for storing operators. Inherits from base ExpressionTreeNode.
    /// </summary>
    public class ExpressionTreeOperatorNode : ExpressionTreeNode
    {
        // Represents the type of operator this node corresponds to.
        //  -0 = "+"
        //  -1 = "-"
        //  -2 = "*"
        //  -3 = "/"
        private int operatorType;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTreeOperatorNode"/> class.
        /// </summary>
        /// <param name="operate">
        ///  Gives the node a name depending on the inputted integer.
        ///  -0 = "+"
        ///  -1 = "-"
        ///  -2 = "*"
        ///  -3 = "/"
        ///  -default = "+".
        /// </param>
        public ExpressionTreeOperatorNode(int operate = 0)
        {
            this.IsParenthesisToken = false;

            // Sets the operand or this node.
            switch (operate)
            {
                case 0:
                    this.Name = "+";
                    this.operatorType = 0;
                    break;
                case 1:
                    this.Name = "-";
                    this.operatorType = 1;
                    break;
                case 2:
                    this.Name = "*";
                    this.operatorType = 2;
                    break;
                case 3:
                    this.Name = "/";
                    this.operatorType = 3;
                    break;
                default:
                    this.Name = "+";
                    this.operatorType = 0;
                    break;
            }

            this.NameChanged += this.ValidateNameChange;

            // Set children to null.
            this.Right = null;
            this.Left = null;
        }

        /// <summary>
        ///  Gets operator type. Set intentionally not allowed for user. Should only be set when name changed.
        /// </summary>
        public int OperatorType
        {
            get { return this.operatorType; }
        }

        /// <summary>
        ///  When the name is changed, this function checks to see if the name is now an operator. If it's not, change it back to the old name.
        /// </summary>
        /// <param name="sender">
        ///  Object that send the event change.
        /// </param>
        /// <param name="e">
        ///  Arguments passed into the event.
        /// </param>
        public void ValidateNameChange(object? sender, EventArgs e)
        {
            if (sender != null)
            {
                if (sender.GetType() == typeof(ExpressionTreeOperatorNode))
                {
                    ExpressionTreeOperatorNode senderNode = (ExpressionTreeOperatorNode)sender;

                    // Updates the operatorType to match the new operator.
                    switch (senderNode.Name)
                    {
                        case "+":
                            this.operatorType = 0;
                            break;
                        case "-":
                            this.operatorType = 1;
                            break;
                        case "*":
                            this.operatorType = 2;
                            break;
                        case "/":
                            this.operatorType = 3;
                            break;

                        // If the assigned operator isn't a valid name for an operator, change it back to the old one.
                        default:
                            switch (this.operatorType)
                            {
                                case 0:
                                    this.Name = "+";
                                    break;
                                case 1:
                                    this.Name = "-";
                                    break;
                                case 2:
                                    this.Name = "*";
                                    break;
                                case 3:
                                    this.Name = "/";
                                    break;
                                default:
                                    this.Name = "+";
                                    this.operatorType = 0;
                                    break;
                            }

                            break;
                    }
                }
            }
        }
    }
}
