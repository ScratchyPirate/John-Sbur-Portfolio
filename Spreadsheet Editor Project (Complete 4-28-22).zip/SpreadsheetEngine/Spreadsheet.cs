﻿// <copyright file="Spreadsheet.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Test_Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Spreadsheet_John_Sbur")]
[assembly: InternalsVisibleTo("Expression_Tree_Demo_Project")]

namespace Cpts321
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Runtime.Serialization.Formatters.Binary;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///  Spreadsheet class for homework 4. Stores spreadsheet information in a 2D array of Cell classes.
    /// </summary>
    public class Spreadsheet
    {
        /// <summary>
        ///  2D array container for all cells in our spreadsheet.
        /// </summary>
        private SpreadsheetCell[,] cellArray;

        /// <summary>
        /// Initializes a new instance of the <see cref="Spreadsheet"/> class with numberOfRows x numberOfColumns as the dimensions.
        /// </summary>
        /// <param name="numberOfRows">
        ///  How big in the y direction the array is.
        /// </param>
        /// <param name="numberOfColumns">
        ///  How big in the x direction the array is.
        /// </param>
        public Spreadsheet(int numberOfRows, int numberOfColumns)
        {
            // set number of Rows to 1 if inputted rows < 1;
            if (numberOfRows < 1)
            {
                numberOfRows = 1;
            }

            // set number of Columns to 1 if inputted columns < 1;
            if (numberOfColumns < 1)
            {
                numberOfColumns = 1;
            }

            this.cellArray = new SpreadsheetCell[numberOfRows, numberOfColumns];

            SpreadsheetCell[,] arrayHolder = this.CellArray;
            SpreadsheetCell newCell;

            // Populate array with new cells.
            for (int i = 0; i < numberOfRows; i++)
            {
                for (int j = 0; j < numberOfColumns; j++)
                {
                    newCell = new SpreadsheetCell(i, j, string.Empty);
                    arrayHolder[i, j] = newCell;
                }
            }

            // Subscribe to all cells
            this.SubscribeToAllCellChangeEvents();

            // Assign cellArray the new edited array.
            this.CellArray = arrayHolder;
        }

        /// <summary>
        ///  Helper event that invokes upon the CellPropertyChanged event evoking.
        /// </summary>
        public event PropertyChangedEventHandler? CellPropertyChangedEventHandler = (sender, e) => { };

        /// <summary>
        ///  Helper event that invokes when the CellProprtyChanged event sees a new color.
        /// </summary>
        public event PropertyChangedEventHandler? CellColorChangedHandler = (sender, e) => { };

        /// <summary>
        ///  Gets or Sets cell array. Used for accessing, modifying, and assigning cellArray.
        /// </summary>
        public SpreadsheetCell[,] CellArray
        {
            get { return this.cellArray; }
            set { this.cellArray = value; }
        }

        /// <summary>
        ///  Gets or Sets rowcount of array. Resizes on Sets.
        /// </summary>
        public int RowCount
        {
            get
            {
                return this.cellArray.GetLength(0);
            }

            set
            {
                this.Resize(value, this.cellArray.GetLength(1));
            }
        }

        /// <summary>
        ///   Gets or Sets columncount of array. Resizes on Sets.
        /// </summary>
        public int ColumnCount
        {
            get
            {
                return this.cellArray.GetLength(1);
            }

            set
            {
                this.Resize(this.cellArray.GetLength(0), value);
            }
        }

        /// <summary>
        ///  Returns requested cell at row and column. Returns null if out of bounds.
        /// </summary>
        /// <param name="rowIndex">
        ///  Row of target cell.
        /// </param>
        /// <param name="columnIndex">
        ///  Column of target cell.
        /// </param>
        /// <returns>
        ///  Returns abstract cell type of cell found.
        /// </returns>
        public Cell? GetCell(int rowIndex, int columnIndex)
        {
            if ((rowIndex >= 0 && rowIndex < this.cellArray.GetLength(0)) && (columnIndex >= 0 && columnIndex < this.cellArray.GetLength(1)))
            {
                return this.cellArray[rowIndex, columnIndex];
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        ///  Resizes the array according to inputed elements. Fails if resizing elements are smaller than current elements.
        /// </summary>
        /// <param name="newRowMax">
        ///  New row bound to be assigned.
        /// </param>
        /// <param name="newColumnMax">
        ///  New column bound to be assigned.
        /// </param>
        /// <returns>
        ///  1 if successful. 0 if fails.
        /// </returns>
        public int Resize(int newRowMax, int newColumnMax)
        {
            // If the new bounds are less than or equal to the current bounds, fail and return 0;
            if (newRowMax <= this.cellArray.GetLength(0) || newColumnMax <= this.cellArray.GetLength(1))
            {
                return 0;
            }

            // Store array, resize array, assign old cells in old array to new cells in new array, return 1.
            SpreadsheetCell[,] arrayHolder = this.CellArray;
            SpreadsheetCell[,] newArray = new SpreadsheetCell[newRowMax, newColumnMax];

            int oldRowBounds = this.cellArray.GetLength(0);
            int oldColumnBounds = this.cellArray.GetLength(1);
            SpreadsheetCell insertCell = new SpreadsheetCell(0, 0, string.Empty);

            for (int i = 0; i < newRowMax; i++)
            {
                for (int j = 0; j < newColumnMax; j++)
                {
                    // If this index exists in the old array, set the new cell to the old cell at this index.
                    if (i < oldRowBounds && j < oldColumnBounds)
                    {
                        insertCell = new SpreadsheetCell(i, j, arrayHolder[i, j].Text);
                    }
                    else
                    {
                        insertCell = new SpreadsheetCell(i, j, string.Empty);
                    }

                    newArray[i, j] = insertCell;
                }
            }

            // Assign resized array to new array.
            this.CellArray = newArray;

            // Resubscribe to all cells
            this.SubscribeToAllCellChangeEvents();

            return 1;
        }

        /// <summary>
        ///  Sets the text information of the cell if the cell exists in the array.
        /// </summary>
        /// <param name="targetRow">
        ///  row of cell to be modified.
        /// </param>
        /// <param name="targetColumn">
        ///  column of cell to be modified.
        /// </param>
        /// <param name="replacementText">
        ///  text to replace old text in modified cell.
        /// </param>
        public void SetCellText(int targetRow, int targetColumn, string replacementText)
        {
            SpreadsheetCell[,] arrayHolder = this.CellArray;

            // If the requested cell is within bounds, set the text of that cell. Otherwise, return.
            if ((targetRow < arrayHolder.GetLength(0) && targetRow >= 0) && (targetColumn < arrayHolder.GetLength(1) && targetColumn >= 0))
            {
                arrayHolder[targetRow, targetColumn].Text = replacementText;
                this.cellArray = arrayHolder;

                // Resubscribe to all cells
                this.SubscribeToAllCellChangeEvents();

                return;
            }
            else
            {
                return;
            }
        }

        /// <summary>
        ///  Sets the text information of the cell if the cell exists in the array without invoking a propertychanged event.
        /// </summary>
        /// <param name="targetRow">
        ///  row of cell to be modified.
        /// </param>
        /// <param name="targetColumn">
        ///  column of cell to be modified.
        /// </param>
        /// <param name="replacementText">
        ///  text to replace old text in modified cell.
        /// </param>
        public void SafeSetCellText(int targetRow, int targetColumn, string replacementText)
        {
            SpreadsheetCell[,] arrayHolder = this.CellArray;

            // If the requested cell is within bounds, set the text of that cell. Otherwise, return.
            if ((targetRow < arrayHolder.GetLength(0) && targetRow >= 0) && (targetColumn < arrayHolder.GetLength(1) && targetColumn >= 0))
            {
                arrayHolder[targetRow, targetColumn].SafeText = replacementText;
                this.cellArray = arrayHolder;

                // Resubscribe to all cells
                this.SubscribeToAllCellChangeEvents();

                return;
            }
            else
            {
                return;
            }
        }

        /// <summary>
        ///  Sets the value information of the cell if the cell exists in the array.
        /// </summary>
        /// <param name="targetRow">
        ///  row of cell to be modified.
        /// </param>
        /// <param name="targetColumn">
        ///  column of cell to be modified.
        /// </param>
        /// <param name="replacementValue">
        ///  text to replace old value in modified cell.
        /// </param>
        public void SetCellValue(int targetRow, int targetColumn, string replacementValue)
        {
            SpreadsheetCell[,] arrayHolder = this.CellArray;

            // If the requested cell is within bounds, set the text of that cell. Otherwise, return.
            if ((targetRow < arrayHolder.GetLength(0) && targetRow >= 0) && (targetColumn < arrayHolder.GetLength(1) && targetColumn >= 0))
            {
                arrayHolder[targetRow, targetColumn].Value = replacementValue;
                this.cellArray = arrayHolder;

                // Resubscribe to all cells
                this.SubscribeToAllCellChangeEvents();

                return;
            }
            else
            {
                return;
            }
        }

        /// <summary>
        ///  Sets the color of all cells in the array to be the inputted color.
        /// </summary>
        /// <param name="newColor">
        ///  New color of all cells.
        /// </param>
        public void SetAllColors(int newColor)
        {
            // For each row
            for (int i = 0; i < this.CellArray.GetLength(0); i++)
            {
                // For each column
                for (int j = 0; j < this.CellArray.GetLength(1); j++)
                {
                    // Set color
                    this.CellArray[i, j].BGCOLOR = newColor;
                }
            }
        }

        /// <summary>
        ///  Sets the color of the target cell if it's within the cell array.
        /// </summary>
        /// <param name="targetRow">
        ///  Row of cell to be editted.
        /// </param>
        /// <param name="targetColumn">
        ///  Column of cell to be edited.
        /// </param>
        /// <param name="newColor">
        ///  New color of target cell.
        /// </param>
        public void SetCellColor(int targetRow, int targetColumn, int newColor)
        {
            // If the requested cell is within bounds, set the text of that cell. Otherwise, return.
            if ((targetRow < this.CellArray.GetLength(0) && targetRow >= 0) && (targetColumn < this.CellArray.GetLength(1) && targetColumn >= 0))
            {
                // Set color
                this.CellArray[targetRow, targetColumn].BGCOLOR = newColor;
                return;
            }
            else
            {
                return;
            }
        }

        /// <summary>
        ///  Prints the array to the designated outputWriter.
        /// </summary>
        /// <param name="outputWriter">
        ///  TextWriter designated as output.
        /// </param>
        /// <returns>
        ///  1 upon completion.
        /// </returns>
        public int PrintCellArray(TextWriter outputWriter)
        {
            SpreadsheetCell[,] arrayHolder = this.CellArray;

            for (int i = 0; i < arrayHolder.GetLength(0); i++)
            {
                // Print formatted contents of each cell in a row. Format: <[rowIndex, columnIndex]cellText>\t
                for (int j = 0; j < arrayHolder.GetLength(1); j++)
                {
                    outputWriter.Write("<[" + i.ToString() + "," + j.ToString() + "]" + arrayHolder[i, j].Text + ">\t");
                }

                // Make a new line at the end of each row.
                outputWriter.Write(Environment.NewLine);
            }

            return 1;
        }

        /// <summary>
        ///  Returns a deep clone of this spreadsheet.
        /// </summary>
        /// <returns>
        ///  Copy of this spreadsheet.
        /// </returns>
        [Obsolete]
        public Spreadsheet Clone()
        {
            // Create a new empty spreadsheet
            Spreadsheet newSpreadsheet = new Spreadsheet(this.RowCount, this.ColumnCount);

            // Deep copy over data
            for (int i = 0; i < newSpreadsheet.RowCount; i++)
            {
                for (int j = 0; j < newSpreadsheet.ColumnCount; j++)
                {
                    // Measures were taken in constructors and Properties to make sure that the string couldn't be null.
#pragma warning disable CS8604 // Possible null reference argument.
                    newSpreadsheet.CellArray[i, j].Text = string.Copy(this.CellArray[i, j].Text);
                    newSpreadsheet.CellArray[i, j].Value = string.Copy(this.CellArray[i, j].Value);
#pragma warning restore CS8604 // Possible null reference argument.
                    newSpreadsheet.CellArray[i, j].BGCOLOR = this.CellArray[i, j].BGCOLOR;
                }
            }

            // Subscribe to all property changed events in this grid's new cells.
            newSpreadsheet.SubscribeToAllCellChangeEvents();
            Cell.ChangesInvoked = 0;

            return newSpreadsheet;
        }

        /// <summary>
        ///  Saves the current spreadsheet and to the StreamWriter in XML format. Only writes non-default cells.
        /// </summary>
        /// <param name="fileStream">
        ///  Target storage stream.
        /// </param>
        public void Save(StreamWriter fileStream)
        {
            // Write first member as a sentinel string. When loading from a stream, if the first string in this format is found, then we can pull from it.
             fileStream.Write("<SPREADSHEET FORMATTED .CSV></SPREADSHEET FORMATTED .CSV>" + Environment.NewLine);

            // Begin writing data from spreadsheet to stream in XML format
            // Spreadsheet token
             fileStream.Write("<Spreadsheet>" + Environment.NewLine);

            // Write number of rows and number of columns in spreadsheet
             fileStream.Write("<RowsCount>" + this.RowCount.ToString() + "</RowsCount>" + Environment.NewLine);
             fileStream.Write("<ColumnsCount>" + this.ColumnCount.ToString() + "</ColumnsCount>" + Environment.NewLine);

            // Begin storing cell data
             for (int i = 0; i < this.RowCount; i++)
            {
                for (int j = 0; j < this.ColumnCount; j++)
                {
                    // Check if cell has data to store that isn't the default data. If it does, store it.
                    // Cannot be null as constructor for SpreadsheetCell ensures each member of this array is initialized.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                    if (this.GetCell(i, j).BGCOLOR != -1 || this.GetCell(i, j).Text != string.Empty)
                    {
                        // Store cell information
                        // Cell row and column
                        fileStream.Write("<cell row=" + i.ToString() + " column=" + j.ToString() + ">" + Environment.NewLine);

                        // Color
                        if (this.GetCell(i, j).BGCOLOR != -1)
                        {
                            fileStream.Write("<color>" + this.GetCell(i, j).BGCOLOR.ToString() + "</color>" + Environment.NewLine);
                        }

                        // Text
                        if (this.GetCell(i, j).Text != string.Empty)
                        {
                            fileStream.Write("<text>" + this.GetCell(i, j).Text + "</text>" + Environment.NewLine);
                        }

                        // Value
                        if (this.GetCell(i, j).Value != string.Empty)
                        {
                            fileStream.Write("<value>" + this.GetCell(i, j).Value + "</value>" + Environment.NewLine);
                        }
#pragma warning restore CS8602 // Dereference of a possibly null reference.

                        // Write end of cell marker
                        fileStream.Write("</cell>" + Environment.NewLine);
                    }
                }
            }

            // Enging spreadsheet token
             fileStream.Write("</Spreadsheet>" + Environment.NewLine);

             Cell.ChangesInvoked = 0;
        }

        /// <summary>
        ///  Loads the current spreadsheet from StreamReader in XML format.
        /// </summary>
        /// <param name="fileStream">
        ///  Target reader stream.
        /// </param>
        public void Load(StreamReader fileStream)
        {
            // Locals used
            string? lineHolder = string.Empty;
            char[] lineHolderArray;
            string tokenHolder1 = string.Empty;
            string tokenHolder2 = string.Empty;
            int integerHolder1 = 0;
            int integerHolder2 = 0;
            int currentCellRow = 0;
            int currentCellColumn = 0;
            int i = 0;
            bool endOfSpreadsheet = false;
            Spreadsheet newsSpreadsheet;

            // Verify that this is in the format required for loading by getting the first line and making sure it's "<SPREADSHEET FORMATTED .CSV>".
            lineHolder = fileStream.ReadLine();

            // If nothing was read, throw here and stop.
            if (lineHolder == null)
            {
                throw new Exception("StreamReader was empty");
            }

            // If the first token is not the right format, return here.
            if (lineHolder != "<SPREADSHEET FORMATTED .CSV></SPREADSHEET FORMATTED .CSV>")
            {
                throw new Exception("StreamReader was not in correct Spreadsheet Format");
            }

            // Get Spreadsheet token. Verify token was received
            lineHolder = fileStream.ReadLine();
            if (lineHolder != "<Spreadsheet>")
            {
                throw new Exception("Missing <Spreadsheet> token");
            }

            // Get rows count and columns count
            // ***** Rows Count *****
            lineHolder = fileStream.ReadLine();
            if (lineHolder == null)
            {
                throw new Exception("Rows Count Element missing.");
            }

            lineHolderArray = lineHolder.ToCharArray();

            // Get Rows count from element
            for (i = 0; i < lineHolderArray.Length; i++)
            {
                if (lineHolderArray[i] == '>')
                {
                    i++;

                    for (; i < lineHolder.Length && lineHolderArray[i] != '<'; i++)
                    {
                        tokenHolder1 += lineHolderArray[i].ToString();
                    }
                }
            }

            // If the found token isn't an integer, throw.
            if (int.TryParse(tokenHolder1, out integerHolder1) != true)
            {
                throw new Exception("Rows Count Corrupted");
            }

            // Store row count in integerHolder1.
            integerHolder1 = int.Parse(tokenHolder1);

            // ***** Column Count *****
            lineHolder = fileStream.ReadLine();
            if (lineHolder == null)
            {
                throw new Exception("Rows Count Element missing.");
            }

            lineHolderArray = lineHolder.ToCharArray();

            // Get Column count from element
            for (i = 0; i < lineHolderArray.Length; i++)
            {
                if (lineHolderArray[i] == '>')
                {
                    i++;

                    for (; i < lineHolder.Length && lineHolderArray[i] != '<'; i++)
                    {
                        tokenHolder2 += lineHolderArray[i].ToString();
                    }
                }
            }

            // If the found token isn't an integer, throw.
            if (int.TryParse(tokenHolder2, out integerHolder2) != true)
            {
                throw new Exception("Columns Count Corrupted");
            }

            // Store column count in integerHolder2.
            integerHolder2 = int.Parse(tokenHolder2);

            // ***** Initialize new spreadsheet *****
            newsSpreadsheet = new Spreadsheet(integerHolder1, integerHolder2);

            // ***** Get and Store cell data *****
            while (fileStream.EndOfStream != true && !endOfSpreadsheet)
            {
                // Clear locals each loop before proceeding
                integerHolder1 = 0;
                integerHolder2 = 0;
                tokenHolder1 = string.Empty;
                tokenHolder2 = string.Empty;
                lineHolder = string.Empty;
                lineHolderArray = new char[1];

                // Get first line, proceed depending on what the line is.
                lineHolder = fileStream.ReadLine();

                // If not null
                if (lineHolder != null)
                {
                    // If not empty
                    if (lineHolder != string.Empty)
                    {
                        // If the token is the start of a cell, get the row and column number
                        if (lineHolder.Contains("<cell row="))
                        {
                            lineHolderArray = lineHolder.ToCharArray();

                            // Go to first equal sign, should be row.
                            for (i = 0; lineHolderArray[i] != '='; i++)
                            {
                            }

                            i++;

                            // Get row number into string.
                            for (; lineHolderArray[i] != ' '; i++)
                            {
                                tokenHolder1 += lineHolderArray[i].ToString();
                            }

                            // Turn string into int throw if fail
                            if (int.TryParse(tokenHolder1, out integerHolder1) != true)
                            {
                                throw new Exception("Error reading cell row");
                            }

                            currentCellRow = int.Parse(tokenHolder1);

                            // Go to second equal sign, should be column.
                            for (; lineHolderArray[i] != '='; i++)
                            {
                            }

                            i++;

                            // Get row number into string.
                            for (; lineHolderArray[i] != '>'; i++)
                            {
                                tokenHolder2 += lineHolderArray[i].ToString();
                            }

                            // Turn string into int throw if fail
                            if (int.TryParse(tokenHolder2, out integerHolder2) != true)
                            {
                                throw new Exception("Error reading cell column");
                            }

                            currentCellColumn = int.Parse(tokenHolder2);

                            // After this, we are good to go to the next line as we have the cell we need for editing data.
                        }

                        // If the token is an element, assign it to the current cell.
                        // Text
                        else if (lineHolder.Contains("<text>") && lineHolder.Contains("</text>"))
                        {
                            lineHolderArray = lineHolder.ToCharArray();

                            // Go to first '>'
                            for (i = 0; lineHolderArray[i] != '>'; i++)
                            {
                            }

                            i++;

                            // Get contents inbetween <text> and </text> tags into tokenHolder1.
                            for (; lineHolderArray[i] != '<'; i++)
                            {
                                tokenHolder1 += lineHolderArray[i].ToString();
                            }

                            // Assign text
                            newsSpreadsheet.CellArray[currentCellRow, currentCellColumn].Text = tokenHolder1;
                        }

                        // Value
                        else if (lineHolder.Contains("<value>") && lineHolder.Contains("</value>"))
                        {
                            lineHolderArray = lineHolder.ToCharArray();

                            // Go to first '>'
                            for (i = 0; lineHolderArray[i] != '>'; i++)
                            {
                            }

                            i++;

                            // Get contents inbetween <value> and </value> tags into tokenHolder1.
                            for (; lineHolderArray[i] != '<'; i++)
                            {
                                tokenHolder1 += lineHolderArray[i].ToString();
                            }

                            // Assign value
                            newsSpreadsheet.CellArray[currentCellRow, currentCellColumn].Value = tokenHolder1;
                        }

                        // Color
                        else if (lineHolder.Contains("<color>") && lineHolder.Contains("</color>"))
                        {
                            lineHolderArray = lineHolder.ToCharArray();

                            // Go to first '>'
                            for (i = 0; lineHolderArray[i] != '>'; i++)
                            {
                            }

                            i++;

                            // Get contents inbetween <value> and </value> tags into tokenHolder1.
                            for (; lineHolderArray[i] != '<'; i++)
                            {
                                tokenHolder1 += lineHolderArray[i].ToString();
                            }

                            // Assign color if it can be converted into an integer
                            if (int.TryParse(tokenHolder1, out integerHolder1))
                            {
                                integerHolder1 = int.Parse(tokenHolder1);
                                newsSpreadsheet.CellArray[currentCellRow, currentCellColumn].BGCOLOR = integerHolder1;
                            }
                        }

                        // If end of cell, reset cell related variables
                        else if (lineHolder.Contains("</cell>"))
                        {
                            currentCellRow = 0;
                            currentCellColumn = 0;
                        }

                        // If end of spreadsheet, stop here
                        else if (lineHolder.Contains("</Spreadsheet>"))
                        {
                            endOfSpreadsheet = true;
                        }
                    }
                }
            }

            // If the file was entirely loaded (endOfSpreadsheet == true), proceed.
            if (endOfSpreadsheet != true)
            {
                return;
            }

            // ***** Clear current spreadsheet *****
            this.Clear();

            // ***** Copy over loaded spreadsheet to this spreadsheet *****
            // Copy array
            this.CellArray = newsSpreadsheet.CellArray;

            // Resubscribe to all events
            this.SubscribeToAllCellChangeEvents();

            // Load function ends here.
            Cell.ChangesInvoked = 0;
        }

        /// <summary>
        ///  Clears all members of the cell array and resets all events and cell properties.
        /// </summary>
        public void Clear()
        {
            // This portion basically runs a portion of the constructor that sets up each member, though each member this time is blank.
            int numberOfRows = this.RowCount;
            int numberOfColumns = this.ColumnCount;
            this.cellArray = new SpreadsheetCell[numberOfRows, numberOfColumns];

            SpreadsheetCell[,] arrayHolder = this.CellArray;
            SpreadsheetCell newCell;

            // Populate array with new cells.
            for (int i = 0; i < numberOfRows; i++)
            {
                for (int j = 0; j < numberOfColumns; j++)
                {
                    newCell = new SpreadsheetCell(i, j, string.Empty);
                    arrayHolder[i, j] = newCell;
                }
            }

            // Subscribe to all cells
            this.SubscribeToAllCellChangeEvents();

            // Assign cellArray the new edited array.
            this.CellArray = arrayHolder;
            Cell.ChangesInvoked = 0;
        }

        /// <summary>
        ///  Subscriber event for each cell. Activates when cell is changed.
        /// </summary>
        /// <param name="sender">
        ///  Object that sent the event.
        /// </param>
        /// <param name="e">
        ///  Formatted "Cell.RowIndex,Cell.columnIndex".
        /// </param>
        public void CellPropertyChanged(object? sender, EventArgs e)
        {
            // If the sender is null, return.
            if (sender == null)
            {
                return;
            }

            // if sender is of type SpreadsheetCell, convert Value. Otherwise, return.
            if (sender.GetType() == typeof(SpreadsheetCell) && (sender != null))
            {
                // Explicit conversion so we can access methods from SpreadsheetCell.
                SpreadsheetCell senderCell = (SpreadsheetCell)sender;

                int rowValue = senderCell.RowIndex;
                int columnValue = senderCell.ColumnIndex;

                SpreadsheetCell targetCell = this.cellArray[rowValue, columnValue];

                // Update Cell Color
                this.CellColorChangedHandler?.Invoke(sender, new PropertyChangedEventArgs("CellColorChangedEvent"));

                // If we have invoked an unreasonable amount of cell changes, we are in an infinite loop and need to throw and error
                if (Cell.ChangesInvoked >= 2000)
                {
                    Cell.ChangesInvoked = 0;
                    throw new Exception("Infinite loop");
                }

                // Update Cell Text/Value Case
                if (targetCell.Text != null)
                {
                    string textHolder = targetCell.Text;
                    char[] charTextHolder = textHolder.ToCharArray();

                    // If the string wasn't loaded in or was empty, return;
                    if (charTextHolder.Length == 0)
                    {
                        return;
                    }

                    // If the first member of charTextHolder is =, evaluate. Otherwise, return.
                    if (charTextHolder[0] == '=')
                    {
                       // Expression tree part. Try to turn the part after '=' into an expression while entering variables as needed for the variable dictionary.
                        var expressionCharStorage = from c in charTextHolder
                               where c != '=' && c != ' '
                                select c;
                        string expression = new string(string.Empty);

                        // Store each non '=' char from the text into the expression string.
                        foreach (char c in expressionCharStorage)
                        {
                            expression += c.ToString();
                        }

                        // Attempt to create an expression tree. If it fails, exit out of the function and leave the text as is.
                        ExpressionTree expressionTree;
                        try
                        {
                            expressionTree = new ExpressionTree(expression);
                        }
                        catch
                        {
                            Console.WriteLine("Expression compile failed.");
                            return;
                        }

                        // Get all variables stored in an array.
                        // Fixing the spacing leads to another warning which asks to revert the spacing back. Resolution not possible.
#pragma warning disable SA1011 // Closing square brackets should be spaced correctly
                        string[]? expressionVariables = expressionTree.ListAllVariables();
#pragma warning restore SA1011 // Closing square brackets should be spaced correctly

                        // For each variable in the array, attempt to set the variable to the grid element corresponding to it. Runs only if variables are present.
                        if (expressionVariables != null)
                        {
                            foreach (string variable in expressionVariables)
                            {
                                // Store variable in a char array.
                                char[] variableArray = variable.ToCharArray();

                                // Used if the text is a value of another cell.
                                int sourceCellColumn = (int)(variableArray[0] - 65);

                                // If the first char is a letter, continue evaluation.
                                // text of that cell.
                                if (sourceCellColumn >= 0 && sourceCellColumn <= 26)
                                {
                                    char[] digits = { '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' };
                                    int numberOfDigits = 0;
                                    int sourceCellRow = 0;

                                    for (int i = 1, j = 0; i != variableArray.Length && i < 10; i++, j++)
                                    {
                                        digits[j] = variableArray[i];
                                        numberOfDigits++;
                                    }

                                    // Store target number in sourceCellColumn.
                                    for (int i = 0; numberOfDigits > 0 && i < 10; numberOfDigits--, i++)
                                    {
                                        // If the digit isn't a number, throw and error
                                        if (((int)digits[i] - 48) < 0 || ((int)digits[i] - 48) > 9)
                                        {
                                            throw new Exception("Variable found wasn't a cell");
                                        }

                                        sourceCellRow += ((int)digits[i] - 48) * Convert.ToInt32(Math.Pow(10, numberOfDigits - 1));
                                    }

                                    sourceCellRow--;

                                    // Get cell at that location and it's text. If successful and it's a double, set the variable to be that double.
                                    SpreadsheetCell? sourceCell = (SpreadsheetCell?)this.GetCell(sourceCellRow, sourceCellColumn);
                                    if (sourceCell != null)
                                    {
                                        if (sourceCell.Value != null)
                                        {
                                            // Throws when circular reference occurs.
                                            if (sourceCellColumn == columnValue && sourceCellRow == rowValue)
                                            {
                                                throw new Exception("Variable expression contains circular reference");
                                            }

                                            double valueHolder = 0.0;
                                            if (double.TryParse(sourceCell.Value, out valueHolder))
                                            {
                                                // Change the property of the cell.
                                                expressionTree.SetVariable(variable, Convert.ToDouble(sourceCell.Value));

                                                // Add a delegate function that updates the text of this cell (targetCell) that references this variable cell (sourceCell)
                                                // Fires whenever a property is changed in variableCell.
                                                sourceCell.PropertyChanged -= targetCell.UpdateCellInformation;
                                                sourceCell.PropertyChanged += targetCell.UpdateCellInformation;

                                                this.CellArray[sourceCellRow, sourceCellColumn] = sourceCell;
                                                this.CellArray[rowValue, columnValue] = targetCell;
                                            }
                                            else
                                            {
                                                // Change the property of the cell.
                                                expressionTree.SetVariable(variable, 0);

                                                // Add a delegate function that updates the text of this cell (targetCell) that references this variable cell (sourceCell)
                                                // Fires whenever a property is changed in variableCell.
                                                sourceCell.PropertyChanged -= targetCell.UpdateCellInformation;
                                                sourceCell.PropertyChanged += targetCell.UpdateCellInformation;

                                                this.CellArray[sourceCellRow, sourceCellColumn] = sourceCell;
                                                this.CellArray[rowValue, columnValue] = targetCell;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        // If a variable is found that is not a cell, return here and do not edit the value. Expression is invalid.
                                        throw new Exception("Variable found wasn't a cell");
                                    }
                                }
                                else
                                {
                                    // If a variable is found that is not a cell, return here and do not edit the value. Expression is invalid.
                                    throw new Exception("Variable found wasn't a cell");
                                }
                            }
                        }

                        // Attempt to evaluate the expression tree. If it fails, exit out of the function and leave the text as it.
                        double result = 0.0;
                        try
                        {
                            result = expressionTree.Evaluate();
                        }
                        catch
                        {
                            Console.WriteLine("Expression evaluate failed.");
                            return;
                        }

                        // if we are at this point, set value to result.
                        // Change the property of the cell.
                        this.SetCellValue(rowValue, columnValue, result.ToString());
                    }
                    else
                    {
                        // Do nothing right now. No = format detected at this point.
                        // Cell value changes only if = is the first symbol in the Text.
                    }
                }

                // Evoke to let the outside world know the property changed.
                this.CellPropertyChangedEventHandler?.Invoke(sender, new PropertyChangedEventArgs("CellPropertyChangedEvent"));
            }
            else
            {
            }
        }

        /// <summary>
        ///  Function used to look at all cells in array and subscribe to the PropertyChanged event
        ///  in each cell.
        /// </summary>
        private void SubscribeToAllCellChangeEvents()
        {
            // Unsubscribe from events if they exist already, then subscribe to all events
            for (int i = 0; i < this.cellArray.GetLength(0); i++)
            {
                for (int j = 0; j < this.cellArray.GetLength(1); j++)
                {
                    // Unsubscribe from this event. (Returns null if not found)
                    this.cellArray[i, j].PropertyChanged -= this.CellPropertyChanged;

                    // Subscribe to event (so only one instance of it exists)
                    this.cellArray[i, j].PropertyChanged += this.CellPropertyChanged;
                }
            }
        }
    }
}
