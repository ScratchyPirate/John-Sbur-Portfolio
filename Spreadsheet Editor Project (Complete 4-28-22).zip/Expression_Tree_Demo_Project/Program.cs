﻿// <copyright file="Program.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Spreadsheet_John_Sbur
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Cpts321;

    /// <summary>
    ///  Main program class. Runtime entry point is here.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        /// <param name="args">
        ///  Potential arguments passed into main.
        /// </param>
        public static void Main(string[] args)
        {
            // User input variables.
            int option = 0;
            string? optionString;
            char[] optionCharArray;

            // Expression storage string
            string expression = "A1-A2";

            // ExpressionTree. Begins compiled with the default expression above.
            ExpressionTree expressionTree = new ExpressionTree(expression);

            // Loop until 4 is entered by user.
            while (true)
            {
                // Print menu and current expression.
                Menu();
                Console.WriteLine("Current Expression: '{0}' ", expression);

                // Get user option.
                optionString = Console.ReadLine();

                // If input was recieved, convert it into an interger. Otherwise, the option is invalid.
                if (optionString != null)
                {
                    optionCharArray = optionString.ToCharArray();
                    option = (int)(optionCharArray[0] - 48);
                }
                else
                {
                    option = -1;
                }

                // Clear old screen.
                Console.Clear();

                switch (option)
                {
                    // Enter expression string. Assume valid expressions are entered.
                    case 1:

                        // Get user input.
                        Console.WriteLine("Enter a new expression:");
                        optionString = Console.ReadLine();

                        // Set the expression tree to be the new expression
                        if (optionString != null)
                        {
                            expressionTree = new ExpressionTree(optionString);
                            expression = optionString;
                            Console.WriteLine("Compiled expression into tree");
                        }
                        else
                        {
                            Console.WriteLine("Invalid Input");
                        }

                        break;

                    // Option to list variables and then set variable values.
                    case 2:

                        // List all variables in dictionary
                        expressionTree.ListAllVariables();

                        // Get user input.
                        Console.WriteLine("\nEnter the name of the variable you want to edit:");
                        optionString = Console.ReadLine();

                        // Check to make sure the inputted string isn't a number. If it isn't, create the variable or edit an existing one.
                        // Also checks to make sure the string isn't equal to "0" or "0.0"
                        double holder;
                        string? valueHolder;

                        // If the string isn't empty
                        if (optionString != null)
                        {
                            if (double.TryParse(optionString, out holder) == false
                            && (optionString != "0.0" && optionString != "0"))
                            {
                                // Get user input once again, asking for the value.
                                Console.WriteLine("Enter the value of the variable you want to edit:");
                                valueHolder = Console.ReadLine();

                                // If the valueHolder isn't null.
                                if (valueHolder != null)
                                {
                                    // Try to parse the inputted string and if it succesfully converts it to a double, then set the variable in the dictionary.
                                    if (double.TryParse(valueHolder, out holder) == true)
                                    {
                                        expressionTree.SetVariable(optionString, holder);
                                        expressionTree.ListAllVariables();
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid value passed in by user.");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("Invalid variable passed in by user (Was an integer or double. Variables cannot be integers or doubles)");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid variable passed in by user. String recieved was null");
                        }

                        break;

                    // Evalute current expression.
                    case 3:
                        Console.WriteLine("Expression: {0} = {1}", expression, expressionTree.Evaluate());
                        break;

                    // Exit option.
                    case 4:
                        Console.WriteLine("Exiting demo...");
                        Environment.Exit(0);
                        break;

                    // Catch case. Tells user input was invalid.
                    default:
                        Console.WriteLine("ERROR: Input invalid.");
                        break;
                }

                // Write 2 new lines for formatting.
                Console.WriteLine(Environment.NewLine);
            }
        }

        /// <summary>
        ///  Homework 5 menu function. Prints out the menu of options for the expression tree demo.
        /// </summary>
        public static void Menu()
        {
            Console.WriteLine("Homework 5: Expression Tree Simulator");
            Console.WriteLine("-(1): Enter an expression to store in the tree");
            Console.WriteLine("-(2): List current variables in tree, then you may edit one of them");
            Console.WriteLine("-(3): Evaluate current expression \n\t(NOTE: 0 is returned if the answer is 0 or if it fails. Failure to evalute will be notified to you)");
            Console.WriteLine("-(4): Quit");
        }
    }
}