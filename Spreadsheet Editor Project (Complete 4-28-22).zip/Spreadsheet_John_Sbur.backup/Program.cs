﻿// <copyright file="Program.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Spreadsheet_John_Sbur
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    /// <summary>
    ///  Main program class. Runtime entry point is here.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
