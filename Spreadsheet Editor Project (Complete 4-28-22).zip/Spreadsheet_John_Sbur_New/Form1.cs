﻿// <copyright file="Form1.cs" company="John Sbur 11663921">
// Copyright (c) John Sbur 11663921. All rights reserved.
// </copyright>

namespace Spreadsheet_John_Sbur
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Cpts321;

    /// <summary>
    ///  Main class that holds information, events, and behaviour of the spreadsheet window.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        ///  Keeps track of cell data on the dataGridView1 Spreadsheet.
        /// </summary>
        private Spreadsheet dataSpreadsheet;

        /// <summary>
        ///  Two stacks used for keeping track of the last image of the Spreadsheet.
        /// </summary>
        private Stack<Spreadsheet> undoStack;
        private Stack<Spreadsheet> redoStack;

        /// <summary>
        ///  Two parallel stacks working with undo and redo stack. Whenever a command is added to either, a string describing what undo or redo will do will be stored as well.
        /// </summary>
        private Stack<string> undoTextStack;
        private Stack<string> redoTextStack;

        /// <summary>
        ///  Keeps track of the last file written to.
        ///     If the user saves to a file, this gets set to the file path name.
        ///     If the user loads a file, this gets set to that file path name.
        /// </summary>
        private string? savedFilePath = null;

        /// <summary>
        ///  Associated with the undo and redo stacks. Begins at 0. Whenever undo or redo is activated, dirtyRedoStack is set to 1. Then, whenever a new command is called, if dirty is 1, pop everything in the redo stack.
        ///     This makes it so that if the user hits undo or redo, things will act as normal, but as soon as a new command is inputted, the past commands in redo don't interfere with the present state if redo
        ///     is entered. After the stack is cleared, reset dirtyRedoStack to 0.
        /// </summary>
        private int dirtyRedoStack;

        /// <summary>
        ///  The beginning part of the associated text box.
        ///  Not meant to be changed.
        /// </summary>
        private string defaultUndoText = "Undo    (Ctrl+Z) [";
        private string defaultRedoText = "Redo    (Ctrl+Y) [";
        private string defaultClearText = "Clear   (Ctrl+D)";
        private string defaultSaveText = "Save     (Ctrl+S)";
        private string defaultSaveAsText = "Save As";
        private string defaultNewText = "New     (Ctrl+N)";
        private string defaultOpenText = "Open    (Ctrl+O)";

        /// <summary>
        ///  Used for the KeyPressed event. Whena  key is pressed, set to true. When released, set to false.
        /// </summary>
        private bool isPressed = false;

        /// <summary>
        ///     Used for determining if a cell is being editted. Defaults to false. Set true during the beginning of CellBeginEdit and set to false again at the end of CellEndEdit.
        /// </summary>
        private bool isEditingCell = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        [Obsolete]
        public Form1()
        {
            this.InitializeComponent();

            // Initialize dataSpreadsheet
            this.dataSpreadsheet = new Spreadsheet(50, 26);

            // Initialize undo and redo stack and dirtyRedoStack
            this.dirtyRedoStack = 0;
            this.undoStack = new Stack<Spreadsheet>();
            this.redoStack = new Stack<Spreadsheet>();
            this.undoTextStack = new Stack<string>();
            this.redoTextStack = new Stack<string>();
            this.undoStack.Clear();
            this.redoStack.Clear();
            this.undoTextStack.Clear();
            this.redoTextStack.Clear();

            // Set button texts
            this.clearToolStripMenuItem.Text = this.defaultClearText;
            this.saveToolStripMenuItem.Text = this.defaultSaveText;
            this.saveAsToolStripMenuItem.Text = this.defaultSaveAsText;
            this.openFileToolStripMenuItem.Text = this.defaultOpenText;
            this.newToolStripMenuItem.Text = this.defaultNewText;
            this.undoToolStripMenuItem.Text = this.defaultUndoText;
            this.redoToolStripMenuItem.Text = this.defaultUndoText;

            // Subscribe to the event handler so when a property is changed it updates the grid.
            this.dataSpreadsheet.CellPropertyChangedEventHandler += this.UpdateDataGridCell;
            this.dataSpreadsheet.CellColorChangedHandler += this.UpdateCellColor;

            // Start with undo and redo disabled
            this.undoToolStripMenuItem.Visible = false;
            this.redoToolStripMenuItem.Visible = false;

            // Resize for easier viewing
            this.Width = 1000;
            this.Height = 1000;

            string holder = " ";

            // Clear existing columns and rows
            this.dataGridView1.Rows.Clear();
            this.dataGridView1.Columns.Clear();

            // Add columns A-Z.
            for (char i = 'A'; i <= 'Z'; i++)
            {
                holder = i.ToString();
                this.AddColumn(holder);
            }

            // Add rows 1-50
            for (int i = 1; i <= 50; i++)
            {
                holder = i.ToString();
                this.AddRow(holder);
            }

            // Resize row headers so multiple digits are seen.
            this.dataGridView1.RowHeadersWidth = 50;
        }

        /// <summary>
        ///  Adds the current image to the top of the undo stack. If the visible button is turned off, turn it on.
        /// </summary>
        /// <param name="description">
        ///  While the image of the spreadsheet is added to the stack. A description of the command is also added to the undo text stack.
        /// </param>
        [Obsolete]
        public void AddUndo(string description)
        {
            // Create a new spreadsheet image to store each property from dataSpreadsheet in the image.
            Spreadsheet spreadsheetImage = (Spreadsheet)this.dataSpreadsheet.Clone();

            // Push the image to the stack.
            this.undoStack.Push(spreadsheetImage);

            // Push description to text stack and update current textbox.
            this.undoTextStack.Push(description);
            this.undoToolStripMenuItem.Text = this.defaultUndoText + description + "]";

            // Turn on button if off
            if (this.undoToolStripMenuItem.Visible == false)
            {
                this.undoToolStripMenuItem.Visible = true;
            }
        }

        /// <summary>
        ///  Adds the current image to the top of the redo stack. If the visible button is turned off, turn it on.
        /// </summary>
        /// <param name="description">
        ///  While the image of the spreadsheet is added to the stack. A description of the command is also added to the redo text stack.
        /// </param>
        [Obsolete]
        public void AddRedo(string description)
        {
            // Create a new spreadsheet image to store each property from dataSpreadsheet in the image.
            Spreadsheet spreadsheetImage = (Spreadsheet)this.dataSpreadsheet.Clone();

            // Push the image to the stack.
            this.redoStack.Push(spreadsheetImage);

            // Push description to text stack and update current textbox.
            this.redoTextStack.Push(description);
            this.redoToolStripMenuItem.Text = this.defaultRedoText + description + "]";

            // Turn on button if off
            if (this.redoToolStripMenuItem.Visible == false)
            {
                this.redoToolStripMenuItem.Visible = true;
            }
        }

        /// <summary>
        ///  Pops the top member of the undo stack and returns it.
        /// </summary>
        /// <param name="description">
        ///  Reference string description. Used to pass the text description through the function after it's popped.
        /// </param>
        /// <returns>
        ///  Popped member or null if nothing was popped.
        /// </returns>
        public Spreadsheet? PopUndo(ref string description)
        {
            // Storage variable used for returning the popped string array.
            Spreadsheet? returnValue = null;

            // If stack not empty and the button is visible
            if (this.undoStack.Count > 0)
            {
                // Pop next member
                returnValue = this.undoStack.Pop();

                // Set description equal to the popped text
                // Pop next text member
                description = this.undoTextStack.Pop();

                // If count is 0 now, make the button invisible.
                if (this.undoStack.Count == 0)
                {
                    this.undoToolStripMenuItem.Visible = false;
                }

                // If not zero, update the current textbox to be accurate to the next undo.
                else
                {
                    this.undoToolStripMenuItem.Text = this.defaultUndoText + this.undoTextStack.Peek() + "]";
                }
            }

            // Return when done. Return string with "Empty" as the only token if nothing was popped
            return returnValue;
        }

        /// <summary>
        ///  Pops the top member of the redo stack and returns it.
        /// </summary>
        /// <param name="description">
        ///  Reference string description. Used to pass the text description through the function after it's popped.
        /// </param>
        /// <returns>
        ///  Popped member or null if nothing was popped.
        /// </returns>
        public Spreadsheet? PopRedo(ref string description)
        {
            // Storage variable used for returning the popped string array.
            Spreadsheet? returnValue = null;

            // If stack not empty
            if (this.redoStack.Count > 0)
            {
                // Pop next member
                returnValue = this.redoStack.Pop();

                // Set description equal to the popped text
                // Pop next text member
                description = this.redoTextStack.Pop();

                // If count is 0 now, make the button invisible.
                if (this.redoStack.Count == 0)
                {
                    this.redoToolStripMenuItem.Visible = false;
                }

                // If not zero, update the current textbox to be accurate to the next undo.
                else
                {
                    this.redoToolStripMenuItem.Text = this.defaultRedoText + this.redoTextStack.Peek() + "]";
                }
            }

            // Return when done. Return string with "Empty" as the only token if nothing was popped
            return returnValue;
        }

        /// <summary>
        ///  Checks if the variable dirtyRedoStack is dirty. If it is, clear the redo stack and makes the redo button invisible.
        /// </summary>
        public void ClearDirtyRedoStack()
        {
            // If the redo stack is dirty, pop everything in the redostack.
            if (this.dirtyRedoStack == 1)
            {
                this.redoStack.Clear();
                this.redoTextStack.Clear();
                this.dirtyRedoStack = 0;
                this.redoToolStripMenuItem.Visible = false;
            }
        }

        /// <summary>
        ///  Using the undo stack and the undo text stack, undo the last action. This happens if the undo stack isn't empty.
        /// </summary>
        [Obsolete]
        public void Undo()
        {
            // If the stack isn't empty. Load pop and load the image on top in.
            if (this.undoStack.Count > 0)
            {
                // Load spreadsheet image. And get description of the image.
                Spreadsheet? poppedSpreadsheet;
                string poppedDescription = new string(string.Empty);
                poppedSpreadsheet = this.PopUndo(ref poppedDescription);

                if (poppedSpreadsheet != null)
                {
                    // Store image in undo stack.
                    this.AddRedo(poppedDescription);

                    this.LoadSpreadsheet(poppedSpreadsheet);
                }
            }
        }

        /// <summary>
        ///  Using the undo stack and the undo text stack, undo the last action. This happens if the undo stack isn't empty.
        /// </summary>
        [Obsolete]
        public void Redo()
        {
            // If the stack isn't empty. Load pop and load the image on top in.
            if (this.redoStack.Count > 0)
            {
                // Load spreadsheet image. And get description of the image.
                Spreadsheet? poppedSpreadsheet;
                string poppedDescription = new string(string.Empty);
                poppedSpreadsheet = this.PopRedo(ref poppedDescription);

                if (poppedSpreadsheet != null)
                {
                    // Store image in redo stack.
                    this.AddUndo(poppedDescription);

                    this.LoadSpreadsheet(poppedSpreadsheet);

                    // Set dirty to 1
                    this.dirtyRedoStack = 1;
                }
            }
        }

        /// <summary>
        ///  Saves the current image of the spreadsheet to a file in XML format. Prompts the user for a fileName before
        ///     proceeding and resets savedFilePath if the filename given by the user is valid.
        /// </summary>
        public void SaveAs()
        {
            // Create an open a save file dialog. Set filters to be .xml files only
            SaveFileDialog newDialog = new SaveFileDialog();
            newDialog.Filter = "Text File (.xml)|*.xml";
            newDialog.Title = "Save Spreadsheet";
            newDialog.ShowDialog();

            // Afterwards, if the file name isn't null. Save the current spreadsheet.
            if (newDialog.FileName != string.Empty)
            {
                Stream outputStream = newDialog.OpenFile();
                StreamWriter outputStreamWriter = new StreamWriter(outputStream);
                this.dataSpreadsheet.Save(outputStreamWriter);

                // Save the pathname of the file
                this.savedFilePath = newDialog.FileName;

                // Change spreadsheet title to match filename
                this.Text = "Spreadsheet - " + newDialog.FileName;

                // Close file
                outputStreamWriter.Close();
                outputStream.Close();
            }
        }

        /// <summary>
        ///  If the savedFilePath isn't null, save the current spreadsheet to that file. Otherwise, call SaveAs() to open a new file to save to.
        /// </summary>
        public void Save()
        {
            // If savedFilePath isn't null. Write spreadsheet to that file.
            if (this.savedFilePath != null)
            {
                StreamWriter outputStreamWriter = new StreamWriter(this.savedFilePath);
                this.dataSpreadsheet.Save(outputStreamWriter);
                outputStreamWriter.Close();
            }

            // Else, call SaveAs()
            else
            {
                this.SaveAs();
            }
        }

        /// <summary>
        ///  Attempts to load a spreadsheet from a .xml file. If it fails, nothing changes. If there was a file opened previously, this also saves that data to its associated xml file.
        /// </summary>
        [Obsolete]
        public void LoadFile()
        {
            // Local used for storing tokens from PopUndo.
            string temporaryString = string.Empty;

            // Create an open a load file dialog. Set filters to be .xml files only
            OpenFileDialog newDialog = new OpenFileDialog();
            newDialog.Filter = "Text File (.xml)|*.xml";
            newDialog.Title = "Open Spreadsheet";
            newDialog.ShowDialog();

            // Afterwards, if the file name isn't null. Clear the current spreadsheet and load this new one. If it can't be loaded, restore old spreadsheet
            if (newDialog.FileName != string.Empty)
            {
                // If the savedFilePath isn't null and not the current file, save the work to that file path before loading
                if (this.savedFilePath != null && this.savedFilePath != newDialog.FileName)
                {
                    this.Save();
                }

                // Save image in case spreadsheet isn't loaded correctly
                this.AddUndo("Spreadsheet Image");

                try
                {
                    // Clear current spreadsheet
                    this.Clear();

                    // Atempt to load in the new spreadsheet.
                    StreamReader inputStreamReader = new StreamReader(newDialog.FileName);
                    this.dataSpreadsheet.Load(inputStreamReader);

                    // If the column or row count of the loaded spreadsheet isn't equal to the dataGridView's, throw.
                    if (this.dataSpreadsheet.RowCount != this.dataGridView1.RowCount || this.dataSpreadsheet.ColumnCount != this.dataGridView1.ColumnCount)
                    {
                        throw new Exception("Loaded spreadsheet's dimensions didn't match dataGridView's");
                    }

                    // Proceed with loading at this point.
                    this.LoadSpreadsheet(this.dataSpreadsheet);

                    // After loading it in
                    // Subscribe to the event handler so when a property is changed it updates the grid.
                    this.dataSpreadsheet.CellPropertyChangedEventHandler += this.UpdateDataGridCell;
                    this.dataSpreadsheet.CellColorChangedHandler += this.UpdateCellColor;

                    // Reset undo and redo.
                    this.dirtyRedoStack = 0;
                    this.undoStack.Clear();
                    this.redoStack.Clear();
                    this.undoTextStack.Clear();
                    this.redoTextStack.Clear();
                    this.undoToolStripMenuItem.Visible = false;
                    this.redoToolStripMenuItem.Visible = false;

                    // Change spreadsheet title to match filename
                    this.Text = "Spreadsheet - " + newDialog.FileName;

                    // Set savedFilePath to this dialog's filepath
                    this.savedFilePath = newDialog.FileName;

                    // Pop unused Undo at this point
                    this.PopUndo(ref temporaryString);

                    // Close file
                    inputStreamReader.Close();
                }
                catch
                {
                    // If the code throws, restore the old spreadsheet.

                    // Cannot be null since it was pushed up above so the stack contains at least 1 member.
#pragma warning disable CS8601 // Possible null reference assignment.
#pragma warning disable CS8604 // Possible null reference argument.
                    this.dataSpreadsheet = this.PopUndo(ref temporaryString);
                    this.LoadSpreadsheet(this.dataSpreadsheet);
#pragma warning restore CS8604 // Possible null reference argument.
#pragma warning restore CS8601 // Possible null reference assignment.
                }
            }
        }

        /// <summary>
        ///  Creates a new file named by the user. Then, stores or deletes the current data of the present spreadsheet and loads in a new blank one.
        /// </summary>
        public void CreateAndLoadNewFile()
        {
            // Create an open a save file dialog. Set filters to be .xml files only
            SaveFileDialog newDialog = new SaveFileDialog();
            newDialog.Filter = "Text File (.xml)|*.xml";
            newDialog.Title = "New Spreadsheet";
            newDialog.ShowDialog();

            // Afterwards, if the file name isn't null. Create the new spreadsheet.
            if (newDialog.FileName != string.Empty)
            {
                // If the savedFilePath isn't empty, save before proceeding.
                if (this.savedFilePath != null)
                {
                    this.Save();
                }

                // Open spreadsheet for write.
                Stream outputStream = newDialog.OpenFile();
                StreamWriter outputStreamWriter = new StreamWriter(outputStream);

                // Create a new blank spreadsheet with same dimensions as old spreadsheet.
                Spreadsheet newSpreadsheet = new Spreadsheet(this.dataSpreadsheet.RowCount, this.dataSpreadsheet.ColumnCount);

                // Set blank spreadsheet as this spreadsheet
                this.dataSpreadsheet = newSpreadsheet;

                // Write blank spreadsheet to newly openned file
                this.dataSpreadsheet.Save(outputStreamWriter);

                // Load spreadsheet into dataGridView1
                this.LoadSpreadsheet(this.dataSpreadsheet);

                // Resubscribe to the event handler so when a property is changed it updates the grid.
                this.dataSpreadsheet.CellPropertyChangedEventHandler += this.UpdateDataGridCell;
                this.dataSpreadsheet.CellColorChangedHandler += this.UpdateCellColor;

                // Reset undo and redo.
                this.dirtyRedoStack = 0;
                this.undoStack.Clear();
                this.redoStack.Clear();
                this.undoTextStack.Clear();
                this.redoTextStack.Clear();
                this.undoToolStripMenuItem.Visible = false;
                this.redoToolStripMenuItem.Visible = false;

                // Save the pathname of the file
                this.savedFilePath = newDialog.FileName;

                // Change spreadsheet title to match filename
                this.Text = "Spreadsheet - " + newDialog.FileName;

                // Close file
                outputStreamWriter.Close();
                outputStream.Close();
            }
        }

        /// <summary>
        ///  Clears all spreadsheet data and resets everything.
        /// </summary>
        [Obsolete]
        public void Clear()
        {
            // Clears the redo stack if dirty.
            this.ClearDirtyRedoStack();

            // Save undo image to undo stack
            this.AddUndo("Clear Spreadsheet");

            // Clear current spreadsheet.
            this.dataSpreadsheet.Clear();

            // Set the current spreadsheet to the new blank spreadsheet.
            this.LoadSpreadsheet(this.dataSpreadsheet);
        }

        /// <summary>
        ///  Given a spreadsheet as an input, this function loads that spreadsheet into the dataGridView1 if the row and column counts are the same.
        /// </summary>
        /// <param name="newSpreadsheet">
        ///  Array to be loaded in.
        /// </param>
        public void LoadSpreadsheet(Spreadsheet newSpreadsheet)
        {
            // If the row and column counts are the same, we are safe to load in.
            if (newSpreadsheet.RowCount == this.dataSpreadsheet.RowCount
                && newSpreadsheet.ColumnCount == this.dataSpreadsheet.ColumnCount)
            {
                // Set old spreadsheet cell array to new spreadsheet
                this.dataSpreadsheet.CellPropertyChangedEventHandler -= this.UpdateDataGridCell;
                this.dataSpreadsheet.CellColorChangedHandler -= this.UpdateCellColor;
                this.dataSpreadsheet = newSpreadsheet;

                // Resubscribe to event changes
                // Subscribe to the event handler so when a property is changed it updates the grid.
                this.dataSpreadsheet.CellPropertyChangedEventHandler += this.UpdateDataGridCell;
                this.dataSpreadsheet.CellColorChangedHandler += this.UpdateCellColor;

                // Update dataGridView cells
                for (int i = 0; i < this.dataSpreadsheet.RowCount; i++)
                {
                    for (int j = 0; j < this.dataSpreadsheet.ColumnCount; j++)
                    {
                        // Update cell text and value.
                        this.UpdateCell(i, j);

                        // Update cell color.
                        if ((this.dataSpreadsheet.RowCount > i && i >= 0)
                            && (j >= 0 && j < this.dataSpreadsheet.ColumnCount))
                        {
                            if ((this.dataGridView1.Rows.Count > i)
                                && (this.dataGridView1.Columns.Count > j))
                            {
                                this.dataGridView1[j, i].Style.BackColor =
                                    Color.FromArgb(this.dataSpreadsheet.CellArray[i, j].BGCOLOR);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        ///  Function used to add columns into the application.
        /// </summary>
        /// <param name="name">
        ///  Used to mark the name of the column to be added.
        /// </param>
        private void AddColumn(string name)
        {
            // Create and name column
            DataGridViewColumn newColumn = new DataGridViewColumn();
            newColumn.Name = name;

            // Create template cell for column to use as default
            DataGridViewCell cellTemplate = new DataGridViewTextBoxCell();
            cellTemplate.Style.BackColor = Color.White;

            // Set column template to cell
            newColumn.CellTemplate = cellTemplate;

            // Insert new column
            this.dataGridView1.Columns.Add(newColumn);
        }

        /// <summary>
        ///  Function used to add rows into the application.
        /// </summary>
        /// <param name="name">
        ///  Name of row to be added.
        /// </param>
        private void AddRow(string name)
        {
            DataGridViewRow newRow = new DataGridViewRow();
            newRow.HeaderCell.Value = name;
            this.dataGridView1.Rows.Add(newRow);
        }

        /// <summary>
        ///  Function used to manually update dataGridView cells.
        /// </summary>
        /// <param name="rowIndex">
        ///  Target row to be updated.
        /// </param>
        /// <param name="columnIndex">
        ///  Target column to be updated.
        /// </param>
        private void UpdateCell(int rowIndex, int columnIndex)
        {
            // If the target is in range, edit the cell requested by updating the text of the cell in the grid to match the spreadsheet cell. Otherwise, return.
            if ((this.dataSpreadsheet.RowCount > rowIndex && rowIndex >= 0) && (columnIndex >= 0 && columnIndex < this.dataSpreadsheet.ColumnCount))
            {
                if ((this.dataGridView1.Rows.Count > rowIndex) && (this.dataGridView1.Columns.Count > columnIndex))
                {
                    this.dataGridView1[columnIndex, rowIndex].Value = this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Value;
                }
            }

            return;
        }

        /// <summary>
        ///  Function used to manually update a dataGridView cell color.
        /// </summary>
        /// <param name="sender">
        ///  Sending object, usually a spreadsheetcell.
        /// </param>
        /// <param name="e">
        ///  ARguments sent from sender object.
        /// </param>
        private void UpdateCellColor(object? sender, EventArgs e)
        {
            // If the sender is a Spreadsheet Cell...
            if (sender != null)
            {
                if (sender.GetType() == typeof(SpreadsheetCell))
                {
                    SpreadsheetCell sourceCell = (SpreadsheetCell)sender;

                    // If the target is in range, edit the cell requested by updating the color of the cell in the grid to match the spreadsheet cell. Otherwise, return.
                    if ((this.dataSpreadsheet.RowCount > sourceCell.RowIndex && sourceCell.RowIndex >= 0) && (sourceCell.ColumnIndex >= 0 && sourceCell.ColumnIndex < this.dataSpreadsheet.ColumnCount))
                    {
                        if ((this.dataGridView1.Rows.Count > sourceCell.RowIndex) && (this.dataGridView1.Columns.Count > sourceCell.ColumnIndex))
                        {
                            this.dataGridView1[sourceCell.ColumnIndex, sourceCell.RowIndex].Style.BackColor = Color.FromArgb(this.dataSpreadsheet.CellArray[sourceCell.RowIndex, sourceCell.ColumnIndex].BGCOLOR);
                        }
                    }

                    return;
                }
            }
        }

        /// <summary>
        ///  Event triggers on a Cell's data changing. Changed the dataGridView's table's corresponding cell to match the change.
        /// </summary>
        /// <param name="sender">
        ///  Sending object, usually a spreadsheetcell.
        /// </param>
        /// <param name="e">
        ///  ARguments sent from sender object.
        /// </param>
        private void UpdateDataGridCell(object? sender, EventArgs e)
        {
            if (sender != null)
            {
                if (sender.GetType() == typeof(SpreadsheetCell))
                {
                    SpreadsheetCell sourceCell = (SpreadsheetCell)sender;
                    this.UpdateCell(sourceCell.RowIndex, sourceCell.ColumnIndex);
                }
            }
        }

        /// <summary>
        ///  Event triggers when demo button is clicked.
        ///  The demo should set the text in about 50 random cells to a text string of your choice.
        ///     “Hello World!” would be fine or some other message would be ok too.
        ///  o Also, do a loop to set the text in every cell in column B to “This is cell B#”, where #
        ///     number is the row number for the cell.
        ///  o Then set the text in every cell in column A to “=B#”, where ‘#’ is the row number of the
        ///     cell. So in other words you’re setting every cell in column A to have a value equal to the
        ///     cell to the right of it in column B.
        ///  o The result should be that the cells in column A update to have the same values as
        ///     column B.
        /// </summary>
        /// <param name="sender">
        ///  Object that sent the event.
        /// </param>
        /// <param name="e">
        ///  Arguments sent from sender when event was invoked.
        /// </param>
        private void DemoButtonClicked(object sender, EventArgs e)
        {
            // Part 1, fill 50 random cells.
            var randomNumberGenerator = new Random();
            int randomColumn = 0;
            int randomRow = 0;

            for (int i = 0; i < 50;)
            {
                randomColumn = randomNumberGenerator.Next(0, 26);
                randomRow = randomNumberGenerator.Next(0, 50);

                SpreadsheetCell[,] holderArray = this.dataSpreadsheet.CellArray;

                if (holderArray[randomRow, randomColumn].Text == string.Empty)
                {
                    this.dataSpreadsheet.SetCellText(randomRow, randomColumn, "Hello World!");
                    i++;
                }
            }

            // Part 2, set every column in column B to "This is cell B#"
            for (int i = 0; i < 50; i++)
            {
                this.dataSpreadsheet.SetCellText(i, 1, "This is cell B" + (i + 1).ToString());
            }

            // Part 3, set every column in column A to "=B#"
            for (int i = 0; i < 50; i++)
            {
                this.dataSpreadsheet.SetCellText(i, 0, "=B" + (i + 1).ToString());
            }
        }

        // ************************************************* Cell Edit Events ************************************************* //

        /// <summary>
        ///  Event triggers when the cell is selected for editing. Text is displayed instead of value.
        /// </summary>
        /// <param name="sender">
        ///  Cell that triggered the event.
        /// </param>
        /// <param name="e">
        ///  Arguments passed into event.
        /// </param>
        // Warning suppressed because code was autogenerated and tampering destabilized the application.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            // Set editing cell bool to true
            this.isEditingCell = true;

            if (this.dataSpreadsheet != null)
            {
                if (this.dataSpreadsheet.GetCell(e.RowIndex, e.ColumnIndex) != null)
                {
                    // Cannot be null since if statements before checked to make sure it isn't null.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                    if (this.dataSpreadsheet.GetCell(e.RowIndex, e.ColumnIndex).Text != null)
                    {
                        this.dataGridView1[e.ColumnIndex, e.RowIndex].Value = this.dataSpreadsheet.CellArray[e.RowIndex, e.ColumnIndex].Text;
                    }
#pragma warning restore CS8602 // Dereference of a possibly null reference.
                }
            }
        }

        /// <summary>
        ///  Event triggers when the cell is unselected for editing. Updated value is displayed based on the entered text from the user instead of text.
        /// </summary>
        /// <param name="sender">
        ///  Cell that triggered the event.
        /// </param>
        /// <param name="e">
        ///  Arguments passed into event.
        /// </param>
        // Warning suppressed because code was autogenerated and tampering destabilized the application.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            if (this.dataSpreadsheet != null && this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex] != null)
            {
                this.EndEditHelper(e.RowIndex, e.ColumnIndex);
                Cell.ChangesInvoked = 0;
            }
        }

        /// <summary>
        ///  Helper function for the cell end edit event. Stores and updates data of the cell inputted.
        /// </summary>
        /// <param name="rowIndex">
        ///  Row index of cell just updated.
        /// </param>
        /// <param name="columnIndex">
        ///  Column index of cell just updated.
        /// </param>
        /// <returns>
        ///  0 if not completed
        ///  1 if completed successfully
        ///  2 if completed but an error was encountered
        ///  3 if there was a stack error.
        /// </returns>
        [Obsolete]
        private int EndEditHelper(int rowIndex, int columnIndex)
        {
            // Local used in catch for determining if undo stack had something added to it within the try{} Portion of this function.
            int addedToUndoStack = 0;

            // Used for determining if an error occured in the AddUndo portion of this function
            // Error = 1 means it occured during the delete cell edit (first else if statement)
            // Error = 2 means it occured while editing a cell (first else statement)
            int undoStackError = 0;

            if (this.dataGridView1.Rows[rowIndex].Cells[columnIndex].Value != null)
            {
                try
                {
                    if (this.dataSpreadsheet.GetCell(rowIndex, columnIndex) != null && this.dataGridView1.Rows[rowIndex].Cells[columnIndex].Value.ToString() != null)
                    {
                        // Section for undo redo
                        this.ClearDirtyRedoStack();

                        // If nothing changed, change the cell back to the original value with possibly updated variable values.
                        if (this.dataGridView1.Rows[rowIndex].Cells[columnIndex].Value.ToString() == this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Text)
                        {
#pragma warning disable CS8604 // Possible null reference argument.
                            this.dataSpreadsheet.SetCellText(rowIndex, columnIndex, string.Empty);
                            this.dataSpreadsheet.SetCellText(rowIndex, columnIndex, this.dataGridView1.Rows[rowIndex].Cells[columnIndex].Value.ToString());
#pragma warning restore CS8604 // Possible null reference argument.
                        }

                        // if the new text is the empty string, set it to the empty string
                        else if (this.dataGridView1.Rows[rowIndex].Cells[columnIndex].Value.ToString() == string.Empty)
                        {
                            // Add undo command to stack
                            undoStackError = 1;
                            this.AddUndo("Delete Cell Text");
                            undoStackError = 0;
                            addedToUndoStack = 1;

                            this.dataGridView1[columnIndex, rowIndex].Value = string.Empty;
                            this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Text = string.Empty;
                            this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Value = string.Empty;
                        }

                        // Otherwise, update the cell.
                        else
                        {
                            // Cannot be null as if statement before checks to make sure it isn't.
                            // Add undo command to stack
                            undoStackError = 2;
                            this.AddUndo("Edit Cell Text");
                            undoStackError = 0;
                            addedToUndoStack = 1;

#pragma warning disable CS8604 // Possible null reference argument.
                            this.dataSpreadsheet.SetCellText(rowIndex, columnIndex, string.Empty);
                            this.dataSpreadsheet.SetCellText(rowIndex, columnIndex, this.dataGridView1.Rows[rowIndex].Cells[columnIndex].Value.ToString());
#pragma warning restore CS8604 // Possible null reference argument.
                        }
                    }

                    return 1;
                }
                catch (Exception ex)
                {
                    // Locals
                    int confirmUndoStackError = 0;
                    string errorMessage = ex.Message;

                    // If we added to the undo stack, pop from that stack
                    // Temporary variable used for storing the pop, but not using it after.
                    if (addedToUndoStack == 1)
                    {
                        string temp = string.Empty;
                        this.PopUndo(ref temp);
                    }

                    // If the error occured while adding to the stack, reset the text.
                    if (undoStackError >= 1)
                    {
                        // If we edited the cell text, we want to make sure that the text is updated, but safely so that it doesn't cause an error.
                        if (undoStackError == 2)
                        {
                            // Set text of dataGridView to cell value without invoking a propertychanged event.
                            this.dataSpreadsheet.CellArray[rowIndex, columnIndex].SafeText = this.dataGridView1[columnIndex, rowIndex].Value.ToString();

                            // Try and catch the error again. Set the text of this exception to the error message
                            try
                            {
#pragma warning disable CS8604 // Possible null reference argument.
                                this.dataSpreadsheet.SetCellText(rowIndex, columnIndex, string.Empty);
                                this.dataSpreadsheet.SetCellText(rowIndex, columnIndex, this.dataGridView1.Rows[rowIndex].Cells[columnIndex].Value.ToString());
#pragma warning restore CS8604 // Possible null reference argument.
                            }
                            catch (Exception ex2)
                            {
                                errorMessage = ex2.Message;
                                confirmUndoStackError = 1;
                            }
                        }
                        else if (undoStackError == 1)
                        {
                            // Set text of dataGridView to cell value without invoking a propertychanged event.
                            this.dataSpreadsheet.CellArray[rowIndex, columnIndex].SafeText = string.Empty;

                            // Try and catch the error again. Set the text of this exception to the error message
                            try
                            {
                                this.dataGridView1[columnIndex, rowIndex].Value = string.Empty;
                                this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Text = string.Empty;
                                this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Value = string.Empty;
                            }
                            catch (Exception ex2)
                            {
                                errorMessage = ex2.Message;
                                confirmUndoStackError = 1;
                            }
                        }
                    }

                    // If an error was found when adding to the undo stack, but no error was found when invoking the respective command, set cell text like normal since nothing was wrong.
                    if (undoStackError >= 1 && confirmUndoStackError == 0)
                    {
                        this.dataGridView1[columnIndex, rowIndex].Value = this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Value;
                        return 2;
                    }

                    // Circular reference error
                    else if (errorMessage == "Variable expression contains circular reference")
                    {
                        this.dataGridView1[columnIndex, rowIndex].Value = "!(circular reference)";
                    }

                    // Invalid Variable error
                    else if (errorMessage == "Variable found wasn't a cell")
                    {
                        this.dataGridView1[columnIndex, rowIndex].Value = "!(invalid cell)";
                    }

                    // Generic error
                    else
                    {
                        this.dataGridView1[columnIndex, rowIndex].Value = "!(error)";
                    }
                }

                // Set editing cell bool to false
                this.isEditingCell = false;

                return 3;
            }
            else
            {
                this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Text = string.Empty;
                this.dataSpreadsheet.CellArray[rowIndex, columnIndex].Value = string.Empty;
            }

            return 0;
        }

        // ************************************************* File Button Events ************************************************* //

        /// <summary>
        ///  New button clicked event. Resets the current dataGridView and dataSpreadsheet while also creating a new file to write to.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event args.
        /// </param>
        /// // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            this.CreateAndLoadNewFile();
        }

        /// <summary>
        ///  Save button clicked event. Saves current image to a file specified by the user or the most recently saved to file or the most recently loaded file.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event args.
        /// </param>
        /// // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            this.LoadFile();
        }

        /// <summary>
        ///  Save button clicked event. Saves current image to a file specified by the user or the most recently saved to file or the most recently loaded file.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event args.
        /// </param>
        /// // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            this.Save();
        }

        /// <summary>
        ///  Save button clicked event. Saves current image to a file specified by the user.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event args.
        /// </param>
        /// // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            this.SaveAs();
        }

        // ************************************************* Edit Button Events ************************************************* //

        /// <summary>
        ///  On click of the yellowToolStripMenuItem, change all cell backgrounds to be yellow.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void yellowToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            // Section for undo redo
            this.ClearDirtyRedoStack();

            // Add to undo stack
            this.AddUndo("Set All Colors Yellow");

            // Set Colors
            this.dataSpreadsheet.SetAllColors(-256);
        }

        /// <summary>
        ///  On click of the blueToolStripMenuItem, change all cell backgrounds to be blue.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            // Section for undo redo
            this.ClearDirtyRedoStack();

            // Add to undo stack
            this.AddUndo("Set All Colors Blue");

            this.dataSpreadsheet.SetAllColors(-16776961);
        }

        /// <summary>
        ///  On click of the redToolStripMenuItem, change all cell backgrounds to be red.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
        [Obsolete]
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void redToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            // Section for undo redo
            this.ClearDirtyRedoStack();

            // Add to undo stack
            this.AddUndo("Set All Colors Red");

            this.dataSpreadsheet.SetAllColors(-65536);
        }

        /// <summary>
        ///  On click of the customToolStripMenuItem, change all cell backgrounds to be the color specified in the color dialog.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void customToolStripMenuItem_Click(object sender, EventArgs e)
        {
#pragma warning restore SA1300 // Element should begin with upper-case letter
            // Initializes color dialog.
            ColorDialog colorDialog = new ColorDialog();

            // Allows the user to get help.
            colorDialog.ShowHelp = true;

            // Sets the initial color select to white.
            colorDialog.Color = Color.White;

            // Update the text box color if the user clicks OK.
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                // Section for undo redo
                this.ClearDirtyRedoStack();

                // Add to undo stack
                this.AddUndo("Set All Colors " + colorDialog.Color.ToString());

                // Set all colors
                this.dataSpreadsheet.SetAllColors(colorDialog.Color.ToArgb());
            }
        }

        /// <summary>
        ///  On click of the yellowToolStripMenuItem1, change all selected cell backgrounds to be yellow.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void yellowToolStripMenuItem1_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            // Section for undo redo
            this.ClearDirtyRedoStack();

            // Add to undo stack
            this.AddUndo("Set Selected Colors Yellow");

            // Local variables
            int rowNumber = 0;
            int columnNumber = 0;

            // For each selected cell...
            for (int i = 0; i < this.dataGridView1.GetCellCount(DataGridViewElementStates.Selected); i++)
            {
                // Get row and column number of selected cell.
                rowNumber = this.dataGridView1.SelectedCells[i].RowIndex;
                columnNumber = this.dataGridView1.SelectedCells[i].ColumnIndex;

                // Set cell color.
                this.dataSpreadsheet.SetCellColor(rowNumber, columnNumber, -256);
            }
        }

        /// <summary>
        ///  On click of the blueToolStripMenuItem1, change all selected cell backgrounds to be blue.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void blueToolStripMenuItem1_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            // Section for undo redo
            this.ClearDirtyRedoStack();

            // Add to undo stack
            this.AddUndo("Set Selected Colors Blue");

            // Local variables
            int rowNumber = 0;
            int columnNumber = 0;

            // For each selected cell...
            for (int i = 0; i < this.dataGridView1.GetCellCount(DataGridViewElementStates.Selected); i++)
            {
                // Get row and column number of selected cell.
                rowNumber = this.dataGridView1.SelectedCells[i].RowIndex;
                columnNumber = this.dataGridView1.SelectedCells[i].ColumnIndex;

                // Set cell color.
                this.dataSpreadsheet.SetCellColor(rowNumber, columnNumber, -16776961);
            }
        }

        /// <summary>
        ///  On click of the redToolStripMenuItem1, change all selected cell backgrounds to be red.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void redToolStripMenuItem1_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            // Section for undo redo
            this.ClearDirtyRedoStack();

            // Add to undo stack
            this.AddUndo("Set Selected Colors Red");

            // Local variables
            int rowNumber = 0;
            int columnNumber = 0;

            // For each selected cell...
            for (int i = 0; i < this.dataGridView1.GetCellCount(DataGridViewElementStates.Selected); i++)
            {
                // Get row and column number of selected cell.
                rowNumber = this.dataGridView1.SelectedCells[i].RowIndex;
                columnNumber = this.dataGridView1.SelectedCells[i].ColumnIndex;

                // Set cell color.
                this.dataSpreadsheet.SetCellColor(rowNumber, columnNumber, -65536);
            }
        }

        /// <summary>
        ///  On click of the customToolStripMenuItem, change all selected cell backgrounds to be the color specified in the color dialog.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void customToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
#pragma warning restore SA1300 // Element should begin with upper-case letter

            // Initializes color dialog.
            ColorDialog colorDialog = new ColorDialog();

            // Allows the user to get help.
            colorDialog.ShowHelp = true;

            // Sets the initial color select to white.
            colorDialog.Color = Color.White;

            // Update the text box color if the user clicks OK.
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                // Local variables
                int rowNumber = 0;
                int columnNumber = 0;

                // Section for undo redo
                this.ClearDirtyRedoStack();

                // Add to undo stack
                this.AddUndo("Set Selected Colors " + colorDialog.Color.ToString());

                // For each selected cell...
                for (int i = 0; i < this.dataGridView1.GetCellCount(DataGridViewElementStates.Selected); i++)
                {
                    // Get row and column number of selected cell.
                    rowNumber = this.dataGridView1.SelectedCells[i].RowIndex;
                    columnNumber = this.dataGridView1.SelectedCells[i].ColumnIndex;

                    // Set cell color.
                    this.dataSpreadsheet.SetCellColor(rowNumber, columnNumber, colorDialog.Color.ToArgb());
                }
            }
        }

        /// <summary>
        ///  Clear button event. Clears the current spreadsheet and resets everything.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event args.
        /// </param>
        [Obsolete]

        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            if (!this.isEditingCell)
            {
                this.Clear();
            }
        }

        /// <summary>
        ///  Undo command for Form1. If there is an element on top of the undo stack, load it in and add the old one to the redo stack.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
#pragma warning restore SA1300 // Element should begin with upper-case letter
        {
            if (!this.isEditingCell)
            {
                this.Undo();
            }
        }

        /// <summary>
        ///  Redo command for Form1. If there is an element on top of the redo stack, load it in and add the old one to the undo stack. Set dirty redo stack to 1.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Event arguments.
        /// </param>
        // Name follows WinForms default naming convention and shouldn't be changed.
#pragma warning disable SA1300 // Element should begin with upper-case letter
        [Obsolete]
        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
#pragma warning restore SA1300 // Element should begin with upper-case letter
            if (!this.isEditingCell)
            {
                this.Redo();
            }
        }

        // ************************************************* KeyBoard Events ************************************************* //

        /// <summary>
        ///  On Key down, check for if a command is inputted.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Key event args.
        /// </param>
        [Obsolete]
        private void Form1_KeyPressed(object sender, KeyPressEventArgs e)
        {
            // If control is pressed. Search for different actions to perform based on the key pressed.
            // Occurs also if this is the only key pressed and no text cells are being edited.
            if (ModifierKeys == Keys.Control && (!this.isPressed))
            {
                // Set isPressed lock.
                this.isPressed = true;

                // Undo Ctrl+Z (char 26 represents Z)
                if (e.KeyChar == (char)26 && !this.isEditingCell)
                {
                    this.Undo();
                }

                // Redo Ctrl+Y (char 25 represents Y)
                else if (e.KeyChar == (char)25 && !this.isEditingCell)
                {
                    this.Redo();
                }

                // Clear Ctrl+D (char 4 represents D)
                else if (e.KeyChar == (char)4 && !this.isEditingCell)
                {
                    this.Clear();
                }

                // Open Ctrl+O (char 15 represents O)
                else if (e.KeyChar == (char)15)
                {
                    this.LoadFile();
                }

                // Save Ctrl+S (char 19 represents S)
                else if (e.KeyChar == (char)19)
                {
                    this.Save();
                }

                // New Ctrl+N (char 14 represents N)
                else if (e.KeyChar == (char)14)
                {
                    this.CreateAndLoadNewFile();
                }
            }
        }

        /// <summary>
        ///  Set is pressed bool to false on key being lifted.
        /// </summary>
        /// <param name="sender">
        ///  Sender object.
        /// </param>
        /// <param name="e">
        ///  Key event args..
        /// </param>
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            // Remove isPressed lock
            this.isPressed = false;
        }
    }
}
