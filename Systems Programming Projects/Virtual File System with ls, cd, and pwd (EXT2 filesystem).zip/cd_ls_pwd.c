/************* cd_ls_pwd.c file **************/

#include "type.h"

int cd()
{

  // store path in a local buffer
  char local_path[256] = "";
  strcpy(local_path, pathname);

  // if path is empty, change to root.
  if(!strcmp(pathname, "")){
    printf("cd: Changing to root\n");
    iput(running->cwd);
    running->cwd = iget(dev,2);
    return 1;
  }
  
  // get the inode number associated with the path
  int target_ino = getino(local_path);

  // if 0, return
  if(target_ino == 0){
    printf("cd: target not found\n");
    return 0;
  }

  // find inode from number
  MINODE* local_mip = iget(dev, target_ino);

  // verify the inode is a dir type.
  if(!S_ISDIR(local_mip->INODE.i_mode)){
    printf("cd: Error, target is not of type dir\n");
    return 0;
  }

  // put the dir as the cwd
  iput(running->cwd);

  // set cwd
  running->cwd = local_mip;

  return 1;
  
}

int ls_file(MINODE *mip, char *name)
{
  // *****pulled from my own lab4client.c file*****//
  // Directory access pointers
  DIR* dir_pointer;
  struct dirent* current_dir_pointer;
  struct tm* time_information;
  char time_holder[50]="";
  char file_type = '\0';

  //locals
  INODE file_inode = mip->INODE;

  
  //print out permission data
      (S_ISDIR(file_inode.i_mode)) ? printf("d") : printf("-");
      (file_inode.i_mode & S_IRUSR) ? printf("r") : printf("-");
      (file_inode.i_mode & S_IWUSR) ? printf("w") : printf("-");
      (file_inode.i_mode & S_IXUSR) ? printf("x") : printf("-");
      (file_inode.i_mode & S_IRGRP) ? printf("r") : printf("-");
      (file_inode.i_mode & S_IWGRP) ? printf("w") : printf("-");
      (file_inode.i_mode & S_IXGRP) ? printf("x") : printf("-");
      (file_inode.i_mode & S_IROTH) ? printf("r") : printf("-");
      (file_inode.i_mode & S_IWOTH) ? printf("w") : printf("-");
      (file_inode.i_mode & S_IXOTH) ? printf("x") : printf("-");
      printf("  %5li ", file_inode.i_links_count);

  //print out group and user
      struct passwd *uid;
      struct group *gid;
      // read in uid as a formatted type and print it out.
      uid = getpwuid(file_inode.i_uid);
      printf("%s ",uid->pw_name);
      gid = getgrgid(file_inode.i_gid);
      printf("%s ",gid->gr_name);

  //print file size in bytes
      printf("%8li ", file_inode.i_size);

  //update timeinfo and print
      time_information = localtime(&(file_inode.i_mtime));
      strftime(time_holder,49,"%b %d %R",time_information);
      printf("%s ",time_holder);

  //print file name
      printf("%s\t",name);
      
  // *****end pull*****//
}

int ls_dir(MINODE *mip)
{

  printf("Executing ls -l. Begin listing directories\n");
  
  char buf[BLKSIZE], temp[256];
  DIR *dp;
  char *cp;

  // list each datablocks files
  for(int i = 0; i< 12; i++){

     get_block(dev, mip->INODE.i_block[i], buf);
     dp = (DIR *)buf;
     cp = buf;

     if(mip->INODE.i_block[i]){

       // store first entry for checking circular loop
       DIR* firstdir = dp;
       int pass1 = 0;
       
       while (cp < buf + BLKSIZE){

	 //printf("firstdir=%x\ndp=%x\ncp=%x\nbuf=%x\n",firstdir, dp, cp,buf);
	 //if(dp == firstdir && !pass1) {pass1=1;}
	 //else{return 1;}

	 strncpy(temp, dp->name, dp->name_len);
	 temp[dp->name_len] = 0;
	 
	 // list contents of each file.
	 MINODE* current_mip = iget(dev, dp->inode);
	 if(current_mip != 0){
	   ls_file(current_mip, temp);
	   
	   //print dev and inode number
	   printf("[%d %d]\n", dev, dp->inode);
	 }
	 else
	   return 1;

	 cp += dp->rec_len;
	 dp = (DIR *)cp;
       }
     }
     
    }
  
}

int ls()
{

  // storage for names
  char dir[256] = "";
  char base[256] = "";

  // store each part of path in storage names
  mydirname(pathname, dir);
  mybasename(pathname, base);

  // if both are empty, ls cwd
  if(!strcmp(dir, "") && !strcmp(base, "")){
     ls_dir(running->cwd);
     return 1;
  }

  // if dir is empty, ls base within cwd
  if(!strcmp(dir, "")){

    // search for ino within cwd
    int target_ino = search(running->cwd, base);

    // if not found print and return.
    if(target_ino == 0){
      printf("Target dir not found\n");
      return 0;
    }

    // else, ls_dir the found target
    MINODE* target_mip = iget(dev, target_ino);
    if(!S_ISDIR(target_mip->INODE.i_mode)){
      printf("ls: Error, target is not of type dir\n");
      return 0;
    }
    ls_dir(target_mip);
    return 1;
  }
    
  // if neither empty, print based on pathname
  int target_ino = getino(pathname);

  // if not found, return here;
  if(target_ino == 0){
    printf("target dir not found\n");
    return 0;
  }

  // else get minode
  MINODE* target_mip = iget(dev, target_ino);

  // if not of type dir, return
  if(!S_ISDIR(target_mip->INODE.i_mode)){
    printf("ls: Error, target is not of type dir\n");
    return 0;
  }

  printf("%d\n", S_ISDIR(target_mip->INODE.i_mode));

  // ls_dir if able
  ls_dir(target_mip);
  return 1;
  
}

char *pwd(MINODE *wd)
{
  // format text
  printf("CWD = ");
  
  // if root, print and return
  if (wd == root){
    printf("/\n");
    return;
  }

  // else, work backwards to print the different names of the parents to create the wd
  rpwd(wd);
  
}

void rpwd(MINODE* wd){

  // if root, return
  if(wd == root){
    return;
  }

  // find ino
  int myino = 0;
  int parent_ino = findino(wd, &myino);
  if(!parent_ino) {
    printf("rpwd: Inode not found\n");
    return 0;
  }

  // find name of ino within parent
  char ino_name[256] = "";
   MINODE* pip = iget(dev, parent_ino);
   if(!findmyname(pip, myino, ino_name)){
    printf("rpwd: Error finding name of ino\n");
    return 0;
  }

  // recursive call
   rpwd(pip);
  
  // print ino name
   printf("/%s", ino_name);
}



