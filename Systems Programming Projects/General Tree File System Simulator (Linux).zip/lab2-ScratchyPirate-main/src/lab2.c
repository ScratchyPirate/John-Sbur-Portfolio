//#include "lab2.h"
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>




//node struct
typedef struct node {
    char name[64];
    char type;
    struct node* childPtr, * siblingPtr, * parentPtr;
}NODE;




//made for storing tree. stores valid commands used for creation, changing directory and removal in a list.
typedef struct list_node {
    char c[16];
    char p[64];
    struct list_node* next;
}LNODE;




//list functions
//***insert into list at end. c is the command and p is the pathname or 2nd command if available
int insert_into_list(LNODE** lroot, char* c, char* p) {


    LNODE* temp = *lroot;
    LNODE* new_node = (LNODE*)malloc(sizeof(LNODE));
    new_node->c[0] = '\0';
    new_node->p[0] = '\0';
    new_node->next = NULL;
    strcpy(new_node->c, c);
    strcpy(new_node->p, p);

    if (!*lroot) {
        *lroot = new_node;
        return 1;
    }
    else {
        while (temp->next) {
            temp = temp->next;
        }
        new_node->next = NULL;
        temp->next = new_node;
        return 1;
    }


}
//***free list
int free_list(LNODE** lroot) {

    LNODE* temp = * lroot;
    
    if (!*lroot) {
        return -1;
    }

    free(temp);
    return 1;

}
//end list functions




//NOTES
//
//This general sequence checks to see if the path to the node exists and if the entered pathname is valid in many of the listed functions
/*
//******Assumes (char* pathname) is a parameter

//******split the pathname into name string array
char* name[32];
int n = 0;
n = tokenize(pathname, name);

//******if name is empty
if (n)n--;
else {
    printf("nothing entered after XXX, XXX FAILED\n");
    return -1;
}

//******checks if the pathname is valid
if (!strcmp(name[n], "/") || !strcmp(name[n], ".") || !strcmp(name[n], "..")) {
    printf("can't rmdir with %s, XXX FAILED\n", name[n]);
    return -1;
}

//******assigns start based on the type of pathname
if (pathname[0] == '/')
start = root;
else
start = cwd;

printf("check whether %s exists\n", name[n]);

//******if there is more than 2 members in name[]
if (n != 0) {
    printf("check whether ");

    char path_holder[128] = "";

    //*******adjust holder based on type of pathname
    if (pathname[0] == '/')strcat(path_holder, "/");
    if (n == 1) {
        printf("%s/", name[0]);
        strcat(path_holder, name[0]);

    }
    else {

        for (int i = 0; i < n; i++) {
            printf("%s/", name[i]);
            strcat(path_holder, name[i]);
            strcat(path_holder, "/");
        }
        path_holder[strlen(path_holder)] = '\0';

    }
    printf(" path exists\n");

    start = path2node(path_holder);

    if (start == 0) {
        printf("path not found, XXX FAILED\n");
        return -1;
    }

}
//*/




//global variables
//***tree related
NODE* root, * cwd, * start;
//***command related
char line[128];
char command[16], pathname[64];//command and pathname strings
char gpath[128];//holder of token strings
//char* name[32];//token string pointers
//char dname[64], bname[64];//dirname and basename string holders
//int n;
char* commands[] = { "mkdir","rmdir","ls","cd","pwd","creat","rm","reload","save","menu","quit",NULL };
char* parameters[] = { "pathname (to directory) or empty for root","pathname (to directory)","pathname or empty for root", "pathname or empty for root"," ", "pathname (to directory) or empty for root", "pathname (to file)", "filename","filename"," "," "," "};
//***function related (No longer used)
//int (*fptr[])(char*) = {(int(*)())mkdir,rmdir,ls,cd,pwd,creat,rm,reload,save,menu,quit};




//tokenizes a path and stores in n
int tokenize(char* pathname, char* name[]) {

    char* s;
    int n = 0;
    //strcpy(gpath, pathname);

    s = strtok(pathname, "/");   
    //n = 1;
    while (s) {
        printf("%s", s);
        name[n] = (char*)malloc(sizeof(strlen(s)+1));
        strcpy(name[n], s);
        n = n+1;
        s = strtok(0, "/");
    }
    printf("\n");
    return n;
}




//node related functions
NODE* search_child(NODE* parent, char* name)
{
    NODE* p;
    printf("search for %s in parent DIR %s\n", name, parent->name);
    p = parent->childPtr;
    if (p == 0)
        return 0;
    while (p) {
        if (strcmp(p->name, name) == 0)
            return p;
        p = p->siblingPtr;
    }
    return 0;
}
int insert_child(NODE* parent, NODE* q)
{
    NODE* p;
    printf("insert NODE %s into parent's child list\n", q->name);
    p = parent->childPtr;
    if (p == 0)
        parent->childPtr = q;
    else {
        while (p->siblingPtr)
            p = p->siblingPtr;

        p->siblingPtr = q;
    }
    q->parentPtr = parent;
    q->childPtr = 0;
    q->siblingPtr = 0;
}
NODE* path2node(char* pathname) {

    char* name[32];//token string pointers
    int n = 0;
    n = tokenize(pathname, name);

    if (!strcmp(pathname, "/") || !strcmp(pathname, ".") || !strcmp(pathname, "..")) {
        return -1;
    }
    if (pathname[0] == '/')
        start = root;
    else
        start = cwd;

    NODE* p = start;
    for (int i = 0; i < n; i++) {
        p = search_child(p, name[i]);
        if (p == 0) {
            printf("node not found\n");
            return 0;
        }
    }
    return p;
}
//end node functions




//misc functions
//***initialize the root and file system tree
void initialize()
{
    root = NULL;
    root = (NODE*)malloc(sizeof(NODE));
    strcpy(root->name, "/");
    root->parentPtr = root;
    root->siblingPtr = 0;
    root->childPtr = 0;
    root->type = 'D';
    cwd = root;
    //n = 0;
    //strcpy(name[0], "C:\ ");
    //n++;
    printf("Root initialized OK\n");
}
//***finds command related to command string entered
int findCmd(const char* command_entered) {

    int i = 0;
    while (commands[i]) {
        //command found return case, commands in order of commands[] global
        if (!strcmp(command_entered, commands[i])) return i;
        i++;
    }
    //null case return
    return -1;

}
//end misc functions




//command functions
//***mkdir. enters a pathname. makes directory is possible under pathname
int mkdir(char* pathname)
{
    NODE* p, * q;
    char* name[32];//token string pointers
    int n=0;
    char path_holder[128] = "";
    n=tokenize(pathname, name);
    if (n)n--;
    else {
        printf("nothing entered after mkdir, mkdir FAILED\n");
        return -1;
    }

    printf("mkdir: name=%s\n", name[n]);

    if (!strcmp(name[n], "/") || !strcmp(name[n], ".") || !strcmp(name[n], "..")) {
        printf("can't mkdir with %s, mkdir FAILED\n", name[n]);
        return -1;
    }
    if (pathname[0] == '/')
        start = root;
    else
        start = cwd;

    printf("check whether %s already exists\n", name[n]);
    
    if (n != 0) {
        printf("check whether ");


        if(pathname[0] == '/')strcat(path_holder,"/");
        if (n == 1) {
            printf("%s/", name[0]);
            strcat(path_holder, name[0]);

        }
        else {
            
            for (int i = 0; i < n; i++) {
                printf("%s/", name[i]);
                strcat(path_holder, name[i]);
                strcat(path_holder, "/");
            }
            path_holder[strlen(path_holder)] = '\0';
            
        }
        printf(" path exists\n");

        start = path2node(path_holder);

        if (start==0) {
            printf("path not found, mkdir FAILED\n");
            return -1;
        }
        if (start->type == 'F') {
            printf("cannot create DIRECTORY under node type FILE, mkdir FAILED");
            return -1;
        }

    }

    p = search_child(start, name[n]);
    if (p) {
        printf("name %s already exists, mkdir FAILED\n", name[n]);
        return -1;
    }
    
    printf("--------------------------------------\n");
    printf("ready to mkdir %s\n", name[n]);
    q = (NODE*)malloc(sizeof(NODE));
    q->type = 'D';
    strcpy(q->name, name[n]);
    insert_child(start, q);
    //cwd = q;
    //strcat(gpath, "/");
    //strcat(gpath, q->name);
    printf("mkdir %s OK\n", name[n]);
    printf("--------------------------------------\n");

    return 1;
}
//***rmdir. enters a pathname. removes the directory if it is empty
int rmdir(char* pathname) {

    NODE* p;
    char path_holder[128] = "";

    //This general sequence checks to see if the path to the node exists and if the entered pathname is valid
    char* name[32];//token string pointers
    int n=0;
    n=tokenize(pathname, name);
    if (n)n--;
    else {
        printf("nothing entered after rmdir, rmdir FAILED\n");
        return -1;
    }

    if (!strcmp(name[n], "/") || !strcmp(name[n], ".") || !strcmp(name[n], "..")) {
        printf("can't rmdir with %s, rmdir FAILED\n", name[n]);
        return -1;
    }
    if (pathname[0] == '/')
        start = root;
    else
        start = cwd;

    printf("check whether %s exists\n", name[n]);

    if (n != 0) {
        printf("check whether ");


        if (pathname[0] == '/')strcat(path_holder, "/");
        if (n == 1) {
            printf("%s/", name[0]);
            strcat(path_holder, name[0]);

        }
        else {

            for (int i = 0; i < n; i++) {
                printf("%s/", name[i]);
                strcat(path_holder, name[i]);
                strcat(path_holder, "/");
            }
            path_holder[strlen(path_holder)] = '\0';

        }
        printf(" path exists\n");

        start = path2node(path_holder);

        if (start == 0) {
            printf("path not found, rmdir FAILED\n");
            return -1;
        }

    }
    //

    p = search_child(start, name[n]);
    if (p == 0) {
        printf("directory not found, rmdir FAILED\n");
        return -1;
    }
    if (p->type != 'D') {
        printf("%s is not of type 'D', rmdir FAILED\n",name[n]);
        return -1;
    }
    else if (p->childPtr != NULL) {
        printf("directory contains at least 1 element, rmdir FAILED\n");
        return -1;
    }
    else {

        //changes directory to the parent if the remove target is the cwd
        if (!strcmp(p->name, cwd->name)) {
            cwd = start;
            strcpy(gpath, "/");
            for (int i = 0; i < n; i++) {
                strcat(gpath, name[i]);
                strcat(gpath, "/");
            }
            gpath[strlen(gpath)-1] = '\0';
        }
        //front case
        if (!strcmp(start->childPtr->name, name[n])) {
            NODE* temp = start->childPtr;
            start->childPtr = start->childPtr->siblingPtr;
            free(temp);
        }
        //end case
        else if(p->siblingPtr == NULL){
            start = start->childPtr; 
            NODE* temp = start->siblingPtr;
            while (temp->siblingPtr != NULL) {
                start = start->siblingPtr;
                temp = temp->siblingPtr;
            }
            free(temp);
            start->siblingPtr = NULL;

        }
        //middle case
        else {
            NODE* temp = start->childPtr->siblingPtr;
            start = start->childPtr;
            while (strcmp(temp->name, name[n])) {
                start = temp;
                temp = temp->siblingPtr;
            }
            start->siblingPtr = temp->siblingPtr;
            free(temp);

        }

    }

    printf("\nSuccessfully freed %s\n", name[n]);
    return 1;
    

}
//***ls. print cwd or pathname entered if possible
int ls(char* pathname)
{
    NODE* p;

    if (!strcmp(pathname, "")) {
        p = cwd->childPtr;
        printf("cwd contents = ");
        while (p) {
            printf("[%c %s] ", p->type, p->name);
            p = p->siblingPtr;
        }
        printf("\n");
    }
    else {

        
        char* name[32];//token string pointers
        int n = 0;
        n = tokenize(pathname, name);
        if (n)n--;

        if (!strcmp(name[n], "/") || !strcmp(name[n], ".") || !strcmp(name[n], "..")) {
            printf("can't process ls %s, ls FAILED\n", pathname);
            return -1;
        }

        //check to see if path exists
        char path_holder[128] = "";

        if (n != 0) {
            if (pathname[0] == '/')strcat(path_holder, "/");
            strcat(path_holder, name[0]);
            
            for (int i = 1; i <= n; i++){ 
                strcat(path_holder, "/");
                strcat(path_holder, name[i]);
            }
            path_holder[strlen(path_holder)] = '\0';
         
            start = path2node(path_holder);
            
        }
        else {
            start = path2node(pathname);
        }
        

        if (start == 0) {
            printf("path not found, ls FAILED\n");
            return -1;
        }

        p = start->childPtr;
        printf("%s contents = ",start->name);
        while (p) {
            printf("[%c %s] ", p->type, p->name);
            p = p->siblingPtr;
        }
        printf("\n");
    }
    
    return 1;
}
//***cd. changes to root if empty or to pathname if possible
int cd(char* pathname) {


    char* name[32];//token string pointers
    int n = 0;
    char path_holder[128] = "";
    strcpy(path_holder, pathname);
    n = tokenize(pathname, name);
    strcpy(pathname, path_holder);
    if (n)n--;
    else {
        printf("cd reset to root\n");
        strcpy(gpath,"");
        cwd = root;
        return 1;
    }

    if (!strcmp(name[n], "/") || !strcmp(name[n], ".") || !strcmp(name[n], "..")) {
        printf("can't process cd %s, cd FAILED\n", pathname);
        printf("cd reset to root\n");
        strcpy(gpath,"");
        cwd = root;
        return 1;
    }

    
    //check to see if path exists
    start = path2node(path_holder);

    if (start == 0) {
        printf("path not found, cd FAILED\n");
        return -1;
    }
    if (start->type == 'F') {
        printf("cannot change directory to node of type FILE, cd FAILED\n");
        return -1;
    }
    
    //change to director if not failed
    printf("Changed cwd to %s\n", pathname);
    if (pathname[0] == '/') {
        strcpy(gpath, "");
    }
    else if (cwd == root && pathname[0] != '/') {
        strcpy(gpath, "/");
    } 
    else {
        strcat(gpath, "/");
    }
    strcat(gpath, pathname);
    cwd = start;
    
    return 1;
}
//***print absolute pathname or root if empty
int pwd() {

    printf("C:~%s/  ", gpath);
    printf("\n");

    return 1;
}
//***same as mkdir only makes them of type FILE instead
int creat(char* pathname) {

    NODE* p, * q;
    char* name[32];//token string pointers
    int n = 0;
    char path_holder[128] = "";
    strcpy(path_holder, pathname);
    n = tokenize(pathname, name);
    strcpy(pathname, path_holder);
    strcpy(path_holder, "");
    if (n)n--;
    else {
        printf("nothing entered after creat, creat FAILED\n");
        return -1;
    }

    printf("creat: name = % s\n", name[n]);

    if (!strcmp(name[n], "/") || !strcmp(name[n], ".") || !strcmp(name[n], "..")) {
        printf("can't creat with %s, creat FAILED\n", name[n]);
        return -1;
    }
    if (pathname[0] == '/')
        start = root;
    else
        start = cwd;

    printf("check whether %s already exists\n", name[n]);

    if (n != 0) {
        printf("check whether ");


        if (pathname[0] == '/')strcat(path_holder, "/");
        if (n == 1) {
            printf("%s/", name[0]);
            strcat(path_holder, name[0]);

        }
        else {

            for (int i = 0; i < n; i++) {
                printf("%s/", name[i]);
                strcat(path_holder, name[i]);
                strcat(path_holder, "/");
            }
            path_holder[strlen(path_holder)] = '\0';

        }
        printf(" path exists\n");

        start = path2node(path_holder);

        if (start == 0) {
            printf("path not found, creat FAILED\n");
            return -1;
        }
        if (start->type == 'F') {
            printf("cannot create FILE under node type FILE, creat FAILED");
            return -1;
        }

    }

    p = search_child(start, name[n]);
    if (p) {
        printf("name %s already exists, creat FAILED\n", name[n]);
        return -1;
    }

    printf("--------------------------------------\n");
    printf("ready to creat %s\n", name[n]);
    q = (NODE*)malloc(sizeof(NODE));
    q->type = 'F';
    strcpy(q->name, name[n]);
    insert_child(start, q);
    printf("creat %s OK\n", name[n]);
    printf("--------------------------------------\n");
    return 1;

}
//***same as rmdir only with type FILE
int rm(char* pathname) {

    NODE* p;
    char path_holder[128] = "";

    //This general sequence checks to see if the path to the node exists and if the entered pathname is valid
    char* name[32];//token string pointers
    int n = 0;
    n = tokenize(pathname, name);
    if (n)n--;
    else {
        printf("nothing entered after rm, rm FAILED\n");
        return -1;
    }

    if (!strcmp(name[n], "/") || !strcmp(name[n], ".") || !strcmp(name[n], "..")) {
        printf("can't rm with %s, rm FAILED\n", name[n]);
        return -1;
    }
    if (pathname[0] == '/')
        start = root;
    else
        start = cwd;

    printf("check whether %s exists\n", name[n]);

    if (n != 0) {
        printf("check whether ");


        if (pathname[0] == '/')strcat(path_holder, "/");
        if (n == 1) {
            printf("%s/", name[0]);
            strcat(path_holder, name[0]);

        }
        else {

            for (int i = 0; i < n; i++) {
                printf("%s/", name[i]);
                strcat(path_holder, name[i]);
                strcat(path_holder, "/");
            }
            path_holder[strlen(path_holder)] = '\0';

        }
        printf(" path exists\n");

        start = path2node(path_holder);

        if (start == 0) {
            printf("path not found, rm FAILED\n");
            return -1;
        }

    }
    //

    p = search_child(start, name[n]);
    if (p == 0) {
        printf("directory not found, rm FAILED\n");
        return -1;
    }
    if (p->type != 'F') {
        printf("%s is not of type 'F', rm FAILED\n", name[n]);
        return -1;
    }
    else {

        //front case
        if (!strcmp(start->childPtr->name, name[n])) {
            NODE* temp = start->childPtr;
            start->childPtr = start->childPtr->siblingPtr;
            free(temp);
        }
        //end case
        else if (p->siblingPtr == NULL) {
            start = start->childPtr;
            NODE* temp = start->siblingPtr;
            while (temp->siblingPtr != NULL) {
                start = start->siblingPtr;
                temp = temp->siblingPtr;
            }
            free(temp);
            start->siblingPtr = NULL;

        }
        //middle case
        else {
            NODE* temp = start->childPtr->siblingPtr;
            start = start->childPtr;
            while (strcmp(temp->name, name[n])) {
                start = temp;
                temp = temp->siblingPtr;
            }
            start->siblingPtr = temp->siblingPtr;
            free(temp);

        }

    }

    printf("\nSuccessfully freed %s\n", name[n]);


    return 1;

}
//***reloads tree from a file if the file exists (assumes target file is valid for reloading if it opens)
int reload(LNODE** lroot, char* file_name) {

    //storage variables used for storing commands and pathnames
    char p_holder[64] = "";
    char c_holder[16] = "";
    int option = 0;
    int successful_command = 0;

    //return if read file won't open
    FILE* read_file = fopen(file_name, "r");
    if (!read_file) {
        printf("file requested does not exist in this program's field of view, reload FAILED\n");
        return -1;
    }


    //***continuing from here ASSUMES OPENNED FILE IS IN THE VALID FORMAT FOR GENERAL TREE READING. IF NOT THE CODE WILL CATCH AND EXIT COMPLETELY, DELETING CURRENT TREE AND LIST


    //***delete current tree if not empty and reinitialize root
    if (root) {
        free(root);
    }
    initialize();
    printf("Successfully freed current tree\n");


    //***delete current lroot if not empty and reinitialize.
    if (*lroot) {
        free(*lroot);
        *lroot = NULL;
    }


    //loop through file until empty and repopulate tree and lroot
    while (!feof(read_file)) {

        fscanf(read_file, "%s", c_holder);
        fscanf(read_file, "%s", p_holder);

        //debug
        printf("\nDEBUG\n**********\n%s %s\n**********\n", c_holder, p_holder);

        //if place holder is read from the file, store blank string in p_holder
        if (strcmp(p_holder, "_default") == 0)strcpy(p_holder, "");

        //find command corresponding to read string
        option = findCmd(c_holder);

        //reset successful function completion variable
        successful_command = 0;


        //run command based on command read from string
        switch (option) {

        case 0:
            //mkdir
            successful_command = mkdir(p_holder);
            break;
        case 1:
            //rmdir
            successful_command = rmdir(p_holder);
            break;
        case 3:
            //cd
            successful_command = cd(p_holder);
            break;
        case 5:
            //creat
            successful_command = creat(p_holder);
            break;
        case 6:
            //rm
            successful_command = rm(p_holder);
            break;       
        default:
            printf("ERROR: tokens read from file not recognized: %s %s\n", c_holder, p_holder);
        }
        //end switch


        //enter command into list if successful
        if (successful_command == 1) {

            //printf("DEBUG: Entering %s %s\n", c_holder, p_holder);
            insert_into_list(lroot, c_holder, p_holder);

        }
        else {

            //if any operation is unsuccessful, exits code as list is no longer recoverable by code
            printf("ERROR: reload failed to load tokens (%s %s) into tree, reload FAILED\n", c_holder, p_holder);
            printf("Tree list no longer recoverable. Continuing operations risks failure of different commands. EXITING PROGRAM\n");
            exit(0);
        }

    }


    //close file
    fclose(read_file);

    //clear screen
    system("cls");

    //reset cwd to root
    cwd = root;
    strcpy(gpath, "");

    //affirm to user operations were successful
    printf("Successfully reloaded tree");

    return 1;
}
//***saves tree if tree is populated
int save(LNODE* lroot, char* file_name) {

    //return if tree is empty and nothing has been stored
    if (!lroot) {
        printf("tree is empty, save FAILED\n");
        return -1;
    }

    FILE* store_file = fopen(file_name,"w");
    //if file is invalid, default to Starting_tree_file.txt
    if (!store_file) {
        printf("filename not recognized, defaulting to (Starting_tree_file.txt)\n");
        store_file = fopen("Starting_tree_file.txt", "w");

        //if file still isn't openned, return
        if (!store_file) {
            printf("ERROR: default file not openned, save FAILED\n");
            return -1;
        }
    }


    //storage variables used for storing commands and pathnames
    LNODE* lroot_holder = lroot;
    char p_holder[64] = "";
    char c_holder[16] = "";


    //print each list node's contents in order to file
    while (lroot_holder) {

        strcpy(p_holder, lroot_holder->p);
        strcpy(c_holder, lroot_holder->c);

        //used for formatting, if p is empty, store _default so that there is always a second string. this way reload works as intended
        if (strcmp(p_holder, "") == 0) strcpy(p_holder, "_default");

        fprintf(store_file,"%s %s", c_holder, p_holder);
        printf("DEBUG: %s %s\n", c_holder, p_holder);

        //add new line marker on all lines except last for file formatting
        if (lroot_holder->next) {
            fprintf(store_file, "\n");
        }

        lroot_holder = lroot_holder->next;

    }
    

    //close file after use
    printf("Successfully saved tree in file\n");
    fclose(store_file);

    return 1;
}
//***display all commands
int menu() {

    int i = 0;
    printf("Available commands:\n");
    while (commands[i]) {
        printf("\t%s \t%s\n",commands[i], parameters[i]);
        i++;
    }
    printf("\n");
    return 1;

}
//***exits and stores tree in default file
int quit(LNODE* lroot)
{

    save(lroot, "Starting_tree_file.txt");
    system("cls");
    printf("Program exit\n");


    exit(0);

    // improve quit() to SAVE the current tree as a Linux file
    // for reload the file to reconstruct the original tree
}
//end command functions




int main(int argc, char* argv[], char* env[]){


  //start up root of tree
  initialize();

  //general local variables
  int option = 0;
  int running = 1;
  char path_holder[64] = "";
  char command_holder[16] = "";
  int successful_command = 0;

  //file related variables
  LNODE* file_list_root = NULL;
  char file_name[64];
  char default_file[64] = "Starting_tree_file.txt";



  //continue until quit is entered (quit should automatically exit, but in case it doesn't, the quit case should set running to false and exit)
  while(running){


    //reset strings after each loop
    strcpy(command, "");
    strcpy(pathname, "");
    strcpy(command_holder, "");
    strcpy(path_holder, "");
  
    //get user data. kill \n from fgets. parse and put command and path into respective globals
    printf("C:~%s/  ", gpath);
    fgets(line,128,stdin);
    line[strlen(line)-1] = 0;
    sscanf(line,"%s %s", command, pathname);

    //reset line
    line[0] = '\0';

    //storage variables used for storing the file tree
    strcpy(command_holder, command);
    strcpy(path_holder, pathname);

    //assign command to option
    option = findCmd(command);

    printf("\n");
    successful_command = 0;

    //run command based on command entered  
    switch(option){

    case 0:
        //mkdir
        successful_command = mkdir(pathname);
        break;

    case 1:
        //rmdir
        successful_command = rmdir(pathname);
        break;

    case 2:
        //ls
        ls(pathname);
        break;

    case 3:
        //cd
        successful_command = cd(pathname);
        break;

    case 4:
        //pwd
        pwd();
        break;

    case 5:
        //creat
        successful_command = creat(pathname);
        break;

    case 6:
        //rm
        successful_command = rm(pathname);
        break;

    case 7:
        //reload
        strcpy(file_name, pathname);
        reload(&file_list_root,file_name);
        break;

    case 8:
        //save
        strcpy(file_name, pathname);
        (!file_list_root) ? printf("Tree empty, save FAILED\n") : save(file_list_root,file_name);
        break;

    case 9:
        //menu
        menu();
        break;

    case 10:
        //quit
        quit(file_list_root);
        running = 0;
        break;

    default:
        printf("\nCommand '%s' not recognized\n", line);
        break;

    }
    //end switch

    //if a command related to editing or traversing the tree was successful, store it in the list 
    //the list can be used later to store and rebuild the tree
    if (successful_command == 1) {

        insert_into_list(&file_list_root, command_holder, path_holder);

    }

    //system("pause");
    printf("\n");
    
  }
  //end while

}
//end main
