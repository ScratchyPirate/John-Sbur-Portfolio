

//No longer used
// //int* mkdir(NODE** target_root){
//
//  //general variables
//  NODE* new_node;
//  NODE* traversal_node;
//  char file_name_holder[64];
//  char* n_holder[] = name;
//  int pathname_count = 0;
//  int c = 0;
//  int found = 0;
//
//  //find number of / to know how many times to search
//  int slash_count = 0;
//  for(int i = 0;pathname[i]!='\0';i++){if(pathname[i]==(char)47)slash_count++;};
//  
//  
//  //absolute case
//  if(pathname[0] == (char)47){
//
//    traversal_node =   (*target_root)->childPtr;
//    pathname_count = 1;
//    while(slash_count > 1){
//
//      //copy file name up to slash into holder
//      for(c = 0;pathname[pathname_count]!= (char)47;pathname_count++){
//	file_name_holder[c]=pathname[pathname_count];
//	c++;
//      }
//      file_name_holder[c] = '\0';
//
//      //loop through siblings for file name. if found continue traversing. if not, end
//      found=0;
//      while(!found&&traversal_node!=NULL){
//
//      }
//      if(found==0){
//	  printf("\nfile path not found\n");
//      name = n_holder;
//	  return 0;
//      }
//      else{
//	printf("%s\ ",file_name_holder);
//      }
//
//      
//      slash_count--;
//      
//
//    }
//
//    if(traversal_node){
//      //directories already existing case
//       while(traversal_node->siblingPtr){
//         traversal_node = traversal_node->siblingPtr;
//       }
//      traversal_node->siblingPtr = (NODE*)malloc(sizeof(NODE));
//      strcpy(traversal_node->siblingPtr->name,file_name_holder);
//      traversal_node->siblingPtr->type ='D';
//      traversal_node->siblingPtr->parentPtr=0;
//      traversal_node->siblingPtr->childPtr = NULL;
//      traversal_node->siblingPtr->siblingPtr=NULL;
//      //set cwd after making it there
//      strcpy(cwd,file_name_holder);
//      strcpy(gpath,pathname);
//    
//    }
//    else{
//      //no directories underneath case
//      traversal_node = (NODE*)malloc(sizeof(NODE));
//      strcpy(traversal_node->siblingPtr->name,file_name_holder);
//      traversal_node->siblingPtr->type = 'D';
//      traversal_node->siblingPtr->parentPtr=0;
//      traversal_node->siblingPtr->childPtr = 0;
//      traversal_node->siblingPtr->siblingPtr=0;
//      //set cwd after making it there
//      strcpy(cwd,traversal_node->siblingPtr->name);
//      strcpy(gpath,pathname);
//      
//    }
//
//    printf("%s\n",traversal_node->siblingPtr->name);
//    return traversal_node->siblingPtr;
//    
//
//  }
//  //relative case
//  else{
//
//    traversal_node = (*target_root)->childPtr;
//    while (slash_count > 0){
//    //copy file name up to slash into holder
//    for (c = 0; pathname[pathname_count] != (char)47; pathname_count++) {
//        file_name_holder[c] = pathname[pathname_count];
//        c++;
//    }
//    file_name_holder[c] = '\0';
//
//    //loop through siblings for file name. if found continue traversing. if not, end
//    found = 0;
//    while (!found && traversal_node != NULL) {
//
//    }
//    if (found == 0) {
//        printf("\nfile path not found\n");
//        return 0;
//    }
//    else {
//        printf("%s\ ", file_name_holder);
//    }
//
//
//    slash_count--;
//
//
//  }
//
//  if (traversal_node) {
//      //directories already existing case
//      while (traversal_node->siblingPtr) {
//          traversal_node = traversal_node->siblingPtr;
//      }
//      traversal_node->siblingPtr = (NODE*)malloc(sizeof(NODE));
//      strcpy(traversal_node->siblingPtr->name, file_name_holder);
//      traversal_node->siblingPtr->type = 'D';
//      traversal_node->siblingPtr->parentPtr = 0;
//      traversal_node->siblingPtr->childPtr = NULL;
//      traversal_node->siblingPtr->siblingPtr = NULL;
//      //set cwd after making it there
//      strcpy(cwd, file_name_holder);
//      strcpy(gpath, pathname);
//
//  }
//  else {
//      //no directories underneath case
//      traversal_node = (NODE*)malloc(sizeof(NODE));
//      strcpy(traversal_node->siblingPtr->name, file_name_holder);
//      traversal_node->siblingPtr->type = 'D';
//      traversal_node->siblingPtr->parentPtr = 0;
//      traversal_node->siblingPtr->childPtr = 0;
//      traversal_node->siblingPtr->siblingPtr = 0;
//      //set cwd after making it there
//      strcpy(cwd, traversal_node->siblingPtr->name);
//      strcpy(gpath, pathname);
//
//  }
//
//  printf("%s\n", traversal_node->siblingPtr->name);
//  return traversal_node->siblingPtr;
//
//
//
//  }
//  
//
//}
//node functions (type 1 = front, 2 = target(inserts as sibling), 3 = end, 4 = sibling linked list) target_name = NULL if not type 2
/*NODE* insert_helper(NODE** root, char* node_name, char node_type, NODE* node_child_ptr, NODE* node_sibling_ptr, NODE* node_parent_ptr, int insert_type, const char* target_name){

  //create and initialize new node with entered attributes
  NODE* new_node = (NODE*)malloc(sizeof(NODE));
  strcpy(new_node->name,node_name);
  new_node->type = node_type;
  new_node->childPtr = node_child_ptr;
  new_node->siblingPtr = node_sibling_ptr;
  new_node->parentPtr = node_parent_ptr;

  //insert node
  return insert(root,new_node,insert_type,target_name);

  
}
void recursive_insert_at_location(NODE** root, NODE* insert_node, const char* target_name){

  if(!*root){

    if(!strcmp((*root)->name,target_name)){
      insert(root,insert_node,4,target_name);
      return;
    }
    //check children for target
    NODE** child = &((*root)->childPtr);
    recursive_insert_at_location(child, insert_node, target_name);
    //check siblings on level of root for target
    NODE** sibling = &((*root)->siblingPtr);
    recursive_insert_at_location(sibling ,insert_node,target_name);   
    
  }
  else{
    return;
  }
  return;
  
}
NODE* insert(NODE** root, NODE* insert_node, int insert_type, const char* target_name){

  
  switch(insert_type){

  case 1:

    //insert at front
    if(!(*root)){
      insert_node->childPtr = *root;
      (*root)->parentPtr = insert_node;
      (*root) = insert_node;      
    }
    else{
      *root=insert_node;
    }
    break;

  case 2:

    //insert at location
    if(root){
       NODE**current_root = root;
       (*current_root)=(*root)->childPtr;
       //check siblings at level
       if(*current_root){
	 recursive_insert_at_location(root,insert_node,target_name);	  
       }
       else{
	 *current_root=insert_node;
       }
    }
    else{
      *root = insert_node;
    }
    
    
    
    break;

  case 3:

    //insert at end
    NODE**current_root = root;
    if(current_root){
      while((*current_root)->childPtr){
	*current_root = (*current_root)->childPtr;
       }
      (*current_root)->childPtr = insert_node;
      insert_node->parentPtr = *current_root;
    }
    else{
      *root = insert_node;
    }  	      
    break;

  case 4:

    //insert in siblings at end of sibling linked list
    NODE**sibling_root = root;
    while((*sibling_root)->siblingPtr){
      (*sibling_root)->siblingPtr = (*sibling_root)->siblingPtr->siblingPtr;
    }
    (*sibling_root)->siblingPtr = insert_node;
    insert_node->parentPtr = (*sibling_root)->parentPtr;

  }

   return insert_node;
}
//prints all members by level, if they are on the same level, they will have the same number
void print_all(NODE* root, int number){

  if(!root)return;

  printf("%d %s\n",number,root->name);
  print_all(root->siblingPtr,number);
  print_all(root->childPtr,number+1);
  
  return;
  
}
*/
