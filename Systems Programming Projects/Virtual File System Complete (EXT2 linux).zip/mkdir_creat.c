/************* mkdir_creat.c file **************/
#include "type.h"


// description: Using the local variable "pathname", this function tries to make a directory within an inputted directory or the cwd.
// returns: 0 when unsuccessful
//          1 when successful
int mymkdir(char* pathname){

    // 1) Separate basename and dirname
    // storage for names and other locals
    char dir[256] = "";
    char base[256] = "";
    int pino = 0;
    MINODE* pmip = NULL;

    // store each part of path in storage names
    mydirname(pathname, dir);
    mybasename(pathname, base);

    printf("dir:%s\tbase:%s\n", dir, base);

    // Different cases
    // Case 0, base is empty, immediately return
    if(!strcmp(base, "")){
        printf("mkdir: Base is empty!\n");
        return 0;
    }
    // Case 1, dir is empty (Use running cwd)
    if(!strcmp(dir, "")){
        pmip = iget(running->cwd->dev, running->cwd->ino);
        pino = pmip->ino;
    }
    // Case 2, dir is not empty, (use path)
    else{
        pino = getino(dir);

        if (pino == 0){
            printf("mkdir: Insertion directory not found\n");
            return 0;
        }

        pmip = iget(getino_dev, pino);
    }

    // 2) Verify existence of directory
    //  Make sure the inode is a directory. If not, exit.
    if(!is_dir(pmip)){
        printf("mkdir: Path %s is not a directory\n", dir);
        iput(pmip);
        return 0;
    }

    // 3) Make sure the basename doesn't exist within the directory. If it does. Return 0;
    if(search(pmip, base)){
        printf("mkdir: Basename %s exists within target directory\n", base);
        iput(pmip);
        return 0;
    }

    // 3.5) Verify user permissions
    if ((!access(pmip, 'r') || !access(pmip, 'w')) || !access(pmip, 'x')){
        printf("mkdir: Current user '%d' doesn't have permission to create directories in '%s'\n", running->uid, dir);
        iput(pmip);
        return 0;
    }

    // 4) kmkdir() call
    update_globals(pmip->dev);
    mykmkdir(pmip, base);
    
    // Increment number of links parent has
    pmip->INODE.i_links_count++;
    pmip->INODE.i_atime = time(0L);
    pmip->dirty = 1;

    // Put the parent with updated information back onto the disk.
    iput(pmip);
    //printf("mkdir: Stored parent inode on disk.\n");

    update_globals(running->cwd->dev);

    // Return when done
    return 1;
}

// description: kernel make directory function. Allocates and initializes a directory inode.
int mykmkdir(MINODE* pmip, char* base){

    // 1) Allocate inode and block data for new directory
    int ino = ialloc(pmip->dev);
    int blk = balloc(pmip->dev);

    // Verify the data was allocated
    if(ino == 0 || blk == 0){
        printf("kmkdir: Data unsuccessfully allocated for new directory\n");
        return 0;
    }

    // 2) Load new inode into memory and initialize the inode.
    // Load into memory
    MINODE* mip = iget(pmip->dev, ino);

    // Verify it was loaded
    if(mip == 0){
        printf("kmkdir: No more memory inode can be allocated\n");
        iput(mip);
        return 0;
    }
    else{
        //printf("kmkdir: Memory inode allocated for new dir\n");
    }

    // Set i_mode as directory with user read, write, exec, group read, exec, and other read, exec.
    mip->INODE.i_mode = 0x41ED;

    // Set first block as the newly allocated block and others as 0.
    //printf("kmkdir: Setting new inode data\n");
    mip->INODE.i_block[0] = blk;
    for(int i = 1; i < 15; i++){
        mip->INODE.i_block[i] = 0;
    }

    // Create rest of the entries in new inode.
    mip->INODE.i_uid = running->uid;
    mip->INODE.i_gid = running->gid;
    mip->INODE.i_size = BLKSIZE;
    mip->INODE.i_links_count = 2;
    mip->INODE.i_atime = mip->INODE.i_ctime = mip->INODE.i_mtime = time(0L);
    mip->INODE.i_blocks = 2;
    //printf("kmkdir: Set new inode data\n");

    // Mark as modified
    mip->dirty = 1;
    mip->refCount = 0;

    // put new inode on disk
    iput(mip);
    //printf("kmkdir: Stored new inode in disk.\n");

    // 3) Add '.' and '..' entries into data block
    char local_buf[BLKSIZE];
    mybzero(local_buf);
    DIR* new_entry = (DIR*)local_buf;
    // '.'
    new_entry->inode = ino;
    new_entry->rec_len = 20;
    new_entry->name_len = 1;
    new_entry->name[0] = '.';
    new_entry->name[1] = 0;
    print_dir(local_buf, new_entry);
    // '..'
    new_entry = (char*)new_entry+20;
    new_entry->inode = pmip->ino;
    new_entry->rec_len = BLKSIZE-20;
    new_entry->name_len = 2;
    new_entry->name[0] = '.';
    new_entry->name[1] = '.';
    new_entry->name[2] = 0;
    print_dir(local_buf, new_entry);

    //printf("kmkdir: Entered parent and child inodes in new inode's first data block.\n");

    // Store the new block onto the filesystem.
    put_block(pmip->dev, blk, local_buf);
    //printf("kmkdir: Stored new inode's first data block.\n");

    // 4) Enter the new directory as a dir_entry in the parent.
    enter_child(pmip, ino, base);

    // Return when complete.
    return 1;
}

// description: given a memory inode, this function enters the inode given as a directory entry for the parent with name "base"
int enter_child(MINODE* pmip, int ino, char* base){

    //printf("enter_child: Entering child name %s in parent dir\n", base);

    // Look for next empty directory block
    int available_block = 0;
    for(int  i = 0; i < 12; i++){
        if(pmip->INODE.i_block[i] == 0){
            available_block = i - 1;
            i = 12;
        }
    }

    // Get parent's data block into local buf
    char local_buf[BLKSIZE];
    mybzero(local_buf);
    get_block(pmip->dev, pmip->INODE.i_block[available_block], local_buf);

    // Look for spot to put new entry in. Step to last entry.
    DIR* dp = local_buf;
    char* cp = dp;
    while(cp + dp->rec_len < local_buf + BLKSIZE){
        cp+=dp->rec_len;
        dp=(DIR*)cp;
    }

    // Get remainder of space left in block;
    int ideal_length = (4*((8+dp->name_len+3)/4));
    int remain = dp->rec_len - ideal_length;
    int need_length = 4*(8+strlen(base)+3)/4;

    // If there is space available, enter the new directory in the data block and put the data block back into the file system.
    // If there isn't space available, go to the next unalllocated i_block and allocate it. Then set pmip's data block to be the allocated
    // block and enter the directory there.
    // Return 1 when complete.
    if(remain >= need_length){

        //printf("enter_child: Space available in existing parent data block, entering child dir entry there.\n");

        // Adjust rec_len of previous entry to be the ideal length.
        dp->rec_len = ideal_length;

        // Move to new area and set dir
        cp += dp->rec_len;
        dp = (DIR*)cp;
        dp->inode = ino;
        dp->name_len = strlen(base);
        dp->rec_len = remain;
        dp->name[0] = '\0';
        strncpy(dp->name, base, strlen(base));

        // Put the updated block back into the system.
        put_block(pmip->dev, pmip->INODE.i_block[available_block], local_buf);

        //printf("enter_child: Entered child in parent\n");
    }
    else {

        //printf("enter_child: Space unavailable in existing parent data block, creating new data block in parent.\n");

        // Increment the size of inode to show a new data block is allocated.
        pmip->INODE.i_size += BLKSIZE;

        // If there aren't any more blocks available, return and print failure.
        if(available_block+1 >= 12){
            printf("enter_child: Parent cannot allocate more blocks\n");
            return 0;
        }

        // Set new block to allocated block
        pmip->INODE.i_block[available_block+1] = balloc(pmip->dev);

        // If unsuccessfully allocated, return 0;
        if(!pmip->INODE.i_block[available_block+1]){
            printf("enter_child: No more data blocks can be allocated\n");
            return 0;
        }

        // Clear out the local buffer;
        mybzero(local_buf);  

        // Set first entry for local_buf to the new dir_entry      
        dp = (DIR*)local_buf;

        // Set dir_entry information.
        dp->inode = ino;
        dp->name_len = strlen(base);
        dp->rec_len = BLKSIZE;
        dp->name[0] = '\0';
        strcpy(dp->name, base);
        dp->name[strlen(base)]=0;
        put_block(pmip->dev, pmip->INODE.i_block[available_block+1], local_buf);

        //printf("enter_child: Entered child in parent\n");
    }

    // Return when complete
    return 1;
}

// description: Using the local variable "pathname", this function tries to make a regular file within an inputted directory or the cwd.
// returns: 1 when successful
//          0 when unsuccessful
int mycreat(char* pathname){
    
    // 1) Separate basename and dirname
    // storage for names and other locals
    char dir[256] = "";
    char base[256] = "";
    int pino = 0;
    MINODE* pmip = NULL;

    // store each part of path in storage names
    mydirname(pathname, dir);
    mybasename(pathname, base);

    printf("dir:%s\tbase:%s\n", dir, base);

    // Different cases
    // Case 0, base is empty, immediately return
    if(!strcmp(base, "")){
        printf("creat: Base is empty!\n");
        return 0;
    }
    // Case 1, dir is empty (Use running cwd)
    if(!strcmp(dir, "")){
        pmip = iget(running->cwd->dev, running->cwd->ino);
        pino = pmip->ino;
    }
    // Case 2, dir is not empty, (use path)
    else{
        pino = getino(dir);
        pmip = iget(getino_dev, pino);
    }

    // 2) Verify existence of directory
    //  Make sure the inode is a directory. If not, exit.
    if(!is_dir(pmip)){
        printf("creat: Path %s is not a directory\n", dir);
        iput(pmip);
        return 0;
    }

    // 3) Make sure the basename doesn't exist within the directory. If it does. Return 0;
    if(search(pmip, base)){
        printf("creat: Basename %s exists within target directory\n", base);
        iput(pmip);
        return 0;
    }

    // 3.5) Verify the user has permission to rwx parent. If they don't, return
    if ((!access(pmip, 'r') || !access(pmip, 'w')) || !access(pmip, 'x')){
        printf("creat: Current user '%d' doesn't have permission to create directories in '%s'\n", running->uid, dir);
        iput(pmip);
        return 0;
    }

    // 4) kcreat
    update_globals(pmip->dev);
    mykcreat(pmip, base);
    update_globals(running->cwd->dev);

    // Mark parent as dirty and store it back
    pmip->INODE.i_atime = time(0L);
    pmip->dirty = 1;
    iput(pmip);

    // Return when done
    return 1;
}

// description: kernel make file function (creat). Allocates and initializes a regular file inode.
int mykcreat(MINODE* pmip, char* base){
    
    // 1) Allocate inode and block data for new directory
    int ino = ialloc(pmip->dev);

    // Verify the data was allocated
    if(ino == 0){
        printf("kcreat: Data unsuccessfully allocated for new file\n");
        return 0;
    }

    // 2) Load new inode into memory and initialize the inode.
    // Load into memory
    MINODE* mip = iget(pmip->dev, ino);

    // Verify it was loaded
    if(mip == 0){
        printf("kmkdir: No more memory inode can be allocated\n");
        iput(mip);
        return 0;
    }
    else{
        //printf("kmkdir: Memory inode allocated for new dir\n");
    }

    // Set i_mode as regular file with rw-r--r-- as permission bits and make it a regular file
    mip->INODE.i_mode = S_IFREG;
    mip->INODE.i_mode |= 0644;


    // Set each data block as empty
    for(int i = 1; i < 15; i++){
        mip->INODE.i_block[i] = 0;
    }

    // Create rest of the entries in new inode.
    mip->INODE.i_uid = running->uid;
    mip->INODE.i_gid = running->gid;
    mip->INODE.i_size = 0;
    mip->INODE.i_links_count = 1;
    mip->INODE.i_atime = mip->INODE.i_ctime = mip->INODE.i_mtime = time(0L);
    mip->INODE.i_blocks = 2;
    //printf("kmkdir: Set new inode data\n");

    // Mark as modified
    mip->dirty = 1;
    mip->refCount = 0;

    // put new inode on disk
    iput(mip);

    // 4) Enter the new file as a dir_entry in the parent.
    enter_child(pmip, ino, base);

    // Return when complete.
    return 1;
}
