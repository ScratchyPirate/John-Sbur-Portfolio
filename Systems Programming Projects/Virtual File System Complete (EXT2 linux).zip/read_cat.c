/************* read_cat.c file **************/
#include "type.h"

// description: Given a file descriptor, buffer, and the amount of bytes to read, this function reads from a file opened for read the amount of bytes 
//  requested into the buffer. Assumes buffer can hold nbytes.
// returns: Number of bytes read (anywhere from nbytes to 0 depending on how many bytes are in the file)
//          0 if unsuccessful as well.
int myread(char* fd_string, char* local_buf, char* nbytes_string){
    
    // Locals
    char* cp, cp2;
    char local_buf2[BLKSIZE], local_buf3[BLKSIZE];
    int* buf_pointer;
    int remain = 0, bytes_read = 0, byte_offset = 0, available_bytes = 0, nbytes = 0, target_fd = 0, lbk = 0, start = 0, local_blk = 0, indirect_blk = 0, indirect_offset = 0;

    // Try to convert fd_string into an integer. If unsuccessful, return
    target_fd = ToUInt(fd_string);
    if(target_fd == -1){
        printf("read: Invalid fd token\n");
        return 0;
    }

    // Try to convert nbytes_string into an integer. If unsuccessful, return
    nbytes = ToUInt(nbytes_string);
    if(nbytes == -1){
        printf("read: Invalid nbytes token\n");
        return 0;
    }

    // Check to see if the fd is openned for read in the current running proc. If not, return
    if(running->fd[target_fd] == 0){
        printf("read: FD requested not open\n");
        return 0;
    }
    if(running->fd[target_fd]->mode != 0 && running->fd[target_fd]->mode != 2){
        printf("read: FD not openned for a readable mode\n");
        return 0;
    }

    // Initialize local variables for reading
    bytes_read = 0;
    byte_offset = running->fd[target_fd]->offset;
    available_bytes = running->fd[target_fd]->minodePtr->INODE.i_size - byte_offset;

    // Start reading bytes one at a time
    while(nbytes > 0 && available_bytes > 0){

        // Compute block to pull from for reading as well as starting byte
        lbk = byte_offset / BLKSIZE;
        start = byte_offset % BLKSIZE;

        // Convert logic block into the actual block we need to pull from within the minode
        // Direct block
        if(lbk < 12){
            local_blk = running->fd[target_fd]->minodePtr->INODE.i_block[lbk];
        }
        // Indirect block
        else if(12 <= lbk && lbk < 12+256){

            // Get single indirect block
            get_block(running->cwd->dev, running->fd[target_fd]->minodePtr->INODE.i_block[12], local_buf3);
            buf_pointer = (int*)local_buf3;

            // Set local block to the correct block within the indirect block.
            local_blk = buf_pointer[lbk-12];
        }
        // Double indirect block
        else{
            // Get double indirect block
            get_block(running->cwd->dev, running->fd[target_fd]->minodePtr->INODE.i_block[13], local_buf3);
            
            // Get the indirect block
            indirect_blk = (lbk - 256 - 12) / 256;
            indirect_offset = (lbk - 256 - 12) % 256;

            // Now that we have the indirect block number, find the block within the indirect block
            buf_pointer = (int *)local_buf3 + indirect_blk;
            get_block(running->cwd->dev, *buf_pointer, local_buf3);
            buf_pointer = (int *)local_buf3 + indirect_offset;
            local_blk = *buf_pointer;
        }

        // If the block is empty, return
        if (local_blk == 0){
            //printf("read: End of minode data blocks encountered\n");
            return bytes_read;
        }

        // Continue to get the block and read
        get_block(running->cwd->dev, local_blk, local_buf2);
        cp = local_buf2 + start;
        remain = BLKSIZE - start;

        // Copy bytes to target buf
        while(remain){

            // If we reach the end of file marker, stop
            if(*cp == -1){
                available_bytes=0;
                break;
            }

            // Copy over byte
            *local_buf = *cp;
            
            // increment buf, cp, offset, and count
            local_buf++;
            cp++;
            running->fd[target_fd]->offset++;
            byte_offset++;
            bytes_read++;

            // decrease remain, available_bytes, and number of bytes read
            remain--;
            available_bytes--;
            nbytes--;

            // If we have read all the bytes asked or if we are at the end of the block, break from this loop
            if(nbytes == 0 || available_bytes == 0)
                break;
        }
    }

    // Return number of bytes read
    return bytes_read;
}

// description: Given a file path, this function opens a the file associated with it for read if able and puts its contents on the screen.
int mycat(char* filepath){

    // Open the specified file, if it can't be openned, return
    int local_fd = myopen(filepath, "RD");
    if(local_fd == -1){
        printf("cat: Failed to open specified file\n");
        return 0;
    }

    // While we haven't read all bytes from the specified file, continue to read
    int bytes_read = 0;
    int total_bytes_read = 0;
    int eof = 0;
    char local_buf2[BLKSIZE];
    char holder[64] = "";
    char holder2[64] = "";
    sprintf(holder2, "%d", BLKSIZE);
    sprintf(holder, "%d", local_fd);
    while(!eof){

        // Read data into local_buf2
        mybzero(local_buf2);
        bytes_read = myread(holder, local_buf2, holder2);
        total_bytes_read+= bytes_read;

        // If bytes_read == 0, stop printing.
        if(bytes_read == 0){
            eof = 1;
        }
        else{
            // Print each byte in local_buf2
            for(int i = 0; i < bytes_read; i++){
                printf("%c", local_buf2[i]);
            }
        }
    }

    printf("\n****End of file concatenation****\n****total bytes read:%8d****\n", total_bytes_read);

    // Close the file and return when done.
    myclosefd(holder);
    return 1;

}
