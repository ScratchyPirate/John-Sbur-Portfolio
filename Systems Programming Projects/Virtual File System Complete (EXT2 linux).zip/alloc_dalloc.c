/************* alloc_dalloc.c file **************/

#include "type.h"


// description: decreases the number of free inodes count in SUPER and GD by 1
// returns: 1 when complete.
int decFreeInodes(int dev){

  // local buffer
  char local_buf[BLKSIZE];

  // decrease the number of free inodes count in SUPER and GD by 1
  // SUPER
  get_block(dev, 1, local_buf);
  sp = (SUPER*)local_buf;
  sp->s_free_inodes_count--;
  put_block(dev, 1, local_buf);
  local_buf[0] = 0;

  // GD
  get_block(dev, 2, local_buf);
  gp = (GD*)local_buf;
  gp->bg_free_inodes_count--;
  put_block(dev, 2, local_buf);
  local_buf[0] = 0;

  return 1;
}

// description: increases the number of free inodes count in SUPER and GD by 1
// returns: 1 when complete.
int incFreeInodes(int dev){

  // local buffer
  char local_buf[BLKSIZE];

  // increase the number of free inodes count in SUPER and GD by 1
  // SUPER
  get_block(dev, 1, local_buf);
  sp = (SUPER*)local_buf;
  sp->s_free_inodes_count++;
  put_block(dev, 1, local_buf);
  local_buf[0] = 0;

  // GD
  get_block(dev, 2, local_buf);
  gp = (GD*)local_buf;
  gp->bg_free_inodes_count++;
  put_block(dev, 2, local_buf);
  local_buf[0] = 0;

  return 1;
}

// description: decreases the number of free blocks count in SUPER and GD by 1
// returns: 1 when complete.
int decFreeBlocks(int dev){

  // local buffer
  char local_buf[BLKSIZE];

  // decrease the number of free inodes count in SUPER and GD by 1
  // SUPER
  get_block(dev, 1, local_buf);
  sp = (SUPER*)local_buf;
  sp->s_free_blocks_count--;
  put_block(dev, 1, local_buf);
  local_buf[0] = 0;

  // GD
  get_block(dev, 2, local_buf);
  gp = (GD*)local_buf;
  gp->bg_free_blocks_count--;
  put_block(dev, 2, local_buf);
  local_buf[0] = 0;

  return 1;
}

// description: increases the number of free blocks count in SUPER and GD by 1
// returns: 1 when complete.
int incFreeBlocks(int dev){

  // local buffer
  char local_buf[BLKSIZE];

  // decrease the number of free inodes count in SUPER and GD by 1
  // SUPER
  get_block(dev, 1, local_buf);
  sp = (SUPER*)local_buf;
  sp->s_free_blocks_count++;
  put_block(dev, 1, local_buf);
  local_buf[0] = 0;

  // GD
  get_block(dev, 2, local_buf);
  gp = (GD*)local_buf;
  gp->bg_free_blocks_count++;
  put_block(dev, 2, local_buf);
  local_buf[0] = 0;

  return 1;
}

// description: allocates an inode number based on available inodes in the inode bitmap global.
// returns: inode number if successful.
//          0 if unsuccessful.
// --if imap isn't assigned to the inode_bit map in the ext2 filesystem and/or the dev inputted isn't a file descriptor of an ext2 filesystem, this function 
//  will not work as intended
int ialloc(int dev){
  
  // Local variables
  int i;
  char local_buf[BLKSIZE];

  // read inode_bitmap block into local_buf
  get_block(dev, imap, local_buf);

  for(i=0; i<ninodes; i++){

    // When we encounter an inode number that isn't occupied on the bit map, set the bit to being occupied and put the bitmap back on the 
    // disk. decrement the number of free inodes.
    if(tst_bit(local_buf, i)==0){
      set_bit(local_buf, i);
      put_block(dev, imap, local_buf);

      decFreeInodes(dev);

      // New number represented with +1 since the 0th inode is technically the first one, inode 1, so we count +1 on inodes.
      printf("Allocated ino = %d\n", i+1);
      return i+1;
    }
  }

  return 0;
}

// description: deallocates an inode number "ino" in the inode bitmap
// returns: 1 if successful.
//          0 if unsuccessful.
// --if imap isn't assigned to the inode_bit map in the ext2 filesystem and/or the dev inputted isn't a file descriptor of an ext2 filesystem, this function 
//  will not work as intended
// --if specified ino is out of range, return 0
// --if inode isn't allocated, return 0.
int idalloc(int dev, int ino){

  // Local variables
  int i;
  char local_buf[BLKSIZE];

  // read inode_bitmap block into local_buf
  get_block(dev, imap, local_buf);

  // If out of range, return
  if (ino > ninodes){
    printf("idalloc: Inode number out of range\n");
    return 0;
  }

  // If inode map bit is 0, return
  if (!tst_bit(local_buf, ino-1)){
    printf("idalloc: Inode uninitialized\n");
    return 0;
  }

  // Deallocate at this point and write back
  clr_bit(local_buf, ino-1);
  put_block(dev, imap, local_buf);

  // Decrement number of free inodes
  decFreeInodes(dev);

  // Return when done
  return 1;
}

// description: allocates an block number based on available blocks in the block bitmap global.
// returns: block number if successful.
//          0 if unsuccessful.
// --if bmap isn't assigned to the block_bit map in the ext2 filesystem and/or the dev inputted isn't a file descriptor of an ext2 filesystem, this function 
//  will not work as intended
int balloc(int dev){

  int i;
  char local_buf[BLKSIZE];

  // read inode_bitmap block into local_buf
  get_block(dev, bmap, local_buf);

  for(i=0; i<nblocks; i++){

    // When we encounter an inode number that isn't occupied on the bit map, set the bit to being occupied and put the bitmap back on the 
    // disk. decrement the number of free inodes.
    if(tst_bit(local_buf, i)==0){
      set_bit(local_buf, i);
      put_block(dev, bmap, local_buf);

      decFreeBlocks(dev);

      // New number represented with +1 since the 0th inode is technically the first one, inode 1, so we count +1 on inodes.
      printf("Allocated block = %d\n", i+1);

      // Entry contents into block with value 0 for all bytes.
      mybzero(local_buf);
      put_block(dev, i+1, local_buf);

      // Return block number
      return i+1;
    }

  }

  // if no free blocks remain, return 0;
  return 0;
}

// description: deallocates a block number "blk" in the inode bitmap
// returns: 1 if successful.
//          0 if unsuccessful.
// --if imap isn't assigned to the block_bit map in the ext2 filesystem and/or the dev inputted isn't a file descriptor of an ext2 filesystem, this function 
//  will not work as intended
// --if specified blk is out of range, return 0
// --if blk isn't allocated, return 0.
int bdalloc(int dev, int blk){

  // Local variables
  int i;
  char local_buf[BLKSIZE];

  // read inode_bitmap block into local_buf
  get_block(dev, bmap, local_buf);

  // If out of range, return
  if (blk > nblocks){
    printf("bdalloc: Inode number out of range\n");
    return 0;
  }

  // If inode map bit is 0, return
  if (!tst_bit(local_buf, blk-1)){
    printf("bdalloc: Block uninitialized\n");
    return 0;
  }

  // Deallocate at this point and write back
  clr_bit(local_buf, blk-1);
  put_block(dev, bmap, local_buf);

  // Decrement number of free inodes
  decFreeBlocks(dev);

  // Return when done
  return 1;
}

// description: Searches the list of all minodes for the next available node without a refcount. Then it sets that ref count = 1 signifying that
//  it's being used. 
// returns: the minode initialized if successful
//          0 if unsuccessful.
MINODE* mialloc(){
  int i;

  for(i = 0; i<NMINODE; i++){

    MINODE *mp = &minode[i];

    // if refCount == 0, initialize this minode and return its address.
    if(mp->refCount == 0){
      mp->refCount = 1;
      return mp;
    }
  }

  // return 0 if no more minodes can be initialized.
  return 0;
}

// description: given a memory inode, this function sets its reference count = 0 signifying that it is no longer being used and can be overriden if needed
void midalloc(MINODE* mip){
  mip->refCount = 0;
}
