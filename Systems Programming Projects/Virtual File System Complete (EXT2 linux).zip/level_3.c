/************* level_3.c file **************/
#include "type.h"

// decription: Give a dev number, this function searches the mount table and returns the Mount associated with that dev number
// returns: mount pointer if found.
//          null if not found.
MOUNT* getmptr(int target_dev){

    // If target dev is 0 or less, we don't search since a dev of 0 or less means that it's empty
    if (target_dev <= 0){
        return NULL;
    }

    // For each member in mountTable...
    for (int i = 0; i < NMNT; i++){

        // If the dev numbers match, we've found it. Return the pointer associated with it.
        if (mountTable[i].dev == target_dev){
            return mountTable + i;
        }
    }

    // If we've made it to this point, we didn't find it and need to return null
    return NULL;
}

// description: Prints all mounts in mountTable. Only prints initialized mounts
int print_mounts(){

    printf("Displaying current mountTable...\n");
        
    // Format print
    printf("**************************************************************\n");

    // Display mount table
    for (int i = 0; i < NMNT;i++){

        // If the mount is initialized, print it
        if (mountTable[i].dev != 0){
            printf("Mount: %s\n", mountTable[i].mount_name);
            printf("\tRealName:%s\n", mountTable[i].name);
            printf("\tDev: %d\n", mountTable[i].dev);
        }
    }

    // Format print
    printf("**************************************************************\n");
    return 1;
}

// description: prints the current mount of the filesystem. ex, prints root to start.
int print_current_mount(){

    // Display mount table
    for (int i = 0; i < NMNT;i++){

        // If the mount is initialized, print it
        if (mountTable[i].dev == running->cwd->dev){
            printf("Current mount: %s\n", mountTable[i].mount_name);
            printf("\tRealName:%s\n", mountTable[i].name);
            printf("\tDev: %d\n", mountTable[i].dev);
        }
    }

    return 1;
}

// description: Given a new_user token, this function changes the running process to match the new user.
//  returns: 1 if user was changed.
//           0 if the user wasn't changed.
int login(char* new_user){

    // If new_user is null or empty, return
    if (new_user == NULL){
        printf("login: User token was null\n");
        return 0;
    }
    else if (strcmp(new_user, "")==0){
        printf("login: User token was empty\n");
        return 0;
    }
    
    // If new_user is 0, change proc to super
    else if (strcmp(new_user, "0")==0){
        if (running != &proc[0]){
            printf("login: Switched to superuser\n");
            running = &proc[0];
            return 1;
        }      
        else{
            printf("login: Already logged in as super user\n");
            return 0;
        }
    }

    // If new_user is 1, change proc to normal user
    else if (strcmp(new_user, "1")==0){
        if (running != &proc[1]){
            printf("login: Switched to normal user\n");
            running = &proc[1];
            return 1;
        }
        else{
            printf("login: Already logged in as normal user\n");
            return 0;
        }
    }

    // If nothing was recognized at this point, the inputted token isn't a recognized user. Don't switch and return
    else{
        printf("login: User '%s' not recognized in this system\n", tokens[0]);
        return 0;
    }
}

// description: Prints all commands implemented in level 3
int help_level_3(){
    printf("\n\nLevel 3 Commands:\n");
    printf("\t'mount'\t\t-Given a disk name, directory name, and optionally a mount name, mounts the disk to the directory specified\n");
    printf("\t'umount'\t-\n");
    printf("\t'pmt'\t\t-Prints all openned mounts in the system\n");
    printf("\t'login'\t\t-Switches the current user to the inputted user\n\t\tlogin 0 - switch to superuser\n\t\tlogin 1 - switch to normal user\n");
}

// description: updates global bit maps and variables concerned with file creation to match the inputted dev's variables if they are initialized.
int update_globals(int dev){

    for (int i = 0; i < NMNT; i++){
        if (mountTable[i].dev == dev){
            imap = mountTable[i].imap;
            iblk = mountTable[i].iblk;
            ninodes = mountTable[i].ninodes;
            nblocks = mountTable[i].nblocks;
        }
    }
}

// description: Checks the file's imode compared to the current user and permission requested.
// returns: 1 or greater if the current user has the permission "mode"
//          0 if the current user doesn't have the permission.
int access(MINODE* file_in_question, char mode){

    // If the current user is the super user, return 1 always
    if (running->uid == 0){
        return 1;
    }

    // Otherwise, check the file's uid. If the uid is the same as the current uid, compare permissions as though it were the usr. Otherwise, treat it
    // as "other"
    else if(file_in_question->INODE.i_uid == running->uid){

        switch(mode){
            case 'r':
                return file_in_question->INODE.i_mode & S_IRUSR;
            case 'w':
                return file_in_question->INODE.i_mode & S_IWUSR;
            case 'x':
                return file_in_question->INODE.i_mode & S_IXUSR;
            default:
                return 0;
        }
    }
    else{
        switch(mode){
            case 'r':
                return file_in_question->INODE.i_mode & S_IROTH;
            case 'w':
                return file_in_question->INODE.i_mode & S_IWOTH;
            case 'x':
                return file_in_question->INODE.i_mode & S_IXOTH;
            default:
                return 0;
        }
    }
}