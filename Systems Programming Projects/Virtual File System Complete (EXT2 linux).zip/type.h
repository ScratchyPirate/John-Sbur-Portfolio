/*************** type.h file ****************/
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ext2fs/ext2_fs.h>
#include <string.h>
#include <libgen.h>
#include <sys/stat.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;

typedef struct ext2_super_block SUPER;
typedef struct ext2_group_desc  GD;
typedef struct ext2_inode       INODE;
typedef struct ext2_dir_entry_2 DIR;

SUPER *sp;
GD    *gp;
INODE *ip;
DIR   *dp;   

#define FREE        0
#define READY       1

#define BLKSIZE  1024
#define NMINODE   128
#define NPROC       2
#define NFD        20   // Arbitrary amount of fds that can be openned at a time.
#define NMNT        8   // Arbitrary amount of mounts that can be mounted at a time.

// openTable entry (OFT)
typedef struct oft{
  int   mode;               // 0(RD) 1(WR) 2(RW) 3(AP)
  int   refCount;           // how many things are referencing the openned file
  struct minode *minodePtr;  // file's associated minode
  int   offset;             // offset to start reading or writing from
  char name[64];               // name of the openned file.
} OFT;

typedef struct minode{
  INODE INODE;           // INODE structure on disk
  int dev, ino;          // (dev, ino) of INODE
  int refCount;          // in use count
  int dirty;             // 0 for clean, 1 for modified

  int mounted;           // for level-3
  struct mntable *mptr;  // for level-3
}MINODE;

typedef struct proc{
  struct proc *next;
  int          pid;      // process ID  
  int          uid;      // user ID
  int          gid;
  MINODE      *cwd;      // CWD directory pointer  
  OFT      *fd[NFD];      // Number of file descriptors in the running proc. Max of 20
  int          nfd;      // Number of file descriptors openned.
}PROC;

// Mount struct. Used for mount and umount
typedef struct Mount{
  int dev;
  int ninodes;
  int nblocks;
  int bmap;
  int imap;
  int iblk;
  MINODE* mounted_minode;
  char name[64];
  char mount_name[64];
} MOUNT;

// Globals

MINODE minode[NMINODE];
MINODE *root;
PROC   proc[NPROC], *running;

MOUNT mountTable[NMNT]; // Mount table for filesystem. Keeps track of all mounts being used. Max of 8
int n_mnt;               // Number of mounts openned

char gpath[128]; // global for tokenized components
char *name[64];  // assume at most 64 components in pathname
int   n;         // number of component strings

char *tokens[64];// Safe global used only for tokenizing the stirng after cmd into tokens
int   n_tokens;  // Number of tokens in 'tokens'

int fd, dev;
int getino_dev; // current dev of getino.
int nblocks, ninodes, bmap, imap, iblk;
char line[128], cmd[32], pathname[128], buf[BLKSIZE];



// Function declarations

// util.c functions
int get_block(int dev, int blk, char *buf);
int put_block(int dev, int blk, char *buf);
int tokenize(char *pathname);
MINODE *iget(int dev, int ino);
void iput(MINODE *mip);
int search(MINODE *mip, char *name);
int getino(char *pathname);
void mybasename(char* path, char* destination);
void mydirname(char* path, char* destination);
int findmyname(MINODE *parent, u32 myino, char myname[ ]);
int findino(MINODE *mip, u32 *myino);
int tst_bit(char* buf, int target_bit);
int set_bit(char* buf, int target_bit);
int clr_bit(char* buf, int target_bit);
int is_dir(MINODE* mip);
void mybzero(char* local_buf);
void print_start_screen();
int split_paths(char *original, char *path1, char *path2);
int find_last_block(MINODE *pip);
int add_last_block(MINODE *pip, int bnumber);
int search_by_ino(int dev, int ino, INODE *ip, char* temp);
int rm(MINODE *mip);
int rm_child(MINODE *pip, char *child);
int enter_name(MINODE *pip, int myino, char *myname);
int ToUInt(char* string);
MINODE* i_get_from_mount(MINODE* mip);
int inode_truncate(MINODE *mip);
void print_dir(char buf[BLKSIZE], DIR*dp);
void print_block(MINODE*pip, int block);
void print_buf(char buf[BLKSIZE]);
void tokenize_inputs();
void print_mip_blocks(MINODE* mip);


// cd_ls_pwd.c
int mycd(char* pathname);
int ls_file(MINODE *mip, char* name);
int ls_dir(MINODE *mip);
int myls(char* pathname);
char *mypwd(MINODE* wd);
void rpwd(MINODE* wd);

// ****level 1****

// alloc_dalloc.c
int decFreeInodes(int dev);
int incFreeInode(int dev);
int decFreeBlocks(int dev);
int incFreeBlocks(int dev);
int ialloc(int dev);
int idalloc(int dev, int ino);
int balloc(int dev);
int bdalloc(int dev, int blk);
MINODE* mialloc();
void midalloc(MINODE* mip);

// mkdir_creat.c
int mymkdir(char* pathname);
int mykmkdir(MINODE* pmip, char* base);
int enter_child(MINODE* pmip, int ino, char* base);
int mycreat(char* pathname);
int mykcreat(MINODE* pmip, char* base);

// rmdir.c
int myrmdir(char* pathname);
int mykrmdir(MINODE* mip, char* pathname);

// link_unlink.c
int mylink(char* old_file, char* new_file);
int myunlink(char* filename);

// symlink.c
int mysymlink(char* old_file, char* new_file);
int myreadlink(char* file, char* buffer);

// level_1.c
int mychmod();
int myutime(char* pathname);
int mystat(char* pathname);
int help_level_1();

// ****level 2****

// open_close_lseek.c
int myopen(char* filename, char* flags);
int myclose(char* filename);
int myclosefd(char* fd_string);
int pfd();

// write_cp.c
int mywrite(char* fd_string, char* local_buf, char* nbytes_string);
int mycp(char* source, char* destination);

// read_cat.c
int myread(char* fd_string, char* local_buf, char* nbytes_string);
int mycat(char* filename);

// level_2.c
int check_invalid_fd(int fd);
int mylseek(int fr, int position);
int mymv(char* source, char* destination);
int peakbuffer(char* buf);
int bebeeb();
int help_level_2();

// ****level 3****

// mount_umount.c
int mymount(char* target_disk, char* target_directory);
int myumount(char* target_disk);

// level_3.c
MOUNT* getmptr(int target_dev);
int print_mounts();
int help_level_3();
int print_current_mount();
int update_globals(int dev);
int login(char* user);
int access(MINODE* file_in_question, char mode);

// *****end type.h*****