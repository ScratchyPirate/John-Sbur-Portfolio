/************* mount_umount.c file **************/
#include "type.h"

// returns: 1 when completed successfully
//          0 when unsuccessfully completed.
int mymount(char* target_disk, char* target_directory){

    // Locals
    char name[64] = "";
    int available_mount_index = -1;
    int new_fd = 0;
    char local_buf[BLKSIZE];
    SUPER* local_sp;
    GD    *local_gp;
    INODE *local_ip;
    DIR   *local_dp;  
    int local_ino = 0;
    MINODE* local_mip = NULL;

    // 1) Verify entered strings. If essential ones are missing, display current mounted systems instead and return.
    // If either pointer is empty, just display all mounted filesystems
    if (target_disk == NULL || target_directory == NULL){
        printf("mount: Tokens inputted are empty\n");
        print_mounts();
        return 0;
    }
    else if (strcmp(target_disk, "")==0){
        printf("mount: Disk token missing\n");
        print_mounts();
        return 0;
    }

    // If the second token is blank. Mount to root name
    if (strcmp(target_directory, "")==0){
        strcpy(target_directory, "/");
    }

    // 2) If the filesystem is already mounted. Don't mount again and return instead.
    for (int i = 0; i < NMNT; i++){
        if (mountTable[i].dev != 0){
            if (!strcmp(mountTable[i].name, target_disk)){
                printf("mount: Disk requested already mounted to system\nmount: %s dev = %d\n", mountTable[i].name, mountTable[i].dev);
                return 0;
            }
        }
    }

    // Go to the next available mount entry and get the index
    for (int i = 0; i < NMNT; i++){
        if (mountTable[i].dev == 0){
            available_mount_index = i;
            i = NMNT;
        }
    }

    // If no index was found, table is full. Return
    if (available_mount_index == -1){
        printf("mount: mount table full. Cannot mount a new mount until other mounts are unmounted\n");
        print_mounts();
        return 0;
    }

    // 3) LINUX open the filesystem for RW. Record fd number as the new DEV
    // Verify the fs is openned.
    mountTable[available_mount_index].dev = open(target_disk, O_RDWR);
    if (mountTable[available_mount_index].dev < 0){
        printf("mount: open %s failed\n", target_disk);
        mountTable[available_mount_index].dev = 0;
        return 0;
    }

    /********** read super block  ****************/
    get_block(mountTable[available_mount_index].dev, 1, local_buf);
    local_sp = (SUPER *)local_buf;

    /* verify it's an ext2 file system ***********/
    if (local_sp->s_magic != 0xEF53){
        printf("mount: magic = %x is not an ext2 filesystem. Cannot mount\n", local_sp->s_magic);
        mountTable[available_mount_index].dev = 0;
        return 0;
    }     

    // 4) Before initializing anything else, we need to verify we can mount the filesystem at the target_directory. Verify we can make the directory.
    // If we can't, return.
    // Attempt to make the directory
    int result = mymkdir(target_directory);
    if (result==0){
        printf("mount: Failed to create mount point '%s'\n", target_directory);
        mountTable[available_mount_index].dev=0;
        return 0;
    }

    // Get the directory's inode
    local_ino = getino(target_directory);

    // If local_ino = 0, we failed to find the inode and need to return.
    if (local_ino == 0){
        printf("mount: Failed to find %s within the current filesystem\n", target_directory);
        mountTable[available_mount_index].dev = 0;
        return 0;
    }

    // Get directory pointer
    local_mip = iget(running->cwd->dev, local_ino);

    // If local_mip == 0, we failed to find it and need to return
    if (local_mip == 0){
        printf("mount: Failed to find %s within the current filesystem\n", target_directory);
        mountTable[available_mount_index].dev = 0;
        return 0;
    }

    // 5) Verify it's a directory and not busy. If either is true, return
    // Directory
    if (S_ISDIR(local_mip->INODE.i_mode)==0){
        printf("mount: %s is not a directory and cannot be mounted to\n", target_directory);
        mountTable[available_mount_index].dev = 0;
        return 0;
    }
    // Busy
    if (local_mip->refCount > 1){
        printf("mount: %s is busy and cannot be mounted to\n", target_directory);
        mountTable[available_mount_index].dev = 0;
        return 0;
    }

    // 6) Initialize mounted_filesystem's mountTable entries

    // From previously pulled SUPER
    mountTable[available_mount_index].ninodes = local_sp->s_inodes_count;
    mountTable[available_mount_index].nblocks = local_sp->s_blocks_count;

    // get group descriptor. get bitmaps for future reference.
    get_block(mountTable[available_mount_index].dev, 2, local_buf); 
    local_gp = (GD *)local_buf;

    mountTable[available_mount_index].bmap = local_gp->bg_block_bitmap;
    mountTable[available_mount_index].imap = local_gp->bg_inode_bitmap;
    mountTable[available_mount_index].iblk = local_gp->bg_inode_table;

    // Initialize the names of the mount
    strcpy(mountTable[available_mount_index].mount_name, target_directory);
    strcpy(mountTable[available_mount_index].name, target_disk);

    // 7) Mark minode as mounted
    mountTable[available_mount_index].mounted_minode = local_mip;
    mountTable[available_mount_index].mounted_minode->mounted = 1;

    // Return when done
    return 1;
}

// description: Unmounts a mounted filesystem as long as the filesystem isn't busy.
// returns: 1 when completed successfully
//          0 when unsuccessfully completed.
int myumount(char* target_disk){

    // Locals
    int target_index = -1;

    // Verify target_disk is initialized
    if (target_disk == NULL){
        printf("umount: Disk token was null\n");
        return 0;
    }
    else if (strcmp(target_disk, "")==0){
        printf("umount: Disk token was empty\n");
        return 0;
    }

    // 1) Try and find the mount within the mountTable
    for (int i = 0; i < NMNT; i++){

        // If the entry is initialized...
        if (mountTable[i].dev != 0){

            // If the entry's name matches the inputted string "target_disk", set the target_index equal
            // to the entry's index.
            if (strcmp(mountTable[i].name, target_disk)==0){
                target_index = i;
            }
        }
    }
    // If the index was never found, return here
    if (target_index == -1){
        printf("umount: Requested disk not found in mount table\n");
        return 0;
    }

    // 2) Check whether the file is active in the mounted filesystem
    // For each memory inode...
    for (int i = 0; i < NMINODE;i++){

        // If the dev of the minode matches and the refCount is greater than 1, return since the filesystem is busy.
        if (minode[i].dev == mountTable[target_index].dev && minode[i].refCount > 0){
            printf("umount: Requested disk is busy and cannot be unmounted\n");
            return 0;
        }
    }

    // 3) Find the mounted filesystem's inode and set mounted to 0. Then use iput,
    mountTable[target_index].mounted_minode->mounted = 0;

    // Remove the created directory for the mount
    int current_uid = running->uid;
    login("0");
    mykrmdir(mountTable[target_index].mounted_minode, mountTable[target_index].mount_name);
    running->uid = current_uid;

    iput(mountTable[target_index].mounted_minode);

    // Reset mount table entry
    mountTable[target_index].dev = 0;
    mountTable[target_index].ninodes = 0;
    mountTable[target_index].nblocks = 0;
    mountTable[target_index].iblk = 0;
    mountTable[target_index].imap = 0;
    mountTable[target_index].bmap = 0;
    mountTable[target_index].mounted_minode = NULL;
    mountTable[target_index].name[0] = '\0';
    mountTable[target_index].mount_name[0] = '\0';

    

    // 4) Return when done
    return 1;
}