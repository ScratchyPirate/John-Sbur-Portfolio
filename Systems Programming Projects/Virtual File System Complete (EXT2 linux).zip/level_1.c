/************* level_1.c file **************/
#include "type.h"



// Major Level_1 Commands are in their respective files


// Minor Level_1 Commands

// description: Using two tokens, tokens[0] and tokens[1], this function changes the file specified in token1 according to the string in tokens[0].
//  Split into three parts, who, what, which.
//  Who: Which area of the i_mode of the file specified to edit. 'u' = user, 'g' = group, 'o' = other, and 'a' = all/
//  What: The modifier of the area
//      '-' = remove permission
//      '+' = add permission
//      '=' = set permission (remove previous permissions and add new ones)
//  Which: Which permission bits to edit
//      'r' = read bit
//      'w' = write bit
//      'x' = execute bit
//
//  Example:
//      chmod u+r file
//      -This adds the read bit permission to the user area in the file's inode's i_mode
//      -Before --wx------
//      -After  -rwx------
//  Notes: Multiple whats and multiple whichs may be added to the first token, ex. ug=rwx.
//      However, only one "which" is permitted, ex. ug=+rw would not be allowed.
int mychmod(){
    
    // 1) Verify first two tokens are initialized
    // Check if either token is null. If true, return 0.
    if(tokens[0] == 0 || tokens[1] == 0){
        printf("chmod: Missing tokens\n");
        return 0;
    }

    // Check if first token is empty string. If true, return 0.
    if(!strcmp(tokens[0], "")){
        printf("chmod: Permission token missing\n");
        return 0;
    }

    // Check if second token is empty string. If true, return 0.
    if(!strcmp(tokens[1], "")){
        printf("chmod: Pathname token missing\n");
        return 0;
    }

    // 2) Look for file in system and load it into memory. 
    int ino = getino(tokens[1]);
    // If it can't be found, return 0
    if(ino == 0){
        printf("chmod: File couldn't be found in system\n");
        return 0;
    }

    MINODE* mip = iget(getino_dev, ino);
    // If memory inode wasn't loaded, return 0.
    if(mip == 0){
        printf("chmod: Error, memory inode not loaded into memory\n");
        return 0;
    }

    // 3) Get each part of the token into 3 parts, who, what, which
    // holder stores the first token so that we can access it like an array
    // holder2 stores the first letters before the modifier "+, -, or ="
    // modify_all represents if we are modifying all permissions in each user
    // Target_bit represents the permission bit to be modified
    // modifier represents if we are removing permissions "-", granting permissions "+", or setting and removing others "="
    //  "-" = 1;
    //  "+" = 2;
    //  "=" = 3;
    // valid_character is used to determine if a character after the modified letter is valid
    // valid_token represents whether the token contains a modifier
    // shift_amount is used to determine how much target_bit is shifted during modification and how much it needs to be shifted
    //  back afterwards.
    // i is the counter for each for loop
    // modifier_position represents the position of the modifier found in the permission token.
    char holder[64] = "";
    char holder2[64] = "";
    int target_bit = 0;
    int modify_all = 0;
    int modifier = 0;
    int valid_character = 0;
    int valid_token = 0;
    int shift_amount = 0;
    int i = 0;
    int modifier_position = 0;
    strcpy(holder, tokens[0]);

    // Check to see if the holder contains a modifier "+, -, or ="
    // If the modifier is at the beginning, the token is invalid.
    if(holder[0] == '+' || (holder[0] == '-' || holder[0] == '=')){
        printf("chmod: Invalid permission token. Modifier at beginning of token.\n");
        iput(mip);
        return 0;
    }
    for(int i = 0; holder[i] != '\0'; i++){
        if(holder[i] == '+' || (holder[i] == '-' || holder[i] == '=')){
            // Checks to make sure only 1 modifier is in the string.
            if(!valid_token){

                // Mark as valid and store the modifier type.
                valid_token = 1;
                modifier_position = i;

                // Store modifier type
                switch(holder[i]){
                    case '-':
                        modifier = 1;
                        break;
                    case '+':
                        modifier = 2;
                        break;
                    case '=':
                        modifier = 3;
                        break;
                    default:
                        break;
                }
            }
            // If there's more than 1 modifier, return here.
            else{
                printf("chmod: Invalid permission token. Multiple modifiers.\n");
                iput(mip);
                return 0;
            }
        }
    }
    // If it's not a valid token, return here
    if(!valid_token){
        printf("chmod: Invalid permission token. No modifier present.\n");
        iput(mip);
        return 0;
    }
    // If the modifier is at the end of the token, return here
    if(holder[i-1] == '+' || (holder[i-1] == '-' || holder[i-1] == '=')){
        printf("chmod: Invalid permission token. Modifier at end of token.\n");
        iput(mip);
        return 0;
    }

    // Store letters before modifier into holder2 and make holder2 a string.
    for(i = 0; holder[i] != '+' && (holder[i] != '-' && holder[i] != '=');i++){
        holder2[i] = holder[i];
    }
    holder2[i] = '\0';


    // 4) Update the permission bits.
    // For each letter in holder2, change permissions in mip->INODE.i_mode.
    for(int h = 0; holder2[h] != '\0'; h++){

        // Reset locals used in each loop.
        target_bit = 0;
        valid_character = 1;
        modify_all = 0;

        // Get which bit we are modifying
        if(holder2[h] == 'u')
            target_bit = S_IXUSR;
        else if(holder2[h] == 'g')
            target_bit = S_IXGRP;
        else if(holder2[h] == 'o')
            target_bit = S_IXOTH;
        else if(holder2[h] == 'a'){
            modify_all = 1;
            target_bit = S_IXOTH;
        }
        else{
            valid_character = 0;
        }

        // If the character is valid, continue. Else, go to next loop.
        if(valid_character){

            // If modifier = 3, remove all current permissions from the target letter
            if(modifier == 3){

                // If modifying every bit, "a=", set all permissions to 0 before adding permissions.
                if(modify_all == 1){
                    mip->INODE.i_mode &= (~511);
                }
                // Set user permission bits to 0 if "u="
                else if(target_bit == S_IXUSR){
                    mip->INODE.i_mode &= (~448);
                }
                // Set group permission bits to 0 if "g="
                else if(target_bit == S_IXGRP){
                    mip->INODE.i_mode &= (~56);
                }
                // Set other permission bits to 0 if "o="
                else if(target_bit == S_IXOTH){
                    mip->INODE.i_mode &= (~7);
                }

            }

            // Loop looking for tokens to edit
            for(i = modifier_position+1; holder[i] != '\0'; i++){
                
                // Reset variables used in each loop
                shift_amount = 0;
                valid_character = 1;

                // Get target bit. Mark shift_amount to correspond with how much the target_bit was shifted over
                if(holder[i] == 'r'){
                    target_bit = target_bit << 2;
                    shift_amount = 2;
                }
                else if(holder[i] == 'w'){
                    target_bit = target_bit << 1;
                    shift_amount = 1;
                }
                else if(holder[i] == 'x'){
                    // For x, the bit already starts there so we don't have to shift. Shift_amount stays at 0
                }
                // If we encounter an invalid character, skip to next.
                else{
                    valid_character = 0;
                }

                // If character is valid, continue. Else, go to next loop.
                if(valid_character){

                    // If modifying all, set each permission to the bit corresponding with the letter
                    if(modify_all){
                        target_bit = target_bit << 3;
                        target_bit = target_bit | (1 << shift_amount);
                        target_bit = target_bit << 3;
                        target_bit = target_bit | (1 << shift_amount);
                    }
                    // Modify single bits in target user
                 
                    // Removing permissions case.
                    if(modifier == 1){
                        target_bit = ~target_bit;
                        mip->INODE.i_mode = mip->INODE.i_mode & target_bit;
                        target_bit = ~target_bit;
                    }
                    // Granting permissions case.
                    else if(modifier == 2 || modifier == 3){
                        mip->INODE.i_mode = mip->INODE.i_mode | target_bit;
                    }
                    
                    // Reset target_bit if we are in the modify all case so that the next loops don't modify permissions it shouldn't
                    if(modify_all){
                        target_bit = (1 << shift_amount);
                    }

                }

                // Reset target bit
                target_bit = target_bit >> shift_amount;
            }
        }
    }

    // 5) After modification, store mip back
    mip->dirty = 1;
    iput(mip);

    // Return when done
    return 1;
}

// description: Changes a file's access time to current time. Follows "pathname" to find file.
int myutime(char* pathname){
    
    // 1) Verify the first token exists
    if(pathname == 0){
        printf("utime: Missing token. Inputted token not found\n");
        return 0;
    }
    if(!strcmp(pathname, "")){
        printf("utime: Missing token. Inputted token empty\n");
        return 0;
    }

    // 2) Get file associated with token
    int ino = getino(pathname);
    // Verifiy inode number was gotten
    if(ino == 0){
        printf("utime: Inputted file not found in system\n");
        return 0;
    }
    MINODE* mip = iget(getino_dev, ino);
    // Verify memory inode was gotten
    if(mip == 0){
        printf("utime: Inputted file not loaded. No more memory inodes can be allocated\n");
        return 0;
    }

    // 3) Update time
    mip->INODE.i_atime = time(0L);

    // 4) Store inode back and return
    mip->dirty = 1;
    iput(mip);
    return 1;
}

// description: Lists details about the file inputted in pathname in linux "stat" format.
int mystat(char *pathname){
    
    // 1) Verify the first token exists
    if(pathname == 0){
        printf("stat: Missing token. Inputted token not found\n");
        return 0;
    }
    if(!strcmp(pathname, "")){
        printf("stat: Missing token. Inputted token empty\n");
        return 0;
    }

    // 2) Get file associated with token
    int ino = getino(pathname);
    // Verifiy inode number was gotten
    if(ino == 0){
        printf("stat: Inputted file not found in system\n");
        return 0;
    }
    MINODE* mip = iget(getino_dev, ino);
    // Verify memory inode was gotten
    if(mip == 0){
        printf("stat: Inputted file not loaded. No more memory inodes can be allocated\n");
        return 0;
    }

    // 3) Print file information
    // File name
    char holder[BLKSIZE] = "";
    mybasename(pathname, holder);
    printf("FILE:\t%s\n", holder);

    // Size Blocks IO Blocks type of file
    printf("SIZE:%10d BLOCKS:%8d IO BLOCK:%8d ", mip->INODE.i_size, mip->INODE.i_blocks, BLKSIZE);
    printf("FILETYPE: ");
    if(S_ISDIR(mip->INODE.i_mode)){
        printf("Directory file\n");
    }
    else if(S_ISLNK(mip->INODE.i_mode)){
        printf("Link file\n");
    }
    else{
        printf("Regular file\n");
    }

    // Device, Inode Number, number of links
    printf("DEVICE:%8d INODE:%9d LINKS:%4d\n", mip->dev, mip->ino, mip->INODE.i_links_count);

    // Access bits
    printf("ACCESS: (%d/", mip->INODE.i_mode);
    // User permissions
    (mip->INODE.i_mode & S_IRUSR) ? printf("r") : printf("-");
    (mip->INODE.i_mode & S_IWUSR) ? printf("w") : printf("-");
    (mip->INODE.i_mode & S_IXUSR) ? printf("x") : printf("-");
    // Group permissions
    (mip->INODE.i_mode & S_IRGRP) ? printf("r") : printf("-");
    (mip->INODE.i_mode & S_IWGRP) ? printf("w") : printf("-");
    (mip->INODE.i_mode & S_IXGRP) ? printf("x") : printf("-");
    // Other permissions
    (mip->INODE.i_mode & S_IROTH) ? printf("r") : printf("-");
    (mip->INODE.i_mode & S_IWOTH) ? printf("w") : printf("-");
    (mip->INODE.i_mode & S_IXOTH) ? printf("x") : printf("-");
    printf(")\t");

    // Uid
    printf("UID: (%6d/%s)\t", mip->INODE.i_uid, getpwuid(mip->INODE.i_uid)->pw_name);

    // Gid
    printf("GID: (%6d/%s)\n", mip->INODE.i_gid, getgrgid(mip->INODE.i_gid)->gr_name);

    // Timestamps
    time_t time;
    char* mtime;
    // Access time
    printf("ACCESS: ");
    time = mip->INODE.i_atime;
    mtime = ctime(&time);
    mtime[strlen(mtime) - 1] = '\0';
    printf("%s\n",mtime);
    // Modify time
    printf("MODIFY: ");
    time = mip->INODE.i_mtime;
    mtime = ctime(&time);
    mtime[strlen(mtime) - 1] = '\0';
    printf("%s\n",mtime);
    // Change time
    printf("CHANGE: ");
    time = mip->INODE.i_ctime;
    mtime = ctime(&time);
    mtime[strlen(mtime) - 1] = '\0';
    printf("%s\n",mtime);

    // 4) Store mip back and return
    iput(mip);
    return 1;
}

// description: prints all implemented commands for level 1
int help_level_1(){
    printf("\n\nLevel 1 Commands:\n");
    printf("\t'ls' \t\t-This tries to list the contents of the pathname in UNIX ls -l format. \n");
    printf("\t'pwd'\t\t-Prints the current working directory of the terminal\n");
    printf("\t'cd' \t\t-Tries to change the current working directory to the path specified\n");
    printf("\t'mkdir'\t\t-Tries to make a directory in the inputed path with the last token being the name\n\t\t\t\t of the new directory\n");
    printf("\t'rmdir'\t\t-Tries to remove an empty directory following the given path with the directory \n\t\t\t\tremoved being the last token\n");
    printf("\t'creat'\t\t-Tries to create a file in the specified path with its name being the last token\n");
    printf("\t'link'\t\t-Links a file to a new file which share an inode\n");
    printf("\t'unlink'\t-Decreases the number of links of the specified file. If not links remain, it's \n\t\t\t\tdeleted\n");
    printf("\t'rm'\t\t-Same as unlink\n");
    printf("\t'symlink'\t-Creates a symbolic link between two files\n");
    printf("\t'readlink'\t-Reads the name of a symbolic link\n");
    printf("\t'chmod'\t\t-Changes the permission bits of the specified file\n");
    printf("\t'utime'\t\t-Changes the specified file's access time to current time\n");
    printf("\t'stat'\t\t-Prints information about a specified file\n");
    printf("\t'quit'\t\t-Exits the terminal\n\n");
}