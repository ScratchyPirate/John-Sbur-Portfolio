/************* symlink.c file **************/
#include "type.h"


// description: creates a symbolic link from new_file to old_file. Unlike hard links, symlink can link to anything,
// including DIRs, even files not on the same device
int mysymlink(char* old_file, char* new_file){
    MINODE *mip;

    // verify old_file exists (either dir or regular)
    int old_ino = getino(old_file);
    if (old_ino == 0) {
        printf("%s does not exist\n", old_file);
        return -1;
    }

    // Create the new_file. If unsuccessfully created, return.
    int result = mycreat(new_file);
    if (result == 0){
        printf("symlink: Failed to create a new link file\n");
        return -1;
    }

    // set type of new_file to LNK
    int new_ino = getino(new_file);
    if (new_ino == 0) {
        printf("%s does not exist.\n", new_file);
        return -1;
    }

    update_globals(getino_dev);
    mip = iget(getino_dev, new_ino);

    mip->INODE.i_mode = 0xA1FF; // A1FF sets LINK
    mip->dirty = 1;
    // write the string old into the i_block[ ], which has room for 60 chars.
    // i_block[] + 24 after = 84 total for old_file
    strncpy(mip->INODE.i_block, old_file, 84);
    // set file size = number of chars in old_file
    mip->INODE.i_size = strlen(old_file);
    // write the INODE back to disk.
    mip->dirty = 1;
    iput(mip);
    update_globals(running->cwd->dev);
    printf("new file = %s -> old file = %s\n", old_file, new_file);
}

// description: reads the target file name of a symbolic file and returns the length of the target file name.
int myreadlink(char* file, char* buffer){
    int ino;
    MINODE *mip;

    ino = getino(file);
    update_globals(getino_dev);
    mip = iget(getino_dev,ino);
    update_globals(running->cwd->dev);

    if(S_ISLNK(mip->INODE.i_mode))
    {
        strncpy(buffer[BLKSIZE],mip->INODE.i_block,mip->INODE.i_size);
        return mip->INODE.i_size;
    }
}
