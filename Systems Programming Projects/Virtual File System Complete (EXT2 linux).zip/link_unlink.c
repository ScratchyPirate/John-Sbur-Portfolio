/************* link_unlink.c file **************/
#include "type.h"

// description: Links a file to a new file which share an inode. creates a hard link from new_file to old_file.
int mylink(char* old_file, char* new_file){
    int old_inode, inode_new;
    MINODE *mip, *mip_new;
    char parent[256], child[256];

    old_inode = getino(old_file);
    if (old_inode == 0) {
        // file doesn't exist
        printf("ERROR: file linking to doesn't exist\n");
        return -1;
    }

    update_globals(getino_dev);
    mip = iget(getino_dev, old_inode);

    // Verify access to old file. If not permitted, put oldfile and return.
    if (!access(mip, 'r') || !access(mip, 'w') || !access(mip, 'x')){
        printf("link: User '%d' cannt create a hard link from file '%s'\n", running->uid, old_file);
        iput(mip);
        update_globals(running->cwd->dev);
        return -1;
    }
    
    if (S_ISDIR(mip->INODE.i_mode)) {
        printf("ERROR: is DIR\n");
        iput(mip);
        update_globals(running->cwd->dev);
        return -1;
    }

    int old_dev = getino_dev;

    // look for that directory new_file exists but the file does not exist yet in the directory
    strcpy(parent, dirname(new_file));
    strcpy(child, basename(new_file));

    //printf("parent = %s\nchild = %s\n", parent, child);
    inode_new = getino(parent);
    if (inode_new == -1) {
        printf("ERROR: can't create link in parent dir %s\n", parent);
        return -1;
    }
    printf("old file = %s; new file = %s\n", old_file, new_file);
    update_globals(getino_dev);
    mip_new = iget(getino_dev, inode_new);

    // Update mip_new to be a link file


    update_globals(running->cwd->dev);

    if (mip_new->dev != old_dev){
        printf("ERROR: can't link files between two separate systems\n");
        update_globals(mip_new->dev);
        iput(mip_new);
        update_globals(mip->dev);
        iput(mip);
        update_globals(running->cwd->dev);
        return -1;
    }
    enter_name(mip_new, mip->ino, child);
    mip->INODE.i_links_count++;
    mip->dirty = 1;
    mip_new->dirty = 1;
    update_globals(mip->dev);
    iput(mip);
    update_globals(mip_new->dev);
    // Update link permissions and return it to the system.
    chmod(new_file, "u=rwx");
    iput(mip_new);
    update_globals(running->cwd->dev);
    
    return 1;
}

// description: unlinks a file. It decrements the file’s links_count by 1 and deletes the file name from its parent DIR.
// When a file’s links_count reaches 0, the file is truly removed by deallocating its data blocks and inode
int myunlink(char* filename){
    int inode;
    MINODE *mip;
    char parent[256], child[256];

    strcpy(parent, dirname(filename));
    strcpy(child, basename(filename));

    // link MIP
    inode = getino(filename);
    if (inode == 0) {
        printf("ERROR: getting link inode\n");
        return -1;
    }


    mip = iget(getino_dev, inode);

    // If failed to get, return here
    if (mip == NULL){
        return -1;
    }

    // check link mip is not a dir
    if (S_ISDIR(mip->INODE.i_mode)) {
        printf("DIR cannot be link; cannot unlink %s\n", filename);
        update_globals(running->cwd->dev);
        return -1;
    }

    if (running->uid != mip->INODE.i_uid && running->uid != 0) {
        printf("ERROR: uid mismatch\n");
        update_globals(running->cwd->dev);
        return -1;
    }
    // decrement link's link_count
    mip->INODE.i_links_count--;
    if (mip->INODE.i_links_count == 0) {
        // deallocate data blocks
        if (!S_ISLNK(mip->INODE.i_mode)) {
            inode_truncate(mip);
        }
    }

    mip->dirty = 1;
    update_globals(mip->dev);
    iput(mip);
    update_globals(running->cwd->dev);


    // remove child, which is the same as rm()
    // parent MIP
    int pino = getino(parent);
    if (pino == 0) {
        printf("ERROR: cannot get parent ino (link)\n");
        return -1;
    }
    MINODE *pip = iget(mip->dev, pino);
    update_globals(mip->dev);
    rm_child(pip, child);
    update_globals(running->cwd->dev);

}
