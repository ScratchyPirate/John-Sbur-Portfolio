/************* main.c file **************/
#include "type.h"

// description: run during the start of the program. 
//  1) Initializes the minodes of the system, 128 files
//  2) Initializes 2 procs, 0=sudo proc, anything else is a regular user process
//  3) Set each proc's cwd to root.
//  4) Set the last proc's "next" field to proc[0], making a circular loop
int init()
{
  int i, j;
  MINODE *mip;
  PROC   *p;

  printf("init()\n");

  // Initialize minodes to 0
  for (i=0; i<NMINODE; i++){
    mip = &minode[i];
    mip->dev = mip->ino = 0;
    mip->refCount = 0;
    mip->mounted = 0;
    mip->mptr = 0;
  }

  // Initialize processes.
  for (i=0; i<NPROC; i++){
    p = &proc[i];
    p->pid = i;
    p->uid = p->gid = i; // P0 = superuser, other processes are regular users.
    p->cwd = iget(dev, 2);
    p->next = &proc[i+1];
    p->nfd = 0;
    for (int i = 0; i < NFD; i++){
      p->fd[i] = NULL;
    }
  }
  
  // Initialize mount table. Set all entries to the equivalent of empty.
  for (i=0;i<NMNT;i++){
    mountTable[i].dev = 0;
    mountTable[i].ninodes = 0;
    mountTable[i].nblocks = 0;
    mountTable[i].bmap = 0;
    mountTable[i].imap = 0;
    mountTable[i].iblk = 0;
    mountTable[i].mounted_minode = NULL;
    mountTable[i].name[0] = '\0';
    mountTable[i].mount_name[0] = '\0';
  }
  
  proc[NPROC-1].next = &proc[0]; // circular linked list.
}

// description: load root INODE and set root pointer to it
int mount_root()
{  
  // Set the root of the system
  printf("mount_root()\n");
  root = iget(dev, 2);
  
  // Update the first mount table's entry to have entries matching the root's entries
  mountTable[0].dev = dev;
  mountTable[0].ninodes = ninodes;
  mountTable[0].nblocks = nblocks;
  mountTable[0].bmap = bmap;
  mountTable[0].imap = imap;
  mountTable[0].iblk = iblk;
  mountTable[0].mounted_minode = root;
  strcpy(mountTable[0].name, "diskimage");
  strcpy(mountTable[0].mount_name, "root");

  // Update number of mounts openned.
  n_mnt = 1;
}

// description: Used when user enters the "quit" command. Unmounts the root, stores minodes, and exits.
int quit()
{
  printf("Exiting...\n");
  int i;
  MINODE *mip;

  // change to root for unmounting.
  mycd("");

  // close all openned file descriptors
  for (int i=0;i<NPROC;i++){
    for(int j=0; j < NFD;j++){
      running = &proc[i];
      if (proc[i].fd[j] != NULL){
        printf("%s\n", proc[i].fd[j]->name);
        myclose(proc[i].fd[j]->name);
      }
    }
  }

  // unmount any mounted disks that aren't root
  for (i=0; i<NMNT;i++){
    if (mountTable[i].dev != 0 && mountTable[i].dev != mountTable[0].dev){
      myumount(mountTable[i].name);
    }
  }

  // store busy minodes
  for (i=0; i<NMINODE; i++){
    mip = &minode[i];
    if (mip->refCount > 0)
      iput(mip);
  }

  exit(0);
}

// description: entry process for program.
int main(int argc, char *argv[ ])
{

  // Format print statement
  printf("*************************** Begin Execution ***************************\n");
  
  // Locals used in different operations
  int ino;
  char buf[BLKSIZE], buf2[BLKSIZE];
  char* holder;


  // Verify the fs is openned.
  printf("checking EXT2 FS ....\n");
  if ((fd = open("diskimage", O_RDWR)) < 0){
    printf("open %s failed\n", "diskimage");
    exit(1);
  }
  dev = fd;    // global dev same as this fd   
  
  /********** read super block  ****************/
  get_block(dev, 1, buf);
  sp = (SUPER *)buf;

  /* verify it's an ext2 file system ***********/
  if (sp->s_magic != 0xEF53){
      printf("magic = %x is not an ext2 filesystem\n", sp->s_magic);
      exit(1);
  }     
  printf("EXT2 FS OK\n");
  ninodes = sp->s_inodes_count;
  nblocks = sp->s_blocks_count;



  // get group descriptor and update ours. get bitmaps for future reference.
  get_block(dev, 2, buf); 
  gp = (GD *)buf;

  bmap = gp->bg_block_bitmap;
  imap = gp->bg_inode_bitmap;
  iblk = gp->bg_inode_table;
  printf("bmp=%d imap=%d inode_start = %d\n", bmap, imap, iblk);



  // Initialize the procs and mount the virtual disk root.
  init();  
  mount_root();
  printf("root refCount = %d\n", root->refCount);


  // p0 becomes the running process
  printf("creating P0 as running process\n");
  running = &proc[0];
  running->cwd = iget(dev, 2);
  printf("root refCount = %d\n\n\n", root->refCount);


  // Print start screen and different help commands
  print_start_screen();
  printf("\nFor information about different commands, enter 'help' followed by a number to receive\n");
  printf("\tinformation about different commands implemented in this system.\n");
  

  // Running loop looking for user commands.
  while(1){
    
    // Debug loop. Prints all minodes with ref count greater than 0.
    /*
    printf("busy inodes\n");
    for(int i = 0; i < NMINODE; i++){
        if(minode[i].refCount > 0){
          printf("Busy minode [%d %d] refcount = %d\n", minode[i].dev, minode[i].ino, minode[i].refCount);
        } 
      
    }
    */

    // Update globals to match cwd
    update_globals(running->cwd->dev);

    // Print the current mount and current directory.
    printf("\n\n");
    print_current_mount();
    printf("Current User: '%d'\n", running->uid);
    mypwd(running->cwd);
    printf("\n");
    printf("Input command :");
    fgets(line, 128, stdin);
    line[strlen(line)-1] = 0;

    if (line[0]==0)
       continue;
    pathname[0] = 0;

    // Get command into "cmd" and tokens after command into "pathname" if they exist.
    holder = (char*)malloc(128);
    holder = strtok(line," ");
		strcpy(cmd,holder);
    holder = (char*)malloc(128);
		holder = strtok(NULL,"\0");
		if(holder)
			strcpy(pathname,holder);

    // Store tokens in tokens[]
    tokenize_inputs();

    // Print inputted command and tokens
    /*
    printf("\ncmd=%s\n", cmd);
    printf("tokens=");
    for(int i = 0; i < n_tokens;i++){
      printf("\t%s\n", tokens[i]);
    }
    printf("\n");
    */

    // ******************************
    // Level_1 commands

    // ls
    if (strcmp(cmd, "ls")==0){
      if(n_tokens > 0){
        for(int i = 0; i <n_tokens;i++){
          printf("ls: %s\n", tokens[i]);
          myls(tokens[i]);
          utime(tokens[i]);
          printf("\n");
        }
      }
      else{
        myls("");
      }      
    }

    // cd
    else if (strcmp(cmd, "cd")==0){
      if(n_tokens > 0){
        mycd(tokens[0]);
        utime(tokens[0]);
      }
      else{
        mycd("");
      }   
    }

    // pwd
    else if (strcmp(cmd, "pwd")==0)
       mypwd(running->cwd);

    // mkdir
    else if (strcmp(cmd, "mkdir")==0){
      if(n_tokens > 0){
        for(int i = 0; i <n_tokens;i++){
          printf("mkdir: %s\n", tokens[i]);
          mymkdir(tokens[i]);
          printf("\n");
        }
      }
    }

    // creat
    else if (strcmp(cmd, "creat")==0){
      if(n_tokens > 0){
        for(int i = 0; i <n_tokens;i++){
          printf("creat: %s\n", tokens[i]);
          mycreat(tokens[i]);
          printf("\n");
        }
      }
    }

    // rmdir
    else if (strcmp(cmd, "rmdir")==0){
      if(n_tokens > 0){
        for(int i = 0; i <n_tokens;i++){
          printf("rmdir: %s\n", tokens[i]);
          myrmdir(tokens[i]);
          printf("\n");
        }
      }
    }

    // link
    else if (strcmp(cmd, "link")==0){
        if (n_tokens > 0){
            for (int i = 0; i+1 < n_tokens;i+=2){
                printf("link: %s %s\n", tokens[i], tokens[i+1]);
                mylink(tokens[i], tokens[i+1]);
                printf("\n");
            }
        }
    }

    // unlink
    else if (strcmp(cmd, "unlink")==0 || strcmp(cmd, "rm")==0){
        if (n_tokens > 0){
            for(int i = 0; i < n_tokens;i++){
                printf("unlink: %s\n", tokens[i]);
                myunlink(tokens[i]);
                printf("\n");
            }
        }
    }

    // symlink
    else if (strcmp(cmd, "symlink")==0){
        if (n_tokens > 0){
            for(int i = 0; i+1 < n_tokens;i+=2){
                printf("symlink: %s %s\n", tokens[i], tokens[i+1]);
                mysymlink(tokens[i], tokens[i+1]);
                printf("\n");
            }
        }
    }

    // readlink
    else if (strcmp(cmd, "readlink")==0){
        if (n_tokens > 0){
            for(int i = 0; i < n_tokens;i++){
                printf("readlink: %s\n", tokens[i]);
                myreadlink(tokens[i], buf);
                printf("\n");
            }
        }
    }

    // stat
    else if (strcmp(cmd, "stat")==0)
      mystat(tokens[0]);

    // chmod
    else if (strcmp(cmd, "chmod")==0)
      mychmod();

    // utime
    else if (strcmp(cmd, "utime")==0)
      myutime(tokens[0]);

    // quit
    else if (strcmp(cmd, "quit")==0)
      quit();

    // help1
    else if (strcmp(cmd, "help1")==0)
      help_level_1();

    // end Level 1 commands

    // ******************************


    // Level_2 commands

    // open
    else if (strcmp(cmd, "open")==0){
      if(n_tokens > 1){
        for(int i = 0; i+1 < n_tokens;){
          printf("open: %s %s\n", tokens[i], tokens[i+1]);

          // print to signify file was openned
          int result = myopen(tokens[i], tokens[i+1]);
          if(result != -1){
            printf("\nopen: File %s openned in current proc. FD=%d\n", tokens[i], result);
          }
          printf("\n");
          i+=2;
        }
      }
      else{
        printf("open: Missing flags token\n");
      }
    }

    // close (based on file descriptors)
    else if (strcmp(cmd, "close")==0){
      if(n_tokens > 0){
        for(int i = 0; i <n_tokens;i++){
          printf("close: %s\n", tokens[i]);
          myclosefd(tokens[i]);
        }
      }
    }

    // close (based on file name)
    else if (strcmp(cmd, "closefile")==0){
      if(n_tokens > 0){
        for(int i = 0; i < n_tokens;i++){
          printf("close: %s\n", tokens[i]);

          // If closed successfully, tell user.
          int result = myclose(tokens[i]);
          if(result){
            printf("close: Closed file fd=%d\n", result);
          }
        }
      }
    }

    // read
    else if (strcmp(cmd, "read")==0){
      if(n_tokens > 1){
        memset(buf, 0, BLKSIZE);
        printf("read: Reading from fd=%s bytes=%s to buffer...\n", tokens[0], tokens[1]);
        printf("read: Bytes read into buffer nbytes=%d\n", myread(tokens[0], buf, tokens[1]));
      }
      else{
        printf("read: Missing bytes token\n");
      }
    }

    // write
    else if (strcmp(cmd, "write")==0){
      if(n_tokens > 1){
        for(int i = 0; i+1 < n_tokens;){
          printf("write: Writing bytes=%d from buffer to fd=%d...\n", tokens[0], tokens[1]);
          mywrite(tokens[0], buf, tokens[1]);
          printf("\n");
          i+=2;
        }
      }
      else{
        printf("write: Missing bytes token\n");
      }
    }

    // writeline
    else if (strcmp(cmd, "writeline")==0){
      if(n_tokens > 1){

        // Clear buffer 2
        mybzero(buf2);

        // Write each token to the specified file with a space inbetween each
        for(int i = 1; i < n_tokens;i++){
          printf("writeline: Writing token='%s' to fd=%s...\n", tokens[i], tokens[0]);

          // Get length of token into buffer
          sprintf(buf2, "%d", strlen(tokens[i]));

          // Write token to file
          mywrite(tokens[0], tokens[i], buf2);

          // Write space character " " to file
          mywrite(tokens[0], " ", "1");
          printf("\n");
        }

        // At the end, write the '\n' marker to the file to signify the end of the line.
        mywrite(tokens[0], "\n", "1");
      }
      else{
        printf("writeline: Missing bytes token\n");
      }
    }
    
    // cat
    else if (strcmp(cmd, "cat")==0){
      if(n_tokens > 0){
        for(int i = 0; i < n_tokens; i++){
          printf("cat: Target file %s\n", tokens[i]);
          mycat(tokens[i]);
        }
      }
      else{
        printf("cat: Missing filepath token\n");
      }
    }

    // cp
    else if (strcmp(cmd, "cp")==0){
      if(n_tokens > 1){
        for(int i = 0; i+1 < n_tokens;i+=2){
          printf("cp: Copying %s to %s\n", tokens[i], tokens[i+1]);
          mycp(tokens[i], tokens[i+1]);
          printf("\n");
        }
      }
      else{
        printf("cp: Missing tokens\n");
      }
    }

    // lseek
    else if (strcmp(cmd, "lseek")==0){
        if(n_tokens > 1){
            for(int i = 0; i+1 < n_tokens;i+=2){
                printf("lseek: beginning of file %d to offset location %d\n", tokens[i], tokens[i+1]);
                mylseek(tokens[i], tokens[i+1]);
                printf("\n");
            }
        }
        else{
            printf("cp: Missing tokens\n");
        }
    }

    // mv
    else if (strcmp(cmd, "mv")==0){
      if(n_tokens > 1){
            for(int i = 0; i+1 < n_tokens;i+=2){
                printf("mv: Moving %s to %s\n", tokens[i], tokens[i+1]);
                mymv(tokens[i], tokens[i+1]);
                printf("\n");
            }
        }
        else{
            printf("mv: Missing tokens\n");
        }
    }

    // pfd
    else if (strcmp(cmd, "pfd")==0)
      pfd();

    // peak
    else if (strcmp(cmd, "peak")==0)
      peakbuffer(buf);

    // bebeeb
    else if (strcmp(cmd, "bebeeb")==0){
      bebeeb();
    }

    // help2
    else if (strcmp(cmd, "help2")==0)
      help_level_2();

    // end Level 2 commands

    // ******************************


    // Level_3 commands

    // mount
    else if (strcmp(cmd, "mount")==0){
      if (n_tokens > 1){
        if(mymount(tokens[0], tokens[1]))
          printf("mount: Mounted %s under name %s\n", tokens[0], tokens[1]);      
      }
      else{
        printf("mount: Missing disk name token\n");
      }
    }
    

    // umount
    else if (strcmp(cmd, "umount")==0){
      if(n_tokens >= 1){
        myumount(tokens[0]);
      }
      else{
        printf("umount: Missing disk token\n");
      }
    }

    // pmt (print mount table)
    else if (strcmp(cmd, "pmt")==0)
      print_mounts();

    // login (switch users)
    else if (strcmp(cmd, "login")==0)
      login(tokens[0]);
      
    // help3
    else if (strcmp(cmd, "help3")==0)
      help_level_3();

    // Catch for if a command isn't recognized
    else{
      printf("Error: Command not recognized\n");
    }
  }
}
