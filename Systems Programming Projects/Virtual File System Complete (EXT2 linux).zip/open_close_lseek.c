/************* open_close.c file **************/
#include "type.h"


// description: Opens a file for read or write depending on the flags.
//  Flags:
//  0 "RD" => read
//  1 "WR" => write
//  2 "RW" => read or write
//  3 "AP" => append
// Returns: File descriptor when successful
//          -1 when unsuccessful
int myopen(char* filename, char* flags){
    
    // locals
    int ino;
    MINODE* mip;
    int flag = 0;
    int available_fd = -1;
    char base[64] = "";

    // 0) Make sure filename and flags are initialized. If not, return.
    if (flags == 0 || filename == 0){
        printf("open: Tokens uninitialized\n");
        return -1;
    }
    else if (!strcmp(filename, "")){
        printf("open: Filepath missing\n");
        return -1;
    }
    else if (!strcmp(flags, "")){
        printf("open: Flags missing");
        return -1;
    }

    // 1) get file's minode or create if it doesn't exist
    ino = getino(filename);
    if(ino == 0){

        // Create if it doesn't exist.
        if(!mycreat(filename)){
            printf("open: Error. File not created when openning\n");
            return -1;
        }
        ino = getino(filename);
    }
    mip = iget(getino_dev, ino);

    // 2) Make sure openned file is a regular file. If not, return
    if((!S_ISREG(mip->INODE.i_mode))){
        printf("open: Openned file is not a regular file\n");
        iput(mip);
        return -1;
    }

    // 3) Allocate fd within running proc. If not more can be allocated, return
    // If the number of file descriptors openned is equal to the max number of file descriptors that
    // can be openned, return
    if (running->nfd == NFD){
        printf("open: Running proc has the maximum amound of file descriptors openned\n");
        iput(mip);
        return -1;
    }
    // Allocate and initialize
    else{

        // Find next open fd
        for (int i = 0; i < NFD; i++){
            if(running->fd[i] == 0){
                available_fd = i;
                i = NFD;
            }
        }
        // If not found, return
        if(available_fd == -1){
            printf("open: Running proc has the maximum amound of file descriptors openned\n");
            iput(mip);
            return -1;
        }

        // Allocate
        running->fd[available_fd] = (OFT*)malloc(sizeof(OFT));

        // Set mode based on inputted flag. Initialize Offset as well depending on mode. 
        //  If flag is invalid, return.
        // Read
        if(!strcmp(flags, "RD") || !strcmp(flags, "O_RDONLY")){

            // Check permissions. If the user doesn't have the right permission, deallocate openned fd and return.
            // Otherwise, continue like normal.
            if (!access(mip, 'r')){
                printf("open: User '%d' doesn't have permission to read from file '%s'\n", running->uid, filename);
                free(running->fd[available_fd]);
                running->fd[available_fd] = 0;
                iput(mip);
                return -1;
            }

            running->fd[available_fd]->mode = 0;
            running->fd[available_fd]->offset = 0;
        }
        // Write
        else if(!strcmp(flags, "WR") || !strcmp(flags, "O_WRONLY")){

            // Check permissions. If the user doesn't have the right permission, deallocate openned fd and return.
            // Otherwise, continue like normal.
            if (!access(mip, 'w')){
                printf("open: User '%d' doesn't have permission to write to file '%s'\n", running->uid, filename);
                free(running->fd[available_fd]);
                running->fd[available_fd] = 0;
                iput(mip);
                return -1;
            }

            running->fd[available_fd]->mode = 1;
            running->fd[available_fd]->offset = 0;
        }
        // Read-Write
        else if(!strcmp(flags, "RW") || !strcmp(flags, "O_RDWR")){

            // Check permissions. If the user doesn't have the right permission, deallocate openned fd and return.
            // Otherwise, continue like normal.
            if (!access(mip, 'r') || !access(mip, 'w')){
                printf("open: User '%d' doesn't have permission to read and write to file '%s'\n", running->uid, filename);
                free(running->fd[available_fd]);
                running->fd[available_fd] = 0;
                iput(mip);
                return -1;
            }

            running->fd[available_fd]->mode = 2;
            running->fd[available_fd]->offset = 0;
        }
        // Append
        else if(!strcmp(flags, "AP") || (!strcmp(flags, "APPEND") || !strcmp(flags, "O_APPEND"))){

            // Check permissions. If the user doesn't have the right permission, deallocate openned fd and return.
            // Otherwise, continue like normal.
            if (!access(mip, 'w')){
                printf("open: User '%d' doesn't have permission to append on file '%s'\n", running->uid, filename);
                free(running->fd[available_fd]);
                running->fd[available_fd] = 0;
                iput(mip);
                return -1;
            }

            running->fd[available_fd]->mode = 3;
            running->fd[available_fd]->offset = mip->INODE.i_size;
        }
        // Return if mode not found.
        else{
            printf("open: Mode not recognized\n");
            free(running->fd[available_fd]);
            running->fd[available_fd] = 0;
            iput(mip);
            return -1;
        }

        // Set ref count to 1
        running->fd[available_fd]->refCount = 1;

        // Set oft minode
        running->fd[available_fd]->minodePtr = mip;

        // Set name of openned file to name in OFT for reference
        running->fd[available_fd]->name[0] = '\0';
        mybasename(filename, base);
        strcpy(running->fd[available_fd]->name, base);

        // Increment nfd
        running->nfd++;

        // DEBUG print open stats
        //printf("openned: \n\tmode=%d\n\toffset=%d\n", running->fd[available_fd]->mode, running->fd[available_fd]->offset);

        // Return index of fd (We don't close mip since it is openned. Closed during "close" function or when the code exits.
        return available_fd;
    }

}

// description: Given a filename, this function checks to see if it's associated with any file descriptors and if it is, close it.
int myclose(char* filename){
    
    // Local used to keep track of which files are closed
    int n_fd_closed = 0;

    // For each fd in the running process
    for (int i = 0; i < NFD; i++){
        
        // Check to make sure it isn't null
        if( running->fd[i] != 0){

            // Check if the name is the same. If it is, put it back
            printf("%s %s\n", running->fd[i]->name, filename);
            if (!strcmp(running->fd[i]->name, filename)){

                // Decrease ref count
                running->fd[i]->refCount--;

                // If the refcount is 0, put the minode back and free the fd
                if(running->fd[i]->refCount == 0){

                    // Put back and deallocate
                    if(running->fd[i]->minodePtr!=0)
                        iput(running->fd[i]->minodePtr);
                        
                    free(running->fd[i]);
                }

                // Set pointer to null.
                running->fd[i] = 0;

                printf("close: Closed fd=%d\n", i);
                n_fd_closed++;
                running->nfd--;
            }
        }
    }

    // If the number of file descriptors closed is greater than 1, return 1. Else return 0;
    printf("close: Closed %d file descriptors\n", n_fd_closed);
    if(n_fd_closed > 0){
        return 1;
    }
    else{
        return 0;
    }
}

// description: Given a filename, this function checks to see if it's associated with any file descriptors and if it is, close it.
int myclosefd(char* fd_string){
 
    // Convert and store argument into an integer
    int target_fd = ToUInt(fd_string);

    // If it can't be converted, return 0;
    if(target_fd == -1){
        printf("closefd: Invalid fd number\n");
        return 0;
    }
    

    // If the target fd isn't null
    if(running->fd[target_fd] != 0){

        // Decrease ref count
        running->fd[target_fd]->refCount--;

        // If the refcount is 0, put the minode back and free the fd
        if(running->fd[target_fd]->refCount == 0){

            // Update minode timestamp
            running->fd[target_fd]->minodePtr->INODE.i_atime = time(0L);
            
            // Put back and deallocate
            iput(running->fd[target_fd]->minodePtr);
            free(running->fd[target_fd]);
        }

        // Set pointer to null.
        running->fd[target_fd] = 0;

        // return when done
        running->nfd--;
        return 1;
    }     

    // if we make it to hear, return 0 since we didn't close anything
    printf("close: Failed to close file fd=%d\n", target_fd);
    return 0;
    
}

// description: sets the offest in the OFT of an opened file descriptor to the byte position either from the file
// beginning or relative to the current position
int mylseek(int fr, int position){
    if (check_invalid_fd(fd)) {
        printf("error: fd not in range\n");
        return -1;
    }

    // check if pointing at OFT entry
    if (running->fd[fd] == NULL) {
        printf("error: not OFT entry\n");
        return -1;
    }

    OFT *oftp = running->fd[fd];
    if (position > oftp->minodePtr->INODE.i_size || position < 0) {
        printf("error: file size overrun\n");
    }

    int original_offset = oftp->offset;
    oftp->offset = position;

    return original_offset;
}

// description: Prints each openned fd in the current running process and their mode
int pfd(){

    // Format print
    printf("Opened file descriptors: \n");
    printf("--------------------------------------------------\n");
    printf("fd\tmode\toffset\tinode\n");

    // For each potential FD openned...
    for (int i = 0; i < NFD; i++){

        // If the fd is initialized...
        if (running->fd[i] != 0){

            // Print fd number
            printf("%d\t", i);

            // Print mode
            switch(running->fd[i]->mode){
                case 0:
                    printf("READ\t");
                    break;
                case 1:
                    printf("WRITE\t");
                    break;
                case 2:
                    printf("RW\t");
                    break;
                case 3:
                    printf("APND\t");
                    break;
                default:
                    printf("ERR\t");
                    break;
            }

            // Print offset
            printf("%d\t", running->fd[i]->offset);

            // Print inode
            printf("[%d %d]\n", running->fd[i]->minodePtr->dev, running->fd[i]->minodePtr->ino);
        }
    }

    // Format print
    printf("--------------------------------------------------\n");

    // Return when done
    return 1;
}
