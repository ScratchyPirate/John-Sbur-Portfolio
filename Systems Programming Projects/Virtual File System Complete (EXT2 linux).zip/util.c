/*********** util.c file ****************/
#include "type.h"



// predefined functions ****
//////////////////////////////////////////
// description: given a file decriptor representing a ext2 filesystem, it finds the data block specified by "blk" and stores the block
//  in "buf". Assumes buf is large enough to hold the data block.
int get_block(int dev, int blk, char *buf)
{
   lseek(dev, (long)blk*BLKSIZE, 0);
   read(dev, buf, BLKSIZE);
}   
// description: given a file decriptor representing an ext2 filesystem, it finds the data block specified by "blk" and stores "buf"
//  into that datablock.
int put_block(int dev, int blk, char *buf)
{
   lseek(dev, (long)blk*BLKSIZE, 0);
   write(dev, buf, BLKSIZE);
}   
// description: given a pathname in the format a/b/c, this takes each token and stores it in the global variable "name" and updates 
//  global variable "n" to be equal to the number of tokens stored. Sets name[n] to be 0 after for easier user traversal as not
//  name can be used in a sentinel-controlled loop. Assumes pathname is formatted to be a c string.
int tokenize(char *pathname)
{
  int i;
  char *s;
  //printf("tokenize %s\n", pathname);

  strcpy(gpath, pathname);   // tokens are in global gpath[ ]
  n = 0;

  s = strtok(gpath, "/");
  while(s){
    name[n] = s;
    n++;
    s = strtok(0, "/");
  }
  name[n] = 0;
  
  for (i= 0; i<n; i++)
    //printf("%s  ", name[i]);
  printf("\n");
}
// description: given a file decriptor representing an ext2 filesystem, it searches for the inode number "ino" and stores it into a 
//  memory inode. The address of the new memory inode is then returned. If no more minodes can be allocated, 0 is returned and the
//  minode is never loaded into memory.
MINODE *iget(int dev, int ino)
{
  int i;
  MINODE *mip;
  char buf[BLKSIZE];
  int blk, offset;
  INODE *ip;

  for (i=0; i<NMINODE; i++){
    mip = &minode[i];
    if (mip->refCount && mip->dev == dev && mip->ino == ino){
       mip->refCount++;
       //printf("found [%d %d] as minode[%d] in core\n", dev, ino, i);
       return mip;
    }
  }
    
  for (i=0; i<NMINODE; i++){
    mip = &minode[i];
    if (mip->refCount == 0){
       //printf("allocating NEW minode[%d] for [%d %d]\n", i, dev, ino);
       mip->refCount = 1;
       mip->dev = dev;
       mip->ino = ino;
       mip->mounted = 0;

       // get INODE of ino to buf    
       blk    = (ino-1)/8 + iblk;
       offset = (ino-1) % 8;

       //printf("iget: ino=%d blk=%d offset=%d\n", ino, blk, offset);

       get_block(dev, blk, buf);
       ip = (INODE *)buf + offset;
       // copy INODE to mp->INODE
       mip->INODE = *ip;
       return mip;
    }
  }   
  printf("PANIC: no more free minodes\n");
  return 0;
}
// description: given an minode "mip" that is dirty and has a reference count greater than 0, this stores the minode back into the 
//  filesystem if it's allocated.
// --if ref count == 0 or "mip" isn't dirty, the function exits early.
void iput(MINODE *mip)
{
 int i, block, offset;
 INODE *ip;

 if (mip==0) 
     return;

 mip->refCount--;
 
 if (mip->refCount > 0) return;
 if (!mip->dirty)       return;
 
 // Write MIP back into disk
  // Get block information
  block = (mip->ino - 1)/8 + iblk;
  offset = (mip->ino - 1)%8;

  // Get block itself into a buffer and ipusing block information
  char local_buf[BLKSIZE];
  get_block(mip->dev, block, local_buf);
  ip = (INODE*)local_buf + offset;

  // copy inode inside mip to ip
  memcpy(ip, &(mip->INODE), sizeof(INODE));

  // Write back to disk
  put_block(mip->dev, block, local_buf);

  // Decallocate memory inode since we are done using it
  midalloc(mip);
  mip = 0;
} 
// decription: given a memory inode "mip" and a string "name", this function looks within the directories of "mip"'s first datablock
//  for an inode matching that name. 
// returns: inode number if found
//          0 if not found.
int search(MINODE *mip, char *name)
{
   int i; 
   char *cp, c, sbuf[BLKSIZE], temp[256];
   DIR *dp;
   INODE *ip;

   //printf("search for %s in MINODE = [%d, %d]\n", name,mip->dev,mip->ino);
   ip = &(mip->INODE);

   /*** search for name in mip's data blocks: ASSUME i_block[0] ONLY ***/

   get_block(mip->dev, ip->i_block[0], sbuf);
   dp = (DIR *)sbuf;
   cp = sbuf;
   //printf("  ino   rlen  nlen  name\n");

   while (cp < sbuf + BLKSIZE){
     strncpy(temp, dp->name, dp->name_len);
     temp[dp->name_len] = 0;
     //printf("%4d  %4d  %4d    %s\n", dp->inode, dp->rec_len, dp->name_len, dp->name);
     if (strcmp(temp, name)==0){
       //printf("found %s : ino = %d\n", temp, dp->inode);
        return dp->inode;
     }
     cp += dp->rec_len;
     dp = (DIR *)cp;
   }
   return 0;
}
// description: given a pathname, this function searches within the openned cwd or root depending on the entered pathname for the basename
//  of the path.
// returns: 0 if not found
//          inode number of found.
int getino(char *pathname)
{
  int i, ino, blk, offset;
  char buf[BLKSIZE];
  INODE *ip;
  MINODE *mip;

  //printf("getino: pathname=%s\n", pathname);
  if (strcmp(pathname, "/")==0)
      return 2;
  
  // starting mip = root OR CWD
  if (pathname[0]=='/')
     mip = iget(running->cwd->dev, 2);
  else
     mip = iget(running->cwd->dev, running->cwd->ino);
  
  tokenize(pathname);

  for (i=0; i<n; i++){
    //printf("===========================================\n");
      //printf("getino: i=%d name[%d]=%s\n", i, i, name[i]);
 
      ino = search(mip, name[i]);

      if (ino==0){
         iput(mip);
         //printf("name %s does not exist\n", name[i]);
         return 0;
      }
      int mip_is_mounted = mip->mounted;
      int mip_dev = mip->dev;
      iput(mip);

      // If mip is mounted, search for its mount and use that mip. Otherwise, proceed like normal
      if (mip_is_mounted){

        mip = i_get_from_mount(mip);

        // Update ino to match mount's ino.
        ino = mip->ino;
      }
      else{
        mip = iget(mip_dev, ino);
      }

      // Check if we have permission to access mip. If we don't, return 0. Check this only if it is a directory
      if (S_ISDIR(mip->INODE.i_mode)){
        if (!access(mip, 'r') || !access(mip, 'x')){
          printf("getino: Current user '%d' doesn't have permission to access directory '%s'\n", running->uid, name[i]);
          return 0;
        }
      }
   }

    // If the final mip is mounted, we still need to check if we are exiting or entering a mount.
    if (mip->mounted == 1){
      mip = i_get_from_mount(mip);
      ino = mip->ino;
    }

    // Check if we have permission to access mip. If we don't, return 0. Check this only if it is a directory
      if (S_ISDIR(mip->INODE.i_mode)){
        if (!access(mip, 'r') || !access(mip, 'x')){
          printf("getino: Current user '%d' doesn't have permission to access directory '%s'\n", running->uid, name[i]);
          return 0;
        }
      }

  // Update global to indicate last accessed dev in getino;
  getino_dev = mip->dev;

   iput(mip);
   return ino;
}
//////////////////////////////////////////
// end predefined functions



// Project defined functions:
//////////////////////////////////////////

// description: sets destination variabel pointer as bthe asename of path (format "a/b/c" will set destination to "c")
// --precondition, path is a string and destination can hold basename
// --if only the basename exists, destination is set to path's contents.
void mybasename(char* path, char* destination){

  //printf("mybasename: path=%s\n", path);

  // look for '/' character and return basename from that
  for(int i = strlen(path)-1 ;i>=0 ;i--){

    // if we encounter it, set destination equal to everything after '/'
    if (path[i] == '/' && i != strlen(path)-1){
      strcpy(destination, &path[i+1]);
      //printf("mybasename: base=%s\n", destination);
      return;
    }
  }

  // if not encountered, the string is the entire basename, so copy and return
  strcpy(destination, path);
  //printf("mybasename: base=%s\n", destination);
  return;
}

// description: sets destination as directory path to the non basename tokens (format "a/b/c" will set destination to "a/b")
// --precondition, path is a string and destination can hold the dirname.
// --if only the basename exists, dirname is set to the empty string
void mydirname(char* path, char* destination){

  //printf("mydirname: path=%s\n", path);
  
  // look for '/' character and return basename from that
  for(int i = strlen(path)-1 ;i>=0 ;i--){

    // if we encounter it, set destination equal to everything before '/'
    if (path[i] == '/' && i != strlen(path)-1){
      strncpy(destination, path, i);
      //printf("mydirname: dir=%s\n", destination);
      return;
    }
  }

  // if not encountered, no dirname. set destination[o] to null
  destination[0] = '\0';
  return;
}

// description: finds the inode with number "myino" within the minode's first datablock, datablock[0]. changes "myname" into the name of "myino".
// --returns:
//  0 if not found
//  1 if found
// --if not found, "myname" is left unchanged.
int findmyname(MINODE *parent, u32 myino, char myname[ ]) 
{
  //local variables used here
  int i; 
  char *cp, c, sbuf[BLKSIZE], temp[256];
  DIR *dp;
  INODE *ip;

  //printf("search for ino %d in MINODE = [%d, %d]\n", myino,parent->dev,parent->ino);
  ip = &(parent->INODE);

  /*** search for name in mip's data blocks: assumed to be within i_block[0]  ***/

  // Get datablock 0 and set dir to being the datablock's address.
  get_block(running->cwd->dev, ip->i_block[0], sbuf);
  dp = (DIR *)sbuf;
  cp = sbuf;

  // Debug formatting
  //printf("  ino   rlen  nlen  name\n");

  // Search through datablock 0 my incrementing to each directory by the previous directory's reclen
  while (cp < sbuf + BLKSIZE){

    // Store name of current directory in temp
    strncpy(temp, dp->name, dp->name_len);
    temp[dp->name_len] = 0;

    // Debug print dp information.
    //printf("%4d  %4d  %4d    %s\n",  dp->inode, dp->rec_len, dp->name_len, dp->name);

    // If the current inode is the same as our target, set "myname" equal to temp and return 1.
    if (dp->inode == myino){

      // Debug let user know the inode target was found
       //printf("found ino %d : name = %s\n", myino, temp);

	    strcpy(myname, temp);
      return 1;
    }

    // Increment to next directory
    cp += dp->rec_len;
    dp = (DIR *)cp;
  }

  // If not found, return 0.
  return 0;
}

// description: given an inputted MINODE, it finds its own inode number and its parent's inode number. Then it sets "myino" to its own inode number
//  and it returns its parent's inode number
// --if either are not found, "myino" is left unchanged and 0 is returned.
int findino(MINODE *mip, u32 *myino) // myino = i# of . return i# of ..
{
  // mip points at a DIR minode
  // WRITE your code here: myino = ino of .  return ino of ..
  // all in i_block[0] of this DIR INODE.

  // look for both ino within parent
  int dotino = search(mip, ".");
  int twodotino = search(mip, "..");

  // if not found in either, return
  if(dotino == 0 || twodotino == 0) {
    printf("findino: Error. inodes not found\n");
    return 0;
  }

  // return both directly or indirectly
  *myino = dotino;
  return twodotino;
}

// description: given a buffer of bytes, this algorithm searches for the target bit number within buf and returns whether it is a 1 or 0. For example,
//  target_bit = 1000, so it looks in byte number 1000/8 at position 1000%8 within that byte and returns its value.
//  Assumes target_bit is within the size of buf.
int tst_bit(char* buf, int target_bit){
  if (buf[target_bit/8] & 1 << (target_bit%8))
    return 1;
  else  
    return 0;
}

// description: given a buffer of bytes, this algorithm searches for the target bit number within buf and sets the bit to 1.
//  Assumes target_bit is within the size of buf.
//  Returns 1 when complete.
int set_bit(char* buf, int target_bit){
  buf[target_bit/8] |= (1 << (target_bit%8));
  return 1;
}

// description: given a buffer of bytes, this algorithm searches for the target bit number within buf and sets the bit to 0.
//  Assumes target_bit is within the size of buf.
//  Returns 1 when complete.
int clr_bit(char* buf, int target_bit){
  buf[target_bit/8] &= ~(1 << (target_bit%8));
  return 1;
}

// description; given a memory inode, this function determines if it is a directory inode or a non-directory inode.
// returns: 1 if it is a directory
//          0 if it isn't a directory 
int is_dir(MINODE* mip){
  return S_ISDIR(mip->INODE.i_mode);
}

// description: given a buffer of size BLKSIZE, this function sets all values to 0.
void mybzero(char* local_buf){
  for(int i = 0; i < BLKSIZE; i++){
    local_buf[i] = 0;
  }
}

// description: Given a memory inode, this function prints each of that inode's blocks.
void print_mip_blocks(MINODE* mip){

  // local buffer
  char buf2[BLKSIZE];

  // Print direct blocks
  printf("================ Direct Blocks ===================\n");
  for(int i=0; i<12;i++)printf("%2d ", mip->INODE.i_block[i]);
    printf("\n");

  // Print indirect blocks if they exist. Store incoming data in buf2;
  if (mip->INODE.i_block[12]){
      printf("===============  Indirect blocks   ===============\n");
      // Get i_block pointer from i_block[12]
      get_block(fd, mip->INODE.i_block[12], buf2);
      int* arr = (int*)buf2;

      // Print each block each indirect block points to.
      for(int i = 0; i < 256; i++){
        if(arr[i])
          printf("%2d ", arr[i]);
        else{
          i = 256;
        }
      }
    printf("\n");
  }

  // Print doubly indirect blocks if they exist. Store incoming data inside of buf2 and buf3
  char buf3[1024];
   if (mip->INODE.i_block[13]){
     printf("===========  Double Indirect blocks   ============\n");

     // Reset buf2
     buf2[0] = 0;
     
     // Get double indirect block and cast it
     get_block(fd, mip->INODE.i_block[13], buf2);
     int* arr = (int*)buf2;

     //for(int i = 0; i < 256;i++){printf("%d\n", arr[i]);return 0;}

     // Loop and print each indirect block in the double indirect block
      for(int i = 0; i < 256; i++){

	   // Get indirect block and cast it
	   get_block(fd, arr[i], buf3);
	   int* arr2 = (int*)buf3;

	   // If not empty, look for blocks
	   if(arr2[0]){
	     //printf("i=%d\n", i);
	     for(int j = 0; j < 256;j++){

	       // print values in block
	       if(arr2[j])
		 printf("%2d ", arr2[j]);
	       else
		 j = 256;
	     }
	   }
	   else{
	     i = 256;
	   }
	   
      }
      printf("\n");
   }
}

// description: prints out the project name, contributors, and other information intended to be printed at the start of the program.
void print_start_screen(){

  printf("*****************************************************\n");
  printf("*             EXT2 FILESYSTEM PROJECT               *\n");
  printf("*                                                   *\n");
  printf("*                                                   *\n");
  printf("* Contributors: John Sbur, Denis Anzora             *\n");
  printf("* Class: WSU Cpts360                                *\n");
  printf("*                                                   *\n");
  printf("*****************************************************\n");

}

// description: Given an inputted string, this function attempts to turn it into an unsigned integer and return it. 
//  returns -1 if it cannot convert to an integer
int ToUInt(char* string){

  // Locals
  int holder = 0;

  for (int i = 0; *(string+i) != '\0'; i++)
  {
    // If it's a digit, add it to the number. Otherwise return.
    if(*(string+i) <= '9' && *(string+i) >= '0'){
      holder *= 10;
      holder += (int)*(string+i) - (int)'0';
    }
    else{
      return -1;
    }
  }

  return holder;
}

// description: Used for switching between mounts and the system root.
// given a mip and dev number, 
// Travelling downward: If the mip is mounted, we look based on the minode's dev, and 
//    root of the mount. (Switch from main filesystem to mount filesystem).
// Travelling upwards: This case only happens if the root is involved and for that, we 
//  check if the mip's inode is 2. If it is, we get the minode above the mount's root
//  and return it.
// If any of these operations fail, the original mip is returned.
MINODE* i_get_from_mount(MINODE* mip){

  // Locals
  int target_mount = -1;

  // Downward traversal case
  if (mip->mounted == 1){

    // Get the mount's dev number. If can't be found, return mip
    int mount_dev = -1;
    for (int i = 0; i < NMNT; i++){
      if (mountTable[i].mounted_minode == mip){
        mount_dev = mountTable[i].dev;
      }
    }
    if (mount_dev == -1){
      return mip;
    }

    iput(mip);

    // Return root of dev.
    return iget(mount_dev, 2);
  }

  // Upward traversal case
  else if (mip->ino == 2){

    // Get the inode of the mountTable entry associated with this mip
    MOUNT* current_mount = getmptr(mip->dev);

    // If the mount was pulled successfully continue. Otherwise, return.
    if (current_mount == NULL){
      return mip;
    }

    iput(mip);

    // Get the minode of the mount from the original disk.
    return iget(mountTable[0].dev, current_mount->mounted_minode->ino);
  }

  // If we've reached this point, just return the original mip.
  return mip;
}

// Etc.
////////////////////////////////////////////////////////////////////
//searched file or dir from ino
int search_by_ino(int dev, int ino, INODE *ip, char* temp)
{
    int i;
    char *cp;
    DIR *dp;
    char buf[BLKSIZE];

    for(i = 0; i < 12; i++)
    {
        if(ip->i_block[i] == 0){ break;}
        get_block(dev, ip->i_block[i], buf);
        dp = (DIR *)buf;
        cp = buf;

        while(cp < buf+BLKSIZE)
        {
            if(ino == dp->inode)
            {
                strncpy(temp, dp->name, dp->name_len);
                return 1;
            }
            cp += dp->rec_len;
            dp = (DIR*)cp;
        }
    }
    return 0;
}
int rm_child(MINODE *pip, char *child)
{
    int i, size, found = 0;
    char *cp, *cp2;
    DIR *dp, *dp2, *dpPrev;
    char buf[BLKSIZE], buf2[BLKSIZE], temp[256];

    memset(buf2, 0, BLKSIZE);
    //check direct
    for(i = 0; i < 12; i++)
    {
        if(pip->INODE.i_block[i] == 0) { return 0; }
        //load to mem
        get_block(pip->dev, pip->INODE.i_block[i], buf);
        dp = (DIR *)buf;
        dp2 = (DIR *)buf;
        dpPrev = (DIR *)buf;
        cp = buf;
        cp2 = buf;

        while(cp < buf+BLKSIZE && !found)
        {
            memset(temp, 0, 256);
            strncpy(temp, dp->name, dp->name_len);
            if(strcmp(child, temp) == 0)
            {
                //if only child
                if(cp == buf && dp->rec_len == BLKSIZE)
                {
                    //deallocate
                    bdalloc(pip->dev, pip->INODE.i_block[i]);
                    pip->INODE.i_block[i] = 0;
                    pip->INODE.i_blocks--;
                    found = 1;
                }
                    //else delete child
                else
                {
                    while((dp2->rec_len + cp2) < buf+BLKSIZE)
                    {
                        dpPrev = dp2;
                        cp2 += dp2->rec_len;
                        dp2 = (DIR*)cp2;
                    }
                    if(dp2 == dp)
                    {
                        dpPrev->rec_len += dp->rec_len;
                        found = 1;
                    }
                    else
                    {
                        size = ((buf + BLKSIZE) - (cp + dp->rec_len));
                        dp2->rec_len += dp->rec_len;
                        //copy
                        memmove(cp, (cp + dp->rec_len), size);
                        dpPrev = (DIR*)cp;
                        memset(temp, 0, 256);
                        strncpy(temp, dpPrev->name, dpPrev->name_len);
                        found = 1;
                    }
                }
            }
            cp += dp->rec_len;
            dp = (DIR*)cp;
        }
        if(found)
        {
            //putback to disk
            put_block(pip->dev, pip->INODE.i_block[i], buf);
            return 1;
        }
    }
    return -1;
}
int rm(MINODE *mip)
{
    int i, j;
    int buf[256], buf2[256];

    if(!S_ISLNK(mip->INODE.i_mode))
    {
        for(i = 0; i < 12; i++)
        {
            if(mip->INODE.i_block[i] != 0)
            {
                //deallocate block
                bdalloc(mip->dev, mip->INODE.i_block[i]);
            }
        }
        if(mip->INODE.i_block[12] != 0)
        {
            memset(buf, 0, 256);
            get_block(mip->dev, mip->INODE.i_block[12], (char*)buf);
            for(i = 0; i < 256; i++)
            {
                if(buf[i] != 0) {bdalloc(mip->dev, buf[i]);}
            }
            bdalloc(mip->dev, mip->INODE.i_block[12]);
        }
        if(mip->INODE.i_block[13] != 0)
        {
            memset(buf, 0, 256);
            get_block(mip->dev, mip->INODE.i_block[13], (char*)buf);
            for(i = 0; i < 256; i++)
            {
                if(buf[i] != 0)
                {
                    memset(buf2, 0, 256);
                    get_block(mip->dev, buf[i], (char*)buf2);
                    for(j = 0; j < 256; j++)
                    {
                        if(buf2[j] != 0) {bdalloc(mip->dev, buf2[j]);}
                    }
                    bdalloc(mip->dev, buf[i]);
                }
            }
            bdalloc(mip->dev, mip->INODE.i_block[13]);
        }
    }
    //finally ino
    idalloc(mip->dev, mip->ino);
    return 1;
}
//addlast of minode
int add_last_block(MINODE *pip, int bnumber)
{
    int buf[256];
    int buf2[256];
    int i, j, newBlk, newBlk2;
    for(i = 0; i < 12; i++) //direct
    {
        if(pip->INODE.i_block[i] == 0) {pip->INODE.i_block[i] = bnumber; return 1;}
    }
    //indirect
    if(pip->INODE.i_block[12] == 0)
    {
        newBlk = balloc(pip->dev);
        pip->INODE.i_block[12] = newBlk;
        memset(buf, 0, 256);
        get_block(pip->dev, newBlk, (char*)buf);
        buf[0] = bnumber;
        put_block(pip->dev, newBlk, (char*)buf);
        return 1;
    }
    memset(buf, 0, 256);
    get_block(pip->dev, pip->INODE.i_block[12], (char*)buf);
    for(i = 0; i < 256; i++)
    {
        if(buf[i] == 0) {buf[i] = bnumber; return 1;}
    }
    //double indirect
    if(pip->INODE.i_block[13] == 0)
    {
        newBlk = balloc(pip->dev);
        pip->INODE.i_block[13] = newBlk;
        memset(buf, 0, 256);
        get_block(pip->dev, newBlk, (char*)buf);
        newBlk2 = balloc(pip->dev);
        buf[0] = newBlk2;
        put_block(pip->dev, newBlk, (char*)buf);
        memset(buf2, 0, 256);
        get_block(pip->dev, newBlk2, (char*)buf2);
        buf2[0] = bnumber;
        put_block(pip->dev, newBlk2, (char*)buf2);
        return 1;
    }
    memset(buf, 0, 256);
    get_block(pip->dev, pip->INODE.i_block[13], (char*)buf);
    for(i = 0; i < 256; i++)
    {
        if(buf[i] == 0)
        {
            newBlk2 = balloc(pip->dev);
            buf[i] = newBlk2;
            put_block(pip->dev, pip->INODE.i_block[13], (char*)buf);
            memset(buf2, 0, 256);
            get_block(pip->dev, newBlk2, (char*)buf2);
            buf2[0] = bnumber;
            put_block(pip->dev, newBlk2, (char*)buf2);
            return 1;
        }
        memset(buf2, 0, 256);
        get_block(pip->dev, buf[i], (char*)buf2);
        for(j = 0; j < 256; j++)
        {
            if(buf2[j] == 0) {buf2[j] = bnumber; return 1;}
        }
    }
    printf("Failed block to node\n");
    return -1;
}
// function to find the last minode
int find_last_block(MINODE *pip)
{
    int buf[256];
    int buf2[256];
    int bnumber, i, j;

    if(pip->INODE.i_block[0] == 0) {return 0;}
    //direct
    for(i = 0; i < 12; i++)
    {
        if(pip->INODE.i_block[i] == 0)
        {
            return (pip->INODE.i_block[i-1]);
        }
    }
    if(pip->INODE.i_block[12] == 0) {return pip->INODE.i_block[i-1];}
    //check indirect
    get_block(dev, pip->INODE.i_block[12], (char*)buf);
    for(i = 0; i < 256; i++)
    {
        //look for the free blocks
        if(buf[i] == 0) {return buf[i-1];}
    }
    //check double indirect
    if(pip->INODE.i_block[13] == 0) {return buf[i-1];}
    memset(buf, 0, 256);
    get_block(pip->dev, pip->INODE.i_block[13], (char*)buf);
    for(i = 0; i < 256; i++)
    {
        if(buf[i] == 0) {return buf2[j-1];}
        if(buf[i])
        {
            get_block(pip->dev, buf[i], (char*)buf2);
            for(j = 0; j < 256; j++)
            {
                if(buf2[j] == 0) {return buf2[j-1];}
            }
        }
    }
}
int split_paths(char *original, char *path1, char *path2)
{
  //split space
    char *temp;
    temp = strtok(original, " ");
    strcpy(path1, temp);
    temp = strtok(NULL, " ");
    if(temp == NULL)
    {
        return -1;
    }
    strcpy(path2, temp);
    return 1;
}
int enter_name(MINODE *pip, int myino, char *myname)
{
    char buf[BLKSIZE], *cp;
    int bno;
    INODE *ip;
    DIR *dp;

    int need_len = 4 * ((8 + strlen(myname) + 3) / 4); //ideal length of entry

    ip = &pip->INODE; // get the inode

    for (int i = 0; i < 12; i++)
    {

        if (ip->i_block[i] == 0)
        {
            break;
        }

        bno = ip->i_block[i];
        get_block(pip->dev, ip->i_block[i], buf); // get the block
        dp = (DIR *)buf;
        cp = buf;

        while (cp + dp->rec_len < buf + BLKSIZE) // Going to last entry of the block
        {
            //printf("%s\n", dp->name);
            cp += dp->rec_len;
            dp = (DIR *)cp;
        }

        // at last entry
        int ideal_len = 4 * ((8 + dp->name_len + 3) / 4); // ideal len of the name
        int remainder = dp->rec_len - ideal_len;          // remaining space

        if (remainder >= need_len)
        {                            // space available for new netry
            dp->rec_len = ideal_len; //trim current entry to ideal len
            cp += dp->rec_len;       // advance to end
            dp = (DIR *)cp;          // point to new open entry space

            dp->inode = myino;             // add the inode
            strcpy(dp->name, myname);      // add the name
            dp->name_len = strlen(myname); // len of name
            dp->rec_len = remainder;       // size of the record

            put_block(dev, bno, buf); // save block
            return 0;
        }
        else
        {                         // not enough space in block
            ip->i_size = BLKSIZE; // size is new block
            bno = balloc(dev);    // allocate new block
            ip->i_block[i] = bno; // add the block to the list
            pip->dirty = 1;       // ino is changed so make dirty

            get_block(dev, bno, buf); // get the blcok from memory
            dp = (DIR *)buf;
            cp = buf;

            dp->name_len = strlen(myname); // add name len
            strcpy(dp->name, myname);      // name
            dp->inode = myino;             // inode
            dp->rec_len = BLKSIZE;         // only entry so full size

            put_block(dev, bno, buf); //save
            return 1;
        }
    }
}
// use inodes in block, go to address, free them (memset),
int inode_truncate(MINODE *mip) {
    char buf[BLKSIZE];
    INODE *ip = &mip->INODE;
    // 12 direct blocks
    for (int i = 0; i < 12; i++) {
        if (ip->i_block[i] == 0)
            break;
        // deallocate block
        bdalloc(dev, ip->i_block[i]);
        ip->i_block[i] = 0;
    }
    // indirect blocks:
    if (ip->i_block[12] != NULL) {
        get_block(dev, ip->i_block[12], buf); // follow the ptr to the block
        int *ip_indirect = (int *)buf; // reference to indirect block with integer ptr
        int indirect_count = 0;
        while (indirect_count < BLKSIZE / sizeof(int)) { // split blksize into int sized chunks (4 bytes at a time)
            if (ip_indirect[indirect_count] == 0)
                break;
            // deallocate indirect block
            bdalloc(dev, ip_indirect[indirect_count]);
            ip_indirect[indirect_count] = 0;
            indirect_count++;
        }
        // indirect block dealt with, deallocate reference to indirect
        bdalloc(dev, ip->i_block[12]);
        ip->i_block[12] = 0;
    }

    // doubly indirect blocks (same code as above, different variables):
    if (ip->i_block[13] != NULL) {
        get_block(dev, ip->i_block[13], buf);
        int *ip_doubly_indirect = (int *)buf;
        int doubly_indirect_count = 0;
        while (doubly_indirect_count < BLKSIZE / sizeof(int)) {
            if (ip_doubly_indirect[doubly_indirect_count] == 0)
                break;
            // deallocate doubly indirect block
            bdalloc(dev, ip_doubly_indirect[doubly_indirect_count]);
            ip_doubly_indirect[doubly_indirect_count] = 0;
            doubly_indirect_count++;
        }
        bdalloc(dev, ip->i_block[13]);
        ip->i_block[13] = 0;
    }

    mip->INODE.i_blocks = 0;
    mip->INODE.i_size = 0;
    mip->dirty = 1;
    iput(mip);
}

// description: unlike tokenize, this takes inputs to the left of command in the form "a b c" and stores them as tokens
//  token[0] = "a";
//  token[1] = "b";
//  token[2] = "c";
//  n_tokens is update to match the number of tokens stored.
void tokenize_inputs(){
  int i;
  char *s;
  //printf("tokenize %s\n", pathname);

  strcpy(gpath, pathname);   // tokens are in global gpath[ ]
  n_tokens = 0;

  s = strtok(gpath, " ");
  while(s){
    tokens[n_tokens] = (char*)malloc(sizeof(strlen(s) + 1));
    strcpy(tokens[n_tokens], s);
    n_tokens++;
    s = strtok(0, " ");
  }
  tokens[n_tokens] = 0;
  
  //for (i= 0; i<n_tokens; i++)
    //printf("%s  ", tokens[i]);
  printf("\n");
}
////////////////////////////////////////////////////////////////////

// Debug functions
// description: Used for printing data inside buffers or directories.
void print_dir(char buf[BLKSIZE], DIR*dp){
  char temp[64];
  strncpy(temp, dp->name, dp->name_len);
  temp[dp->name_len] = 0;
  printf("name = %s\t", temp);
  printf("ino# = %d\t", dp->inode);
  printf("rec_len = %d\t", dp->rec_len);
  printf("name_len = %d\t", dp->name_len);
  printf("file type = %d\t", dp->file_type);
  printf("offset = %ld\t", (char*)dp - buf);
  printf("remaining space = %ld\n", buf+BLKSIZE-((char*)dp+dp->rec_len));
}
void print_block(MINODE*pip, int block){
  char buf[BLKSIZE];
  get_block(pip->dev, block, buf);
  char*cp=buf;
  DIR*dp =buf;
  while(cp<buf+BLKSIZE){
    print_dir(buf, dp);
    cp+=dp->rec_len;
    dp = (DIR*)cp;
  }
  printf("\n");
}
void print_buf(char buf[BLKSIZE]){
  printf("printing current buffer: \n");
  char*cp = buf;
  DIR*dp = (DIR*)buf;
  while(cp+dp->rec_len<buf+BLKSIZE){
    print_dir(buf, dp);
    cp+=dp->rec_len;
    dp = (DIR*)cp;
  }
  print_dir(buf, dp);
  printf("\n");
}
// end debug functions.