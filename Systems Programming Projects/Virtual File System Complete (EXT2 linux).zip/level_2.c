/************* level_2.c file **************/
#include "type.h"



// Major Level 2 commands are in their respective files


// Minor Level 2 commands

// description: function helper for mylseek to check if is invalid fd
int check_invalid_fd(int fd) {
    return (fd < 0 || fd > (NFD-1));
}

// description: Moves an inputted file from one location to another.
int mymv(char* source, char* destination){
    MINODE *mip;
    char temp[256];
    int fd;

    strcpy(temp, source);

  fd = myopen(source, 0);
    
    if(fd < 0)
    {
        printf("Source file does not exist\n");
        return -1;
    }

    mip = running->fd[fd]->minodePtr;
    update_globals(running->fd[fd]->minodePtr->dev);

    if(mip->dev == dev)
    {
        mylink(source, destination);
        myunlink(temp);
        myclose(fd);
        //printf("link count: %d\n", mip->refCount);
        mip->dirty = 1;
        iput(mip);
        update_globals(running->cwd->dev);
        return 1;
    }
    else
    {
        mycp(source, destination);
        myunlink(source);
        update_globals(running->cwd->dev);

    }
}

// description: Prints the contents of the inputted buffer one at a time. Assumes buffer is of size BLKSIZE
int peakbuffer(char* buf){

    // If buffer is empty, return
    if (buf == 0){
        printf("peak: Buffer empty\n");
        return 0;
    }

    // Print contents of buffer
    int i = 0;
    while(i < BLKSIZE){
        printf("%c", buf[i]);
        i++;
    }
    printf("\n");

    // Return when done;
    return 1;

}

// description: prints a funny pikachu to the screen
int bebeeb(){

    printf("quu..__\n");
    printf(" $$$b  `---.__\n");
    printf("  '$$b        `--.                          ___.---uuudP\n");
    printf("   `$$b           `.__.------.__     __.---'      $$$$'              .\n");
    printf("     '$b          -'            `-.-'            $$$'              .'|\n");
    printf("       .                                       d$'             _.'  |\n");
    printf("         `.   /                              ...'             .'     |\n");
    printf("           `./                           ..::-'            _.'       |\n");
    printf("            /                         .:::-'            .-'         .'\n");
    printf("           :                          ::''\          _.'            |\n");
    printf("          .' .-.             .-.           `.      .'               |\n");
    printf("          : /'$$|           .@'$\           `.   .'              _.-'\n");
    printf("         .'|$u$$|          |$$,$$|           |  <            _.-'\n");
    printf("         | `:$$:'          :$$$$$:           `.  `.       .-'\n");
    printf("         :                  `'--'             |    `-.     \ \n");
    printf("        :##.       ==             .###.       `.      `.    `\ \n");
    printf("        |##:                      :###:        |        >     >\n");
    printf("        |#'     `..'`..'          `###'        x:      /     /\n");
    printf("         \                                   xXX|     /    ./\n");
    printf("          \                                xXXX'|    /   ./\n");
    printf("          /`-.                                  `.  /   /\n");
    printf("         :    `-  ...........,                   | /  .'\n");
    printf("         |         ``:::::::'       .            |<    `.\n");
    printf("         |             ```          |           x| \ `.:``.\n");
    printf("         |                         .'    /'   xXX|  `:`M`M':.\n");
    printf("         |    |                    ;    /:' xXXX'|  -'MMMMM:'\n");
    printf("         `.  .'                   :    /:'       |-'MMMM.-'\n");
    printf("          |  |                   .'   /'        .'MMM.-'\n");
    printf("          `'`'                   :  ,'          |MMM<\n");
    printf("            |                     `'            |tbap\ \n");
    printf("             \                                  :MM.-'\n");
    printf("              \                 |              .''\n");
    printf("               \.               `.            /\n");
    printf("                /     .:::::::.. :           /\n");
    printf("               |     .:::::::::::`.         /\n");
    printf("               |   .:::------------\       /\n");
    printf("              /   .''               >::'  /\n");
    printf("              `',:                 :    .'\n");
    printf("                                   `:.:' \n");

    return 1;

}

// description: Prints all commands implemented in level 2
int help_level_2(){
    printf("\n\nLevel 2 Commands:\n");
    printf("\t'open' \t\t-This tries to open a specified file with flags either RD(Read), WR(Write), RW(Read Write), or AP(Append)\n");
    printf("\t'closefile'\t-Tries to close a file according to the file name specified if it is open.\n");
    printf("\t'close'\t\t-Tries to close a file according to an inputted fd if it is open.\n");
    printf("\t'read'\t\t-Tries to read from an inputted file descriptor into the global buffer. Works only if the file is openned for read\n");
    printf("\t'write'\t\t-Tries to write the contents of the current buffer up to the bytes specified to the file descriptor entered. \n\t\t\tWorks only if the file is openned for write\n");
    printf("\t'writeline'\t-Tries to write a line inputted by the user to the specified file descriptor. Works only if the file is openned for write\n");
    printf("\t'cat'\t\t-Tries to concatenate the contents of the file specified to the console\n");
    printf("\t'cp'\t\t-Tries to copy the contents of the first filepath token into the second filepath token\n");
    printf("\t'lseek'\t\t-Sets the offest in the OFT of an opened file descriptor to the byte position\n");
    printf("\t'mv'\t\t-Moves a file from one location to another\n");
    printf("\t'pfd'\t\t-Prints out all openned file descriptors in the current file system and their properties\n");
    printf("\t'peak'\t\t-Prints the current contents of the global buffer to the screen unorganized\n");
}