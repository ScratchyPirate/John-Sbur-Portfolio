/************* rmdir.c file **************/
#include "type.h"


// description: Using the local variable "pathname", this function tries to remove a directory within an inputted directory or the cwd.
// returns: 1 when successful
//          0 when unsuccessful
// If this would remove root, it instead exits
int myrmdir(char* pathname){
    
    // Locals
    char local_buf[BLKSIZE];
    
    // 1) Separate basename and dirname
    // storage for names and other locals
    int ino = 0;
    MINODE* mip = NULL;

    printf("dir:%s\n", pathname);

    // Different cases
    // Case 1, pathname is empty, immediately return
    if(!strcmp(pathname, "")){
        printf("rmdir: Base is empty!\n");
        return 0;
    }
    // Case 2, pathname is not empty, (use path)
    else{
        ino = getino(pathname);

        if (ino == 0){
            printf("rmdir: Failed to find parent\n");
            return 0;
        }
        mip = iget(getino_dev, ino);
    }

    // 2) Verify existence of directory
    //  Make sure the inode is a directory. If not, exit.
    if(!is_dir(mip)){
        printf("rmdir: Path %s is not a directory\n", pathname);
        iput(mip);
        return 0;
    }

    // 3) Make sure directory to be removed isn't busy
    if(mip->refCount > 1){
        printf("rmdir: Target directory is busy and cannot be removed\n");
        iput(mip);
        return 0;
    }

    // 5) If the base is '.' or '..' and the parent is root, immediately return. If it is ".." or ".", also return
    if((!strcmp(pathname, ".") || !strcmp(pathname, "..")) || mip->ino == root->ino){
        printf("rmdir: Cannot remove parent or self from the filesystem\n");
        iput(mip);
        return 0;
    }

    // 6) Verify directory is empty
    get_block(mip->dev, mip->INODE.i_block[0], local_buf);
    char*cp=local_buf;
    DIR*dp =local_buf;
    while(cp<local_buf+BLKSIZE){

        // Load in name of entry
        char temp[64];
        strncpy(temp, dp->name, dp->name_len);
        temp[dp->name_len] = 0;

        // If the entry's name isn't "." or "..", the directory isn't empty. We return from here.
        if(strcmp(temp, ".") && strcmp(temp, "..")){
            printf("rmdir: Target directory isn't empty\n");
            iput(mip);
            return 0;
        }

        // Go to next entry
        cp+=dp->rec_len;
        dp = (DIR*)cp;
    }

    // 6.5) Verify the person removing is the owner or super user
    if (mip->INODE.i_uid != running->uid && running->uid != 0){
        printf("rmdir: Current user '%d' is not the owner of '%s' and cannot remove it\n", running->uid, pathname);
        iput(mip);
        return 0;
    }

    // 7) krmdir

    // Update globals to match the current dev being interacted with.
    update_globals(mip->dev);
    mykrmdir(mip, pathname);
    // Update globals to match the current dev being interacted with.
    update_globals(running->cwd->dev);

    // Put the child back after deallocation to free the memory inode
    iput(mip);

    // Return when done
    return 1;

}

// description: kernel remove directory function. Deallocates directory inode.
int mykrmdir(MINODE* mip, char* pathname){

    // Locals
    char local_buf[BLKSIZE];
    char* cp;
    DIR* dp;
    int found = 0;
    int i = 0;
    int j = 0;
    int previous_record_length = 0;

    // Get parent inode
    int pino = search(mip, "..");
    MINODE* pmip = iget(mip->dev, pino);
    
    // Find the child within the parent.
    // Get child name
    char child[64];
    mybasename(pathname, child);
    // Look in each data block for child. (Direct data blocks for this project)
    for(i = 0; i < 12 && !found; i++){

        // Load data block
        get_block(pmip->dev, pmip->INODE.i_block[i], local_buf);
        cp=local_buf;
        dp=(DIR*)local_buf;

        // Look within all entries of block
        if(pmip->INODE.i_block[i]){
            while(cp<local_buf+BLKSIZE && !found){

                // Load in name of entry
                char temp[64];
                strncpy(temp, dp->name, dp->name_len);
                temp[dp->name_len] = 0;

                // If the entry's name is the child's name, we've found it. Now we need to remove it.
                if(!strcmp(temp, child)){
                    found = 1;
                    //printf("krmdir: Entry found within parent\n");
                }
                // Else, go to next entry
                else{
                    previous_record_length = dp->rec_len;
                    cp+=dp->rec_len;
                    dp = (DIR*)cp;
                }
            }
        }
        
    }
    i--;

    // If for some reason it's not found, put parent back and return.
    if(!found){
        printf("krmdir: Error, child not found within parent\n");
        iput(pmip);
        return 0;
    }
    
    // Remove the child from the parent
    // Case 1, the directory is the only entry in the data block (At the beginning)
    if(dp == (DIR*)local_buf && dp->rec_len >= 200){

        // If this is the only data block, deallocate it and shift other data blocks after it down.
        bdalloc(pmip->dev, pmip->INODE.i_block[i]);
        for(j = i; pmip->INODE.i_block[j+1] != 0; j++){
            pmip->INODE.i_block[j] = pmip->INODE.i_block[j+1]; 
        }
        pmip->INODE.i_block[j] = 0;
    }
    // Case 2, directory is at the end of the data block, deallocate it and shift the data block. (If statement checks for if the rec_len is greater than
    // its ideal length for seeing if it's at the end of the block)
    else if(dp->rec_len > (4*((8+dp->name_len+3)/4))){

        // Get the entry length of dp and then shift backwards to the previous entry.
        int last_entry_length = dp->rec_len;      
        cp -= previous_record_length;
        dp = (DIR*)cp;

        // Set the rec_len of the previous entry equal to it's own length plus the removed's directory's rec_len
        dp->rec_len = dp->rec_len + last_entry_length;

        // put the block edited back into the system
        put_block(pmip->dev, pmip->INODE.i_block[i], local_buf);
    }
    // Case 3, child is first or in the middle of the block and not the only member
    else{

        // Memcopy the next entry into the current dp (Shift down)
        int last_entry_length = dp->rec_len;
        char local_buf_2[BLKSIZE];
        memcpy(local_buf_2, local_buf, BLKSIZE); 
        memcpy(dp, local_buf_2 + ((int)dp-(int)local_buf+last_entry_length), BLKSIZE);

        // Go to last entry
        dp = (DIR*)local_buf;
        cp = dp;
        found=0;
        while(cp<local_buf+BLKSIZE && !found){

            // If rec_len is greater than ideal length, we've found the last entry
            if(local_buf+BLKSIZE-((char*)dp+dp->rec_len+last_entry_length)==0){
                found=1;
            }  
            else{
                cp+=dp->rec_len;
                dp = (DIR*)cp; 
            }                                              
        }

        // Set last entry's rec_len to be the rec_len + the removed entry's rec_len
        dp->rec_len = dp->rec_len + last_entry_length;

        // put the block edited back into the system
        put_block(pmip->dev, pmip->INODE.i_block[i], local_buf);
        
    }

    // Put the parent back
    pmip->dirty = 1;
    pmip->INODE.i_atime = time(0L);
    iput(pmip);

    // Deallocate the inode and data blocks of the target
    // Blocks
    for(int i = 0; i < 12; i++){
        if(mip->INODE.i_block[i]){
            bdalloc(mip->dev, mip->INODE.i_block[i]);
        }
        else{
            i=12;
        }
    }
    // Inode
    idalloc(mip->dev, mip->ino);

    // Return when done
    return 1;

}
