/************* write_cp.c file **************/
#include "type.h"


// description: Given a file descritor, buffer, and the amount of bytes to read, this function writes the buffer to a file openned for write or append
// returns: Number of bytes written (anywhere from nbytes to 0 depending on how many bytes are in the buffer)
//          0 if unsuccessful as well.
int mywrite(char* fd_string, char* local_buf, char* nbytes_string){

    // Locals
    char* cp, cp2;
    char local_buf2[BLKSIZE], local_buf3[BLKSIZE];
    int* buf_pointer;
    int remain = 0, bytes_written = 0, byte_offset = 0, nbytes = 0, target_fd = 0, lbk = 0, start = 0, local_blk = 0, indirect_blk = 0, indirect_offset = 0;
    int old_blk = 0;

    // Try to convert fd_string into an integer. If unsuccessful, return
    target_fd = ToUInt(fd_string);
    if(target_fd == -1){
        printf("write: Invalid fd token\n");
        return 0;
    }

    // Try to convert nbytes_string into an integer. If unsuccessful, return
    nbytes = ToUInt(nbytes_string);
    if(nbytes == -1){
        printf("write: Invalid nbytes token\n");
        return 0;
    }

    // Check to see if the fd is openned for read in the current running proc. If not, return
    if(running->fd[target_fd] == 0){
        printf("write: FD requested not open\n");
        return 0;
    }
    if(running->fd[target_fd]->mode == 0){
        printf("write: FD not openned for a writeable mode\n");
        return 0;
    }

    // Update globals to match the current dev being interacted with.
    update_globals(running->fd[target_fd]->minodePtr->dev);

    // Initialize offset
    byte_offset = running->fd[target_fd]->offset;

    // While we haven't written all bytes requested, continue.
    while(nbytes){

        // Compute block to pull from for reading as well as starting byte
        lbk = byte_offset / BLKSIZE;
        start = byte_offset % BLKSIZE;

        // Convert logic block into the actual block we need to pull from within the minode
        // Direct block
        if(lbk < 12){
            local_blk = running->fd[target_fd]->minodePtr->INODE.i_block[lbk];

            // If there isn't a block in the area found, allocate and store a new one. Increase file size.
            if (local_blk == 0){
                running->fd[target_fd]->minodePtr->INODE.i_block[lbk] = balloc(running->cwd->dev);
                local_blk = running->fd[target_fd]->minodePtr->INODE.i_block[lbk];
                memset(local_buf3, 0, BLKSIZE);
                put_block(running->cwd->dev, local_blk, local_buf3);
                running->fd[target_fd]->minodePtr->dirty = 1;    
            }
        }
        // Indirect block
        else if(12 <= lbk && lbk < 12+256){

            // If block is empty, allocate a new one, increase file size, then allocate a block within it and continue. Otherwise, traverse.
            if(running->fd[target_fd]->minodePtr->INODE.i_block[12] == 0){

                // Indirect
                running->fd[target_fd]->minodePtr->INODE.i_block[12] = balloc(running->cwd->dev);
                local_blk = running->fd[target_fd]->minodePtr->INODE.i_block[12];
                running->fd[target_fd]->minodePtr->dirty = 1;    

                // Normal
                memset(local_buf3, 0, BLKSIZE);
                buf_pointer = (int*)local_buf3;
                buf_pointer[0] = balloc(running->cwd->dev);
                put_block(running->cwd->dev, local_blk, local_buf3);
                local_blk = buf_pointer[0];
            }
            else{

                // Get single indirect block
                get_block(running->cwd->dev, running->fd[target_fd]->minodePtr->INODE.i_block[12], local_buf3);
                buf_pointer = (int*)local_buf3;

                // Set local block to the correct block within the indirect block.
                local_blk = buf_pointer[lbk-12];

                // If there isn't a block in the area found, allocate and store a new one. Increase block size
                if (local_blk == 0){
                    buf_pointer[lbk-12] = balloc(running->cwd->dev);
                    local_blk = buf_pointer[lbk-12];
                    running->fd[target_fd]->minodePtr->dirty = 1;
                    put_block(running->cwd->dev, running->fd[target_fd]->minodePtr->INODE.i_block[12], local_buf3);  
                }
            }
            
        }
        // Double indirect block
        // Different cases. 
        // 1) block[13] == 0 -> make double indirect block, make indirect block, and make regular block. Attach all together
        // 2) block[13]'s indirect block == 0, make a new indirect block with a regular block within it. Attach together
        // 3) block[13]'s indirect block's block == 0, make a new regular block and attach.
        // 4) Each object is initialized, continue like normal.
        else{

            // ***Case 1***
            // If block is empty, allocate a new one, then make an indirect block, then make a normal block and continue. Otherwise, traverse.
            if(running->fd[target_fd]->minodePtr->INODE.i_block[13] == 0){

                // Double indirect
                running->fd[target_fd]->minodePtr->INODE.i_block[13] = balloc(running->cwd->dev);
                local_blk = running->fd[target_fd]->minodePtr->INODE.i_block[13];
                running->fd[target_fd]->minodePtr->dirty = 1;    

                // Indirect
                memset(local_buf3, 0, BLKSIZE);
                buf_pointer = (int*)local_buf3;
                buf_pointer[0] = balloc(running->cwd->dev);
                put_block(running->cwd->dev, local_blk, local_buf3);
                local_blk = buf_pointer[0];

                // Normal
                buf_pointer[0] = balloc(running->cwd->dev);
                put_block(running->cwd->dev, local_blk, local_buf3);
                local_blk = buf_pointer[0];

            }
            else{

                // Get double indirect block
                get_block(running->cwd->dev, running->fd[target_fd]->minodePtr->INODE.i_block[13], local_buf3);

                // Get the indirect block                
                indirect_blk = (lbk - (256+12)) / 256;
                indirect_offset = (lbk - (256+12)) % 256;

                // Now that we have the indirect block number, find the block within the indirect block
                buf_pointer = (int*)local_buf3;
                local_blk = buf_pointer[indirect_blk];

                // ***Case 2***
                // If the gotten block was empty, allocate a new indirect block followed by a normal block attached to it and continue
                if(local_blk == 0){

                    // Indirect
                    buf_pointer[indirect_blk] = balloc(running->cwd->dev);
                    local_blk = buf_pointer[indirect_blk];
                    put_block(running->cwd->dev, running->fd[target_fd]->minodePtr->INODE.i_block[13], local_buf3);
                    running->fd[target_fd]->minodePtr->dirty = 1;    

                    // Normal
                    memset(local_buf3, 0, BLKSIZE);
                    buf_pointer = (int*)local_buf3;
                    buf_pointer[0] = balloc(running->cwd->dev);
                    put_block(running->cwd->dev, local_blk, local_buf3);
                    local_blk = buf_pointer[0];

                }
                else{
                    get_block(running->cwd->dev, local_blk, local_buf3);
                    buf_pointer = (int*)local_buf3;
                    old_blk = local_blk;
                    local_blk = buf_pointer[indirect_offset];

                    // ***Case 3***
                    // If there isn't a block in the area found, allocate and store a new one.
                    if (local_blk == 0){
                        buf_pointer[indirect_offset] = balloc(running->cwd->dev);
                        local_blk = buf_pointer[indirect_offset];
                        running->fd[target_fd]->minodePtr->dirty = 1;    
                        put_block(running->cwd->dev, old_blk, local_buf3);
                    }

                    // ***Case 4***
                    // If no block was allocated in case 3, we are in case 4.
                }
                
            }          
        }    

        // Get block's data into buffer
        get_block(running->cwd->dev, local_blk, local_buf2);
        cp = local_buf2 + start;
        remain = BLKSIZE - start;

        // While we aren't at the end of the block, write over bytes to the block
        while(remain){

            // Copy over 1 byte
            *cp = *local_buf;
            
            // increment buf, cp, offset, size, and count
            local_buf++;
            cp++;
            running->fd[target_fd]->offset++;
            byte_offset++;
            bytes_written++;
            running->fd[target_fd]->minodePtr->INODE.i_size++;    

            // decrease remain, available_bytes, and number of bytes read
            remain--;
            nbytes--;

            // If we have read all the bytes asked or if we are at the end of the block, break from this loop
            if(nbytes <= 0)
                break;
        }


        // Put Block back after writing data to it.
        put_block(running->cwd->dev, local_blk, local_buf2);
    }

    // Update minode timestamp
    running->fd[target_fd]->minodePtr->INODE.i_atime = time(0L);
    
    // Set mip to dirty if it isn't already
    running->fd[target_fd]->minodePtr->dirty = 1;  

    // Update globals to match the current dev being interacted with.
    update_globals(running->cwd->dev);
    
    // Return number of bytes written
    return bytes_written;
}

// description: Give two files, a source and a destination, this function copies the contents of the source to the destination.
int mycp(char* source, char* destination){
    
    // Open the files, source for read and destination for write. If either fail, return
    int fd_source = myopen(source, "RD");
    int fd_destination = myopen(destination, "WR");
    if(fd_source == -1 || fd_destination == -1){
        printf("cp: Failed to open file tokens\n");
        return 0;
    }
    else if(fd_source == fd_destination){
        printf("cp: Cannot copy file to itself\n");
        myclose(source);
        myclose(destination);
        return 0;
    }

    // Locals
    int bytes_read = 0;
    int bytes_remaining = 0;
    int eof = 0;
    char holder[BLKSIZE] = "";
    char holder2[BLKSIZE];
    char holder3[BLKSIZE];
    char holder4[BLKSIZE];
    char bytes_read_string[64];
    int* buf_pointer, *buf_pointer2;
    char source_fd_string[64] = "";
    char destination_fd_string[64] = "";
    sprintf(source_fd_string, "%d", fd_source);
    sprintf(destination_fd_string, "%d", fd_destination);   
    sprintf(holder2, "%d", BLKSIZE);

    // Clear out blocks in destination
    for(int i = 0; i < 14; i++){

        if(running->fd[fd_destination]->minodePtr->INODE.i_block[i] != 0){


            // Direct block case
            if(i<12){
                bdalloc(running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i]);
                running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i] = 0;
                running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_size-=BLKSIZE;
            }
            // Indirect block case
            else if(i==12){
                
                get_block(running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i], holder3);
                buf_pointer = (int*)holder3;

                // Deallocate blocks under indirect block
                for(int k = 0; k < BLKSIZE/4; k++){
                    if(buf_pointer[k] != 0){
                        bdalloc(running->cwd->dev, buf_pointer[k]);
                        buf_pointer[k] = 0;
                        running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_size-=BLKSIZE;
                    }
                }

                // Deallocate indirect block
                put_block(running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i], holder3);
                bdalloc(running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i]);
                running->fd[fd_destination]->minodePtr->INODE.i_block[i] = 0;
                running->fd[fd_destination]->minodePtr->INODE.i_size-=BLKSIZE;

            }
            else if(i==13){

                // Get double indirect block
                get_block(running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i], holder3);
                buf_pointer = (int*)holder3;

                // Deallocate indirect blocks under double indirect block
                for(int k = 0; k < BLKSIZE/4; k++){

                    if(buf_pointer[k] != 0){

                        // Get indirect_block
                        get_block(running->cwd->dev, buf_pointer[k], holder4);
                        buf_pointer2 = (int*)holder4;

                        // Deallocate blocks under indirect block
                        for(int j = 0; j < BLKSIZE/4; j++){
                            if(buf_pointer2[j] != 0){
                                bdalloc(running->cwd->dev, buf_pointer2[j]);
                                buf_pointer2[j] = 0;
                                running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_size-=BLKSIZE;
                            }
                        }

                        // Deallocate indirect block
                        put_block(running->cwd->dev, buf_pointer[k], holder3);
                        bdalloc(running->cwd->dev, buf_pointer[k]);
                        buf_pointer[k] = 0;
                        running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_size-=BLKSIZE;
                    }   
                }     

                // Deallocate double indirect block
                put_block(running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i], holder3);
                bdalloc(running->cwd->dev, running->fd[fd_destination]->minodePtr->INODE.i_block[i]);
                running->fd[fd_destination]->minodePtr->INODE.i_block[i] = 0;
                running->fd[fd_destination]->minodePtr->INODE.i_size-=BLKSIZE;
            }
        }

    }
    // Set size to 0
    running->fd[fd_destination]->minodePtr->INODE.i_size=0;
    bytes_remaining = running->fd[fd_source]->minodePtr->INODE.i_size;

    // While we aren't at the end of the reader, copy over blocks of data to destination
    while(!eof){

        // Read data into local_buf2
        bytes_read = myread(source_fd_string, holder, holder2);
        bytes_remaining -= bytes_read;

        // If bytes_read == 0, stop copying. Otherwise, write buffer to destination
        if(bytes_read == 0){
            eof = 1;
        }
        else{
            // Copy over the amount read from source to destination
            if (bytes_remaining < 0){
                bytes_read = bytes_read - (bytes_remaining * -1);
            }
            sprintf(bytes_read_string, "%d", bytes_read);
            mywrite(destination_fd_string, holder, bytes_read_string);
        }
    }

    // When done, close both files and exit
    myclosefd(destination_fd_string);
    myclosefd(source_fd_string);
    return 1;   
}

