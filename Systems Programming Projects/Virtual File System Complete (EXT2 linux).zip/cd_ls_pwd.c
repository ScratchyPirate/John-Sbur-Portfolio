/************* cd_ls_pwd.c file **************/
#include "type.h"

// decription: using the local "pathname" variable, which stores user input, this function works in three different ways
//  1) pathname = "", change running->cwd to be the root of the file system
//  2) pathname = "a/b/c", change running->cwd to c  by traversing through the current cwd to "c"
//  3) pathname = "/a/b/c", change running->cwd to "c" by traversing through the file system's root
// returns: 0 if any token is not found and the path cannot be completed OR if any of the tokens are not directories
//          1 if cwd is changed successfully.
int mycd(char* pathname)
{

  // store path in a local buffer
  char local_path[256] = "";
  strcpy(local_path, pathname);

  // if path is empty, change to root.
  if(!strcmp(local_path, "")){
    printf("cd: Changing to root\n");
    iput(running->cwd);
    running->cwd = root;
    update_globals(running->cwd->dev);
    return 1;
  }
  
  // get the inode number associated with the path
  int target_ino = getino(local_path);

  // if 0, return
  if(target_ino == 0){
    printf("cd: target not found\n");
    return 0;
  }

  // find inode from number
  MINODE* local_mip = iget(getino_dev, target_ino);

  // verify the inode is a dir type.
  if(!S_ISDIR(local_mip->INODE.i_mode)){
    printf("cd: Error, target is not of type dir\n");
    iput(local_mip);
    return 0;
  }

  // put the dir as the cwd
  iput(running->cwd);

  // set cwd
  running->cwd = local_mip;

  update_globals(running->cwd->dev);

  return 1;
  
}

// description: given a name and a memory inode, this function prints the name of the file and information related to the 
//   file contained within "mip". Printed in UNIX ls -l format.
int ls_file(MINODE *mip, char *name)
{
  // *****pulled from my own lab4client.c file*****//
  // Directory access pointers
  DIR* dir_pointer;
  struct dirent* current_dir_pointer;
  
  //locals
  INODE file_inode = mip->INODE;

  //print out permission data
      // File type
      if(S_ISDIR(file_inode.i_mode)){
        printf("d");
      }
      else if(S_ISLNK(file_inode.i_mode)){
        printf("l");
      }
      else{
        printf("-");
      }
      // User permissions
      (file_inode.i_mode & S_IRUSR) ? printf("r") : printf("-");
      (file_inode.i_mode & S_IWUSR) ? printf("w") : printf("-");
      (file_inode.i_mode & S_IXUSR) ? printf("x") : printf("-");
      // Group permissions
      (file_inode.i_mode & S_IRGRP) ? printf("r") : printf("-");
      (file_inode.i_mode & S_IWGRP) ? printf("w") : printf("-");
      (file_inode.i_mode & S_IXGRP) ? printf("x") : printf("-");
      // Other permissions
      (file_inode.i_mode & S_IROTH) ? printf("r") : printf("-");
      (file_inode.i_mode & S_IWOTH) ? printf("w") : printf("-");
      (file_inode.i_mode & S_IXOTH) ? printf("x") : printf("-");
      // Number of links
      printf("  %5li ", file_inode.i_links_count);

  //print out group and user
      struct passwd *uid;
      struct group *gid;
      // read in uid as a formatted type and print it out.
      uid = getpwuid(file_inode.i_uid);
      printf("%s ",uid->pw_name);
      gid = getgrgid(file_inode.i_gid);
      printf("%s ",gid->gr_name);

  //print file size in bytes
      printf("%8li ", file_inode.i_size);

  //update timeinfo and print
      //mip->INODE.i_ctime = time(0L);
      time_t time = mip->INODE.i_atime;
      char *mtime = ctime(&time);
      mtime[strlen(mtime) - 1] = '\0';
      printf("%s ",mtime);

  //print file name
      printf("%16s\t",name);
      
  // *****end pull*****//
}

// description: given a minode "mip", this function prints each directory within the inode. Prints entries until directories
//  cannot be found within the minode.
// returns: 1 when complete
//          garbage if exits early.
int ls_dir(MINODE *mip)
{

  //printf("ls_dir: Executing ls -l. Begin listing directories\n");
  
  // loval variables
  char buf[BLKSIZE], temp[256];
  DIR *dp;
  char *cp;

  // list each datablocks files
  for(int i = 0; i< 12; i++){

    get_block(mip->dev, mip->INODE.i_block[i], buf);
    dp = (DIR *)buf;
    cp = buf;

    if(mip->INODE.i_block[i]){

      // store first entry for checking circular loop
      DIR* firstdir = dp;
      int pass1 = 0;
   
      while (cp < buf + BLKSIZE){

        strncpy(temp, dp->name, dp->name_len);
        temp[dp->name_len] = 0;

        // list contents of each file.
        MINODE* current_mip = iget(mip->dev, dp->inode);
        if(current_mip->ino != 0){
          ls_file(current_mip, temp);
            
          //print dev and inode number
          printf("[%d %d]\n", current_mip->dev, dp->inode);
          iput(current_mip);
        }
        else {
          return 1;
        }
        cp += dp->rec_len;
        dp = (DIR *)cp;
      }  
    }
  }  
}

// decription: using the local "pathname" variable, which stores user input, this tries to list the contents
//  of the basename of "pathname" in UNIX ls -l format. 
// returns: 1 if successful
//          0 if not found or any pathname token isn't a directory file.
int myls(char* pathname)
{

  // storage for names
  char dir[256] = "";
  char base[256] = "";

  // store each part of path in storage names
  mydirname(pathname, dir);
  mybasename(pathname, base);

  // if both are empty, ls cwd
  if(!strcmp(dir, "") && !strcmp(base, "")){
     ls_dir(running->cwd);
     return 1;
  }

  // if dir is empty, ls base within cwd
  if(!strcmp(dir, "")){

    // search for ino within cwd
    int target_ino = getino(pathname);

    // if not found print and return.
    if(target_ino == 0){
      printf("ls: Target dir not found\n");
      return 0;
    }

    // else, ls the found target
    MINODE* target_mip = iget(getino_dev, target_ino);
    if(!S_ISDIR(target_mip->INODE.i_mode)){
      printf("ls: Error, target is not of type dir\n");
      iput(target_mip);
      return 0;
    }
    ls_dir(target_mip);
    iput(target_mip);
    return 1;
  }
    
  // if neither empty, print based on pathname
  int target_ino = getino(pathname);

  // if not found, return here;
  if(target_ino == 0){
    printf("ls: Target dir not found\n");
    return 0;
  }

  // else get minode
  MINODE* target_mip = iget(getino_dev, target_ino);

  // if not of type dir, return
  if(!S_ISDIR(target_mip->INODE.i_mode)){
    printf("ls: Error, target is not of type dir\n");
    iput(target_mip);
    return 0;
  }

  printf("%d\n", S_ISDIR(target_mip->INODE.i_mode));

  // ls_dir if able
  ls_dir(target_mip);

  // put directory back when done
  iput(target_mip);

  return 1;
  
}

// description: this function looks at the current running->cwd, inputted as "wd", and traverses up to the root of the filesystem
//  and prints the names of each tokenas it goes up the file tree. Uses rpwd as a helper function.
char *mypwd(MINODE *wd)
{
  // format text
  printf("CWD = ");
  
  // if root, print and return
  MINODE* current_root = iget(running->cwd->dev, 2);
  if (wd == current_root){
    printf("/\n");
    iput(current_root);
    return;
  }
  iput(current_root);

  // else, work backwards to print the different names of the parents to create the wd
  rpwd(wd);
  
}

// description: helper function of pwd(). Uses recursion.
void rpwd(MINODE* wd){

  // if root, return
  MINODE* current_root = iget(running->cwd->dev, 2);
  if(wd == current_root){
    iput(current_root);
    return;
  }
  iput(current_root);

  // find ino
  int myino = 0;
  int parent_ino = findino(wd, &myino);
  if(!parent_ino) {
    printf("rpwd: Inode not found\n");
    return 0;
  }

  // find name of ino within parent
  char ino_name[256] = "";
   MINODE* pip = iget(running->cwd->dev, parent_ino);
   if(!findmyname(pip, myino, ino_name)){
    printf("rpwd: Error finding name of ino\n");
    iput(pip);
    return 0;
  }

  // recursive call
   rpwd(pip);

   // put pup back when done
   iput(pip);
  
  // print ino name
   printf("/%s", ino_name);
}